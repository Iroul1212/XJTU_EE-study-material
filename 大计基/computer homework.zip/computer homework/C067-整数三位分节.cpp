#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int k=0;
	int i=1;
	int t=0;
	int a[100];
	while(k<n)
	{
		k=n%i;
		a[t]=n/i%10;
		t++;
		i=i*10;
	}
	int m=(t-1)%3;
	if(m)
	{
		int j=0;
		for(;j<m;j++)
		{
			printf("%d",a[t-2-j]);
	    }
	    int p=t-2-j;
	    while(p-2>=0)
	    {
	    	printf(",%d%d%d",a[p],a[p-1],a[p-2]);
	    	p=p-3;
		}
	}
	else
	{
		int p=t-2;
		int flag=0;
	    while(p-2>=0)
	    {
	    	if(flag)
	    	{
	    		printf(",");
			}
			printf("%d%d%d",a[p],a[p-1],a[p-2]);
	    	p=p-3;
	    	flag=1;
		}
	}
	return 0;
}