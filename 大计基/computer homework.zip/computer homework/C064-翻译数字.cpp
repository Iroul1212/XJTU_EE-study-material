#include <stdio.h>
#include <string.h>
int main()
{
	char wrd[10][10]={"zero","one", "two", "three", "four","five", "six", "seven", "eight","nine"};
	char ipt[200];
	int num[200];
	gets(ipt);
	for(int i=0;i<strlen(ipt);i++)
	{
		num[i]=ipt[i]-'0';
	}
	int flag=0;
	for(int i=0;i<strlen(ipt);i++)
	{
		if(flag)
		{
			printf(" ");
		}
		printf("%s",wrd[num[i]]);
		flag=1;
	}
	return 0;
}
	