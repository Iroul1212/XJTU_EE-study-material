#include <stdio.h>
#include <string.h>
int main()
{
	char s[5][45],max[45],min[45];
	for(int i=0;i<5;i++)
	    scanf("%s",&s[i]);
    strcpy(max,s[0]);
	strcpy(min,s[0]);
	for(int j=1;j<5;j++)	
	   {
	   	if(strcmp(max,s[j])<0)
	   	    strcpy(max,s[j]);
	   	if(strcmp(min,s[j])>0)
	   	    strcpy(min,s[j]);
	   }
	printf("max:%s min:%s",max,min);
	return 0;
}