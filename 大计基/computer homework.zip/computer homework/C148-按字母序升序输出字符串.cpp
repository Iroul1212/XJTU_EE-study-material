#include <stdio.h>
#include <string.h>
int main()
{
	char str[81]={0};
	gets(str);
	char str1[81]={0};
	int j=0;
	for(int i=0;i<strlen(str);i++)
	{
		if(str[i]>='a'&&str[i]<='z')
		{
			str1[j]=str[i];
			j++;
		}
	}
	char s;
	for(int i=0;i<strlen(str1)-1;i++)
	{
		for(int k=0;k<strlen(str1)-1;k++)
		{
			if(str1[k]>str1[k+1])
			{
				s=str1[k];
			    str1[k]=str1[k+1];
			    str1[k+1]=s;
			}
		}
	}
	puts(str1);
	return 0;
}