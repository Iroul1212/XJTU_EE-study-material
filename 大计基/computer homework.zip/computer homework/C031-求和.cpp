#include <stdio.h>
int main()
{
	int a,n;
	scanf("%d %d",&a,&n);
	int i=1,sum=0,b=a;
	int flag=0;
	while (i<=n)
	{
		sum=sum+b;
		if(flag)
		{
			printf("+");
		}
		flag=1;
		printf("%d",b);
		b=10*b+a;
		i=i+1;
	}
	printf("=%d\n",sum);
	return 0;
}