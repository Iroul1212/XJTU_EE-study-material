#include <stdio.h>
int main()
{
	int x;
	int a=0,b=0,c=0,d=0,e=0;
	while (x!=-1)
	{
		scanf("%d",&x);
		if(x==0)
	 	 a=a+1;
		else if(x==1)
		 b=b+1;
		else if(x==2)
		 c=c+1;
		else if(x==3)
		 d=d+1;
		else if(x==4)
		 e=e+1;
	}
	printf("%d %d %d %d %d\n",a,b,c,d,e);
	return 0;
}