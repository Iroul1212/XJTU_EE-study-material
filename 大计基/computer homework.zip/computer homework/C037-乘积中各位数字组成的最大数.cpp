#include <stdio.h>
#include <string.h>
int main()
{
	int n;
	scanf("%d",&n);
	char a[100]={0};
	n=3*n;
	printf("%d ",n);
	int i=0;
	while(n>0)
	{
		int m=n%10;
		a[i]='0'+m;
		i++;
		n=n/10;
	}
	int l=strlen(a);
	char a1;
	for(int j=0;j<l-1;j++)
	{
		for(int k=0;k<l-1;k++)
		{
			if(a[k]<a[k+1])
			{
				a1=a[k];
				a[k]=a[k+1];
				a[k+1]=a1;
			}
		}
	}
	for(int j=0;j<l;j++)
	{
		printf("%c",a[j]);
	}
	return 0;
}