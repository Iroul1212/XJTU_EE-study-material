#include <stdio.h>
int main()
{
	char input[200],output[200];
	scanf("%s",&input);
	int i=0,j=0,k=0;
	for(;i<200;i++){
		if(input[i]!='*')
		  break;
    }
	for(;j<200;j++){
	    output[j]=input[j+i];
		if(input[j+i]=='\0')
		   break;
    }   
    for(;k<i;k++){
		output[k+j]='*';
	}
	output[k+j]='\0';
    printf("%s",output);
	return 0;
}