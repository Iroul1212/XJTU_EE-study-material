#include <stdio.h>
int main()
{
	int m,n,t=0;
	scanf("%d %d",&m,&n);
	int x=m;
	int flag=0;
	while (x>=m&&x<=n)
	{
		int k=0,b=0,i=1,sum=0;
		while (x>k)
		{
			k=x%i;
			b=x/i%10;
			sum=b*b*b+sum;
			i=i*10;
		}
		if(sum==x)
		{
			t=t+1;
			if(flag)
			printf(" ");
			printf("%d",x);				
			flag=1;	
	    }
		
		x=x+1;
    }
	if(t==0)
	printf("-1");
	return 0;
}