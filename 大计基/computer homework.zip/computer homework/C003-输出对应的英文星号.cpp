#include <stdio.h>
int main()
{
	int a,b,c,o,p,q;
	scanf("%d%d%d",&a,&b,&c);
	o=p=q=1;
	while(o<a)
	{
	    printf("*");
		o=o+1;
	}
	printf("*\n");
	while(p<b)
	{	
	    printf("*");
		p=p+1;
	}
	printf("*\n");
	while(q<c)
	{	
		printf("*");
		q=q+1;
	}
	printf("*\n");
	return 0;
}
                