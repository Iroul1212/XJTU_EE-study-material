#include <stdio.h>
#include <string.h>
int main()
{
	char ipt[100][20];
	char opt[100][20];
	int num[100];
	int i=0;
	for(;strcmp(ipt[i-1],"###")!=0;i++)
	{
		scanf("%s",&ipt[i]);
	}
	i=i-1;
	int t=1;
	strcpy(opt[0],ipt[0]);
	for(int j=0;j<i;j++)
	{
		num[j]=0;
	}
	for(int j=1;j<i;j++)
	{
		int m=0;
		for(int k=0;k<j;k++)
		{
			if(strcmp(ipt[j],ipt[k])!=0)
			{
				m++;
			}
	    }
		if(m==j)
		{
			strcpy(opt[t],ipt[j]);
			t++;
		}
		else
		{
			for(int p=0;p<=t;p++)
			{
				if(strcmp(ipt[j],opt[p])==0)
				{
					num[p]++;
					break;
				}
			}
		}
    }
    int flag=0;
    for(int j=0;j<t;j++)
    {
    	if(flag)
    	{
    		printf(" ");
		}
		printf("%s-%d",opt[j],num[j]+1);
		flag=1;
	}
    return 0;
}