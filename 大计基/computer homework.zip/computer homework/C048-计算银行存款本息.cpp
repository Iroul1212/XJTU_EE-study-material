#include <stdio.h>
#include <math.h>
int main()
{
	float money,years,rate,sum;
	scanf("%f,%f,%f",&money,&years,&rate);
	sum=money*pow((1+rate),years);
	printf("%.2f",sum);
	return 0;
}