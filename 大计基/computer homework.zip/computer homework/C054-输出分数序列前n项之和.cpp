#include <stdio.h>
int main()
{
	int n;
	float sum=0,fz=2,fm=1,x;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		sum=sum+fz/fm;
		x=fz;
		fz=fz+fm;
		fm=x;
	}
	printf("%.4f",sum);
	return 0;
}