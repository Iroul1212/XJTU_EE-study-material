#include <stdio.h>
struct fs
{
	int fz;
	int fm;
};
int main()
{
	int N;
	scanf("%d",&N);
	struct fs a[100]={0};
	for(int i=0;i<N;i++)
	{
		scanf("%d/%d",&a[i].fz,&a[i].fm);
	}
	struct fs sum;
	sum.fz=0;
	sum.fm=1;
	for(int i=0;i<N;i++)
	{
		sum.fm=sum.fm*a[i].fm;
	}
	for(int i=0;i<N;i++)
	{
		sum.fz=sum.fz+(sum.fm/a[i].fm)*a[i].fz;
	}
	if(sum.fz%sum.fm==0)
	{
		printf("%d",sum.fz/sum.fm);
	}
	else
	{
        int n=sum.fz/sum.fm;
		sum.fz=sum.fz-n*sum.fm;
	    struct fs aw;
	    aw.fz=sum.fz;
	    aw.fm=sum.fm;
	    if(sum.fz>0)
	    {
		   for(int i=2;i<=sum.fz;i++)
		   {
			    if(sum.fz%i==0&&sum.fm%i==0)
			    {
				   while(aw.fz%i==0&&aw.fm%i==0)
				    {
					   aw.fz=aw.fz/i;
			           aw.fm=aw.fm/i;
			        }
			    }
		    }
	    }
	    if(sum.fz<0)
	    {
		    sum.fz=-sum.fz;
	 	    for(int i=2;i<=sum.fz;i++)
		    {
			    if(sum.fz%i==0&&sum.fm%i==0)
			    {
					while(aw.fz%i==0&&aw.fm%i==0)
				    {			
				       aw.fz=aw.fz/i;
				       aw.fm=aw.fm/i;
				    }   
			    }
		    }
		    aw.fz=-aw.fz;
	    }   
		if(n!=0)
		{
			printf("%d ",n);
		}
		printf("%d/%d",aw.fz,aw.fm);
    }
	return 0;
}