#include<stdio.h>
struct psn
{
	char nmb[200];
	char name[200];
	int a,b,c;
	int sum;
};
int main()
{
	int n;
	scanf("%d",&n);
	struct psn hmn[200];
	for(int i=0;i<n;i++)
	{
		scanf("%s",&hmn[i].nmb);
		scanf("%s",&hmn[i].name);
		scanf("%d",&hmn[i].a);
		scanf("%d",&hmn[i].b);
		scanf("%d",&hmn[i].c);
		hmn[i].sum=hmn[i].a+hmn[i].b+hmn[i].c;
	}
	struct psn srt;
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1;j++)
		if(hmn[j].sum>hmn[j+1].sum)
		{
			srt=hmn[j];
			hmn[j]=hmn[j+1];
			hmn[j+1]=srt;
		}
	}
	for(int i=0;i<n;i++)
	{
		printf("%s ",hmn[i].nmb);
		printf("%s ",hmn[i].name);
		printf("%d ",hmn[i].a);
		printf("%d ",hmn[i].b);
		printf("%d ",hmn[i].c);
		printf("%d\n",hmn[i].sum);
	}
}