#include <stdio.h>
#include <string.h>
int main()
{
	char str[100]={0};
	scanf("%s",&str);
	int maxi=strlen(str)-1;
	printf("%s",str+maxi);
	for(int i=1;i<=maxi;i++)
	{
		printf(" %s",str+maxi-i);
	}
	return 0;
}