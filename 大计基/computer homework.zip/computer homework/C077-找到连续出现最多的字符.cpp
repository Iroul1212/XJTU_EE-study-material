#include <stdio.h>
int main()
{
	char str[100]={0};
    scanf("%s",&str);
    char maxstr=str[0];
	int max=0;
	int maxi=0;
	char cmaxstr=str[0];
	int cmax=0;
	int cmaxi=0;
	int i=0;
	while (str[i])
	{
		while (str[i]==cmaxstr)
		{
			cmax=cmax+1;
			i=i+1;
		}
		if (cmax>max)
		{
			maxstr=cmaxstr;
			max=cmax;
			maxi=cmaxi;
		}
		cmax=0;
		cmaxstr=str[i];
		cmaxi=i;
    }
    printf("%c %d %d",maxstr,max,maxi);
    return 0;
}