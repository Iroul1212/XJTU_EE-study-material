#include <stdio.h>
char cha(char x,int n);
int main()
{
	char str[100];
	int n;
	scanf("%s %d",&str,&n);
	int i=0;
	while(str[i]!=0)
	{
		str[i]=cha(str[i],n);
		i=i+1;
	}
	printf("%s",str);
	return 0;
}

char cha(char x,int n)
{
	if(x>='a'&&x<='z')
	{
		x='a'+(x-'a'+n)%26;
	}
	if(x>='A'&&x<='Z')
	{
		x='A'+(x-'A'+n)%26;
	}
	return x;
}