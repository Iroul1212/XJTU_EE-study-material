#include <stdio.h>
int ispalindrome(int n);
int main()
{
	int n;
	scanf("%d",&n);
	int i=1000;
	int flag=0;
	while(i>=1000&&i<=n)
	{
		if (ispalindrome(i))
		{
		if(flag)
		  {
		  	printf(" ");
		  }
		 printf("%d",i);
		 flag=1;
		}
	    i=i+1;
	}
	return 0;
}

int ispalindrome(int n)
{
	int a,b,c,d;
	a=n/1000%10;
	b=n/100%10;
	c=n/10%10;
	d=n/1%10;
	if(a==d&&b==c)
		return 1;
	else
		return 0;
}