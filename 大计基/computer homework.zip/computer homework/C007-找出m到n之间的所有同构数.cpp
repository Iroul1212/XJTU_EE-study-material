#include <stdio.h>
int main()
{
	int m,n,x,y;
	scanf("%d %d",&m,&n);
	x=m;
	int flag=0;
	while (x>=m&&x<=n)
	{
		y=x*x;
		int i=10,k;
		while (y>k)
		{
			k=y%i;
			if (k==x)
			{
			    if (flag)
                    printf(" ");
				printf("%d",x);
				flag=1;
				break;
			}
			else
			{
				i=i*10;
			}
		}
		x=x+1;
	}
    return 0;
}