#include <stdio.h>
int main()
{
	int n;
	int a[51];
	scanf("%d\n",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	int p=0;
	int t=0;
	int q;
    for(int j=0;j<n;j++)
	{
		t=0;
        for(int k=j+1;k<n;k++)
        {
        	if(a[j]==a[k]&&k-j==t+1)
        	{
        		t++;
			}
		}
		if(p<t)
		{
			p=t;
			q=j;
		}	
	}
	if(p==0)
	{
		printf("NO");
	}
	else
	{
		printf("%d,%d",q,q+p);
	}
	return 0;
}