#include <stdio.h>
int main()
{
	int a,k,m;
	int sum=0,i=1;
	scanf("%d",&a);
	while (a>k)
	{
		k=a%i;
		m=a/i%10;
		sum=sum+m;
		i=i*10;
	}
	if(sum%2==1)
	{
		printf("1\n");
	}
	else
	{
		printf("0\n");
	}
	return 0;
}