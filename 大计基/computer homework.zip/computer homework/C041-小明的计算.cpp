#include <stdio.h>
int rev(int x);
int main()
{
	int x,y;
	scanf("%d %d",&x,&y);
	int a1,b1;
	a1=rev((x+y)/2);
	b1=rev((x-y)/2);
	int s=a1+b1;
	int t=a1-b1;
	printf("%d %d",s,t);
	return 0;
}

int rev(int x)
{
	int k=0;
	int i=1;
	int x1=0;
	int x2;
	if(x<0)
	{
		x2=-x;
	}
	else
	{
		x2=x;
	}
	while(k<x2)
	{
		k=x2%i;
		i=10*i;
	}
	i=i/100;
	int j=1;
	while(i>0)
	{
		x1=x1+((x2/i)%10)*j;
		j=j*10;
		i=i/10;
	}
	if(x<0)
	{
		x1=-x1;
	}
	return x1;
} 