#include <stdio.h>
#include <string.h>
int main()
{
	char str1[200];
	char str2[200];
	scanf("%s %s",&str1,&str2);
	int t=0;
	for(int i=0;i<strlen(str1);i++)
	{
		int flag=1;
		for(int j=0;j<strlen(str2);j++)
		{
			if(i+j>=strlen(str1)||str1[i+j]!=str2[j])
			{
				flag=0;
				break;
			}
		}
		if(flag)
		{
			t++;
		}
	}
	printf("%d",t);
	return 0;
}