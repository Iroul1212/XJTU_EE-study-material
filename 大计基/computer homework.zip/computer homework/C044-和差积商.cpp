#include <stdio.h>
int main()
{
	int a,b,s,d,p,q;
	scanf("%d %d",&a,&b);
	s=a+b;
	d=a-b;
	p=a*b;
	q=a/b;
	printf("%d %d %d %d\n",s,d,p,q);
	return 0;
}