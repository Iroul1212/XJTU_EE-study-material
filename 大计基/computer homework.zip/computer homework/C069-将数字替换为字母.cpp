#include <stdio.h>
int main()
{
	int n;
	int m;
	scanf("%d",&n);
	m=n/2;
	printf("%d ",m);
	int i=1;
	int k=0;
	while(k<m)
	{
		i=i*10;
		k=m%i;
	}
	i=i/10;
	while(i>=1)
	{
	    char t=m/i%10;
		t=t+'a';
		printf("%c",t);
		i=i/10;
	}
	return 0;
}