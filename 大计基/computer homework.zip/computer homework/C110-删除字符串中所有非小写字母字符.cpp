#include <stdio.h>
#include <string.h>
int main()
{
	char ipt[200]={0};
	char opt[200]={0};
	gets(ipt);
	int j=0;
	for(int i=0;i<strlen(ipt);i++)
	{
		if(ipt[i]>='a'&&ipt[i]<'z')
		{
			opt[j]=ipt[i];
			j++;
		}
	}
	puts(opt);
	return 0;
}