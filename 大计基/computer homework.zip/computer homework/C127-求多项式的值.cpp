#include <stdio.h>
double poly(int n,double x);
int main()
{
	int n;
	double x;
	scanf("%d%lf",&n,&x);
	printf("%lf",poly(n,x));
	return 0;
}

double poly(int n,double x)
{
	double r;
	if(n==0)
	{
		r=1;
	}
	if(n==1)
	{
		r=x;
	}
	if(n>1)
	{
		r=((2*n-1)*x* poly(n-1,x)-(n-1)* poly(n-2,x))/n;
	}
	return r;
}