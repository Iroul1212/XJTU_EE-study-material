#include <stdio.h>
#include <string.h>
int main()
{
	int a,K,m;
	scanf("%d %d",&a,&K);
	char s[200]={0};
	int i=0;
	if(a==0)
	{
		printf("0");
	}
	else
	{
		while(a>0)
		{
			m=a%K;
			if(m<10)
			{
				s[i]=m+'0';
				i++;
			}
			else
			{
				s[i]=m-10+'A';
				i++;
			}
			a=a/K;
		}
		for(int j=strlen(s)-1;j>=0;j--)
		{
			printf("%c",s[j]);
		}
	}
	return 0;
}