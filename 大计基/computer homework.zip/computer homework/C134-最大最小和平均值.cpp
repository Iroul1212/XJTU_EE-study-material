#include <stdio.h>
double fun(int a[],int n,int *max,int *min);
int main()
{
	int n;
	int a[200];
	int max,min;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	double arr=fun(a,n,&max,&min);
	printf("%d %d %.6lf",max,min,arr);
	return 0;
}

double fun(int a[],int n,int *max,int *min)
{
	double arr;
	double sum=0;
	*max=a[0];
	*min=a[0];
	for(int i=0;i<n;i++)
	{
		sum=sum+a[i];
		if(a[i]>*max)
		{
			*max=a[i];
		}
		if(a[i]<*min)
		{
			*min=a[i];
		}
	}
	arr=sum/n;
	return arr;
}