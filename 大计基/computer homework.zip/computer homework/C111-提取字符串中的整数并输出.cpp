#include <stdio.h>
#include <string.h>
int main()
{
	char s[100];
	gets(s);
	char a[100][100]={0};
	int b[100]={0};
	int m=0;
	int n=0;
	int t=0;
	int k=0;
	for(int i=1;s[i-1]<'0'||s[i-1]>'9';i++)
	{
		k++;
	}
	for(int i=k;i<strlen(s);i++)
	{
		if(s[i]>='0'&&s[i]<='9')
		{
			a[m][n]=s[i];
		    n++;
		    t++;
		}
		if(s[i]<'0'||s[i]>'9')
		{
			if(s[i+1]>='0'&&s[i+1]<='9')
			{
				m++;
				n=0;
			}
		}
	}
	if(t==0)
	{
		printf("NO");
	}
	else
	{
		for(int i=0;i<=m;i++)
  	    {      
	       int k=1;
		   for(int j=strlen(a[i])-1;j>=0;j--)
		   {
			   b[i]=b[i]+(a[i][j]-'0')*k;
			   k=k*10;
		   }
	    }
	    int flag=0;
	    for(int i=0;i<=m;i++)
	    {   
		    if(flag)
	        {
	            printf(" ");
	        }
	        printf("%d",b[i]);
	        flag=1;
	    }
	    printf("\n");
	    int sum=0;
	    for(int i=0;i<=m;i++)
	        {
		        sum=sum+b[i];
	        }
	    printf("%d",sum);
	    }
	return 0;
}