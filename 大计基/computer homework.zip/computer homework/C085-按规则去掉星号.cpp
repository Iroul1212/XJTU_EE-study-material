#include <stdio.h>
#include <string.h>
int main()
{
	char str[200]={0};
	char str1[200]={0};
	gets(str);
	int i=0;
	int j=strlen(str)-1;
	while(str[i++]=='*');
	while(str[j--]=='*');
	int n=0;
	for(int m=i-1;m<j+2;m++)
	{
		str1[n]=str[m];
		n++;
	}
	printf("%s",str1);
	return 0;
}