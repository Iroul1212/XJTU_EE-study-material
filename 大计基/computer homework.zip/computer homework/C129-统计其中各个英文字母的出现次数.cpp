#include<stdio.h>
#include<string.h>
int main()
{
	char str[200]={0};
	gets(str);
	char cut[26]={0};
	strupr(str);
	for (int i=0; str[i]!=0; i++)
	{
		if (str[i]>='A'&& str[i]<='Z')
		{
			cut[str[i]-'A'] ++;
		}
     }
	printf("%d",cut[0]);
	for (int i=1;i<26;i++)
	{
		printf(",%d",cut[i]);
	}
  return 0;
}
