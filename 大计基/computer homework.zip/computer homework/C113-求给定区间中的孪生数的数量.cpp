#include <stdio.h>
#include <math.h>
int prime(int x);
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int t=0;
	for(int i=m;i<=n-2;i++)
	{
		if(prime(i)&&prime(i+2))
		{
			t++;
		}
	}
	printf("%d",t);
	return 0;
}

int prime(int x)
{
	for(int j=2;j<=(int)sqrt(x);j++)
	{
		if(x%j==0)
		{
			return 0;
			break;
		}
	}
	return 1;	
}