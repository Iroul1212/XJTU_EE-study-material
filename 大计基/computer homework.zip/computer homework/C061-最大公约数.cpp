#include <stdio.h>
int max(int x,int y);
int min(int m,int n);
int tep(int v,int u);
int main()
{
	int a[51];
	int t=0;
	scanf("%d",&a[0]);
	for(int i=1;a[i-1]!=0;i++)
	{
		scanf("%d",&a[i]);
		t++;
	}
	t=t-1;
	int p=tep(max(a[0],a[1]),min(a[0],a[1]));
	for(int i=2;i<=t;i++)
	{
		p=tep(max(p,a[i]),min(p,a[i]));
	}
	printf("%d",p);
	for(int i=0;i<=t;i++)
	{
		printf(" %d",a[i]);
	}
	return 0;
}

int max(int x,int y)
{
	int d;
	if(x>=y) {d=x;}
	else {d=y;}
	return d;
}

int min(int x,int y)
{
	int e;
	if(x<y) {e=x;}
	else {e=y;}
	return e;
}

int tep(int u,int v)
{
	while(v!=0)
	{
		int q=u%v;
		u=v;
		v=q;
	}
	return u;
}