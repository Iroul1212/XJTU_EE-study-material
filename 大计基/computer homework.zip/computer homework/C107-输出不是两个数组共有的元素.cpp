#include <stdio.h>
int main()
{
	int Na,Nb;
	int a[100]={0};
	int b[100]={0};
	int c[100]={0};
	int k=0;
	scanf("%d",&Na);
	for(int i=0;i<Na;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d",&Nb);
	for(int i=0;i<Nb;i++)
	{
		scanf("%d",&b[i]);
	}
	for(int i=0;i<Na;i++)
	{
		int t=0;
		for(int j=0;j<Nb;j++)
		{
			if(a[i]==b[j])
			{
				t++;
			}
		}
		if(t==0)
		{
			c[k]=a[i];
			k++;
		}
	}
	for(int i=0;i<Nb;i++)
	{
	    int t=0;
	    for(int j=0;j<Na;j++)
		{
			if(b[i]==a[j])
			{
				t++;
			}
		}
		if(t==0)
		{
			c[k]=b[i];
			k++;
		}
	}
	int c1;
	for(int i=0;i<k-1;i++)
	{
		for(int j=0;j<k-1;j++)
		{
			if(c[j]>c[j+1])
			{
				c1=c[j];
				c[j]=c[j+1];
				c[j+1]=c1;
			}
		}
	}
	int flag=0;
	for(int i=0;i<k;i++)
	{
		if(flag)
		{
			printf(" ");
		}
		printf("%d",c[i]);
		flag=1;
	}
	return 0;
}