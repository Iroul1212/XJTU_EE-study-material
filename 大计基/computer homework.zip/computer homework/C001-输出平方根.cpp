#include <stdio.h>
#include <math.h>
int main()
{
	int a,b;
	do
	{
	scanf("%d",&a);
 	if(a>1000||a<=0)
	printf("0\n");
    }    
	while (a>1000||a<=0);
	b=sqrt(a);
	printf("%d",b);
	return 0;
}