#include <stdio.h>
int main()
{
	int a[50],b[50];
	int ai,bi;
	scanf("%d\n",&ai);
	for(int i=0;i<ai;i++)
	{
		scanf("%d",&a[i]);
	}
	scanf("%d\n",&bi);
	for(int i=0;i<bi;i++)
	{
		scanf("%d",&b[i]);
	}
	int flag=0;
	int flag1=0;
	for(int i=0;i<ai;i++)
	{
		for(int j=0;j<bi;j++)
		{
			if(a[i]==b[j])
			{
				flag=1;
				for(int k=0;k<i;k++)
				{
					if(a[i]==a[k])
					{
						flag=0;
						break;
					}
				}
				if(flag)
				{
					if(flag1)
					{
						printf(" ");
					}					
					printf("%d",a[i]);
				}
				flag1=1;
			}
		}
	}
	return 0;
}