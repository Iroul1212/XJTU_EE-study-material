#include <stdio.h>
int main()
{
	char m,b,a;
	scanf("%c",&m);
	if(m>='B'&&m<='Y')
	{
		b=m-1;
		a=m+1;
	}
	else if(m=='A')
	{
		b=m+25;
		a=m+1;
	}
	else if(m=='Z')
	{
		b=m-1;
		a=m-25;
	}
	else
	{
	}
    printf("%c%c%c\n",b,m,a);
	return 0;
}