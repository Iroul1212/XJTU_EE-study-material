#include <stdio.h>
int main()
{
	char a,b,c,d,e,f,g,h;
	scanf("%c%c%c%c",&a,&b,&c,&d);
	e=a+1;
	f=b+1;
	g=c+1;
	h=d+1;
	printf("%c %d %c\n",a,a,e);
	printf("%c %d %c\n",b,b,f);
	printf("%c %d %c\n",c,c,g);
	printf("%c %d %c\n",d,d,h);
	return 0;
}