#include <stdio.h>
#include <string.h>
int main()
{
	char str[100]={0};
	gets(str);
	char str1[100]={0};
	int n=strlen(str);
	if(n%2==0)
	{
		for(int i=0;str[i]!=NULL;)
		{
			str1[i]=str[i];
			i=i+2;
		}
		for(int i=1;i<n;)
		{
			str1[i]=str[n-i];
			i=i+2;
		}
	}
	else
	{
		for(int i=0;str[i]!=NULL;)
		{
			str1[i]=str[i];
			i=i+2;
	    }
		for(int i=1;i<n;)
		{
			str1[i]=str[n-i-1];
			i=i+2;
	    }	
    }
	printf("%s",str1);
	return 0;
}