#include <stdio.h>
int main()
{
	int a,n1,n2,n3,n4,b;
	scanf("%d",&a);
	n1=a/1000;
	n2=a/100%10;
	n3=a/10%10;
	n4=a/1%10;
	n1=(n1+5)%10;
	n2=(n2+5)%10;
	n3=(n3+5)%10;
	n4=(n4+5)%10;
	b=1000*n4+100*n3+10*n2+n1;
	printf("%d\n",b);
	return 0;
}