#include <stdio.h>
int main()
{
	float a,b,c,sum;
	int d;
	scanf("%f %f %f",&a,&b,&c);
	sum=a+b+c;
	d=(int)(sum+0.5);
	printf("%g %d\n",sum,d);
	return 0;
}