#include <stdio.h>
int main()
{
	int a,b,c;
	float x;
	scanf("%d %d %d",&a,&b,&c);
	x=(a+b+c);
	x=x/3;
	printf("%g\n",x);
	return 0;
}