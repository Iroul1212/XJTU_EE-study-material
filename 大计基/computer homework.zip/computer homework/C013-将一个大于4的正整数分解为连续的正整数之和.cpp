#include <stdio.h>
int main()
{
	int x;
	scanf("%d",&x);
	int i=1;
	while (i<x)
	{
		int s=0,j=i;
		while (s<x)
		{
			s=s+j;
			if(s==x)
			{
			printf("%d=",x);
			int k=i;
			while (k<=j)
			{
				if(k==j)
				{
					printf("%d\n",k);
				}
				else
				{
					printf("%d+",k);
				}
				k=k+1;
			}
		    }
			j=j+1;
		}
		i=i+1;
	}
	return 0;
}