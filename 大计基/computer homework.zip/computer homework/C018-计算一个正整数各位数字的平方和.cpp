#include <stdio.h>
int main()
{
	int x;
	scanf("%d",&x);
	int sum=0,i=1,k,m;
	while (x>k)
	{
		k=x%i;
		m=x/i%10;
		sum=sum+m*m;
		i=i*10;
	}
	printf("%d\n",sum);
	return 0;
}