#include <stdio.h>
int main()
{
	int Y,N;
	int n=0;
	scanf("%d %d",&Y,&N);
	for(Y;n<N;Y++)
	{
		if((Y%4==0&&Y%100!=0)||(Y%400==0)) n++;
	}
	printf("%d",Y-1);
	return 0;
}