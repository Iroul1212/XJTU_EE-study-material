#include <stdio.h>
int main()
{
    float d,v;
    scanf("%f %f",&d,&v);
    int t=0,i=1;
    while(v>0)
    {
        int k=i;
        while(k>0&&v>0)
        {
            k--;
            v-=d;
            t++;
        }
        if(v>0)
        {
            t++;
        }
        i++;
    } 
    printf("%d",t);
    return 0;
}