#include <stdio.h>
#include <string.h>
int main()
{
	char s[200]={0};
	char c;
	scanf("%s\n%c",&s,&c);
	char*p=strchr(s,c);
	char s1[200]={0};
	int j=0;
	if(p!=NULL)
	{
		for(int i=0;i<strlen(s);i++)
		{
			if(s[i]!=c)
			{
				s1[j]=s[i];
				j++;
			}
		}
		printf("%s",s1);
	}
	else
	{
		printf("NotFound");
	}
	return 0;
}