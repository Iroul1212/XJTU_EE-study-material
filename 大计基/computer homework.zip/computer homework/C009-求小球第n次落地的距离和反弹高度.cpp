#include <stdio.h>
int main()
{
	int n;
	double h=100;
	double s=0;
	scanf("%d",&n);
	for(int i=1;i<n+1;i++)
	{
		s=s+h+h/2;
		h=h/2;
	}
	s=s-h;
	printf("%lf\n%lf",s,h);
	return 0;
}