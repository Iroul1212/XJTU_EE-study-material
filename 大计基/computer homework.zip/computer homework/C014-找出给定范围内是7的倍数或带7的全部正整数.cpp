#include <stdio.h>
int main()
{
	int m,n;
	scanf("%d %d",&m,&n);
	int x=m;
	while (x>=m&&x<=n)
	{
		if(x%7==0)
		{
			printf("%d is a multiple of 7\n",x);
		}
		int i=1,k,a;
		while (x>k)
		{
			k=x%i;
			a=x/i%10;
			if(a==7)
			{
				printf("%d contains 7\n",x);
				break;
			}
			else
			{
				i=i*10;
			}
		}
		x=x+1;
	}
	return 0;
}