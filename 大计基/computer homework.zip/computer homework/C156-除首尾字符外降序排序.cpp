#include <stdio.h>
#include <string.h>
int main()
{
	char input[200]={0};
	scanf("%s",&input);
	int n[200]={0};
	for(int i=1;i<strlen(input)-1;i++)
	{
		n[input[i]]++;
	}
	printf("%c",input[0]);
	for(int i=199;i>=1;i--)
	{
		while(n[i]!=0)
		{
			printf("%c",i);
			n[i]--;
		}
	}
	printf("%c",input[strlen(input)-1]);
	return 0;
}