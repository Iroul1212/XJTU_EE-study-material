#include <stdio.h>
int main()
{
	int a[100]={0};
	int t=0;
	scanf("%d",&a[0]);
	t=t+6*a[0];
	for(int i=1;a[i-1]!=0;i++)
	{
		scanf("%d",&a[i]);
	}
	int i=1;
	for(;a[i-1]!=0;i++)
	{
		int k=a[i]-a[i-1];
		if(k>0)
		{
			t=t+6*k;
		}
		else
		{
			t=t-4*k;
		}
		t=t+5;
	}
	t=t-4*a[i-2];
	printf("%d",t);
	return 0;
}