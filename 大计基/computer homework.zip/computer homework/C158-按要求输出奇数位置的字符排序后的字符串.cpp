#include <stdio.h>
#include <string.h>
int main()
{
	char s[100];
	gets(s);
	int l=strlen(s);
	char s1;
	for(int i=0;i<l-2;i=i+2)
	{
		for(int j=0;j<l-2;j=j+2)
		{
			if(s[j]>s[j+2])
			{
				s1=s[j];
				s[j]=s[j+2];
				s[j+2]=s1;
			}
		}
	}
	puts(s);
	return 0;
}