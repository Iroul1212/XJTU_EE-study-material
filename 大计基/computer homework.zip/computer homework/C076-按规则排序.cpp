#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[200]={0};
	int b[200]={0};
	int a1;
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			if(a[j]>a[j+1])
			{
				a1=a[j];
				a[j]=a[j+1];
				a[j+1]=a1;
			}
		}
    }
    for(int i=0;i<n;i++)
    {
		b[i]=0;
	}
	b[0]=a[0];
    b[((n+1)/2)-1]=a[n-1];
	b[n-1]=a[((n+1)/2)-1];
	int flag=0;
	for(int i=0;i<n;i++)
	{
		if(flag)
		{
			printf(" ");
		}
		printf("%d",b[i]);
		flag=1;
	}
	return 0;
}