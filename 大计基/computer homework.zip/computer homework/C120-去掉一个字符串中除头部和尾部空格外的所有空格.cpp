#include <stdio.h>
#include <string.h>
int main()
{
	char str[100]={0};
	char str1[100]={0};
	gets(str);
	int i=1;
	int j=98;
	int t=strlen(str);
	while(str[i-1]==' ')
	{
		i++;
	}
	while(str[j+1]==' '||str[j+1]==NULL)
	{
		j--;
	}
	for(int k=0;k<i-1;k++)
	{
		str1[k]=str[k];
	}
	int m=i-1;
	int n=i-1;
	while(n>=i-1&&n<=j+1)
	{
		if(str[n]!=' ')
		{
			str1[m]=str[n];
			m++;
		}
		n++;
	}
	for(int k=j+2;str[k]!=NULL;k++)
	{
		str1[m]=str[k];
		m++;
	}
	printf("%s",str1);
	return 0;
}