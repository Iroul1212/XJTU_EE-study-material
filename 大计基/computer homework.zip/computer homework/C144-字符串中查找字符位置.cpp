#include <stdio.h>
#include <string.h>
int main()
{
	char str[100]={0};
	char cstr[100]={0};
	char bstr[100]={0};
	gets(str,100);
	int i=0;
	while(str[i++]!='*');
	int k=0;
	while(k<i)
	{
		bstr[k]=str[k];
		k++;
	}
	int j=0;
	for(;str[i]!=0;j++)
	{
		cstr[j]=str[i];
		i++;
	}
	char*ret=strstr(bstr,cstr);
	if(ret==NULL)
	  printf("-1");
	else
	  printf("%d",ret-bstr);
	return 0;
}