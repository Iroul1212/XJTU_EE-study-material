#include <stdio.h>
#include <math.h>
int main()
{
	int n,t=0;
	float s=0.00,i=1.00;
	scanf("%d",&n);
    while (t<n)
	{
	    s=s+(1/i)*pow(-1,t);
		i=i+2;
		t=t+1;
	}
	printf("%.4f",s);
	return 0;
}