#include <stdio.h>
#include <string.h>
struct psn
{
	char name[200];
	char phn[200];
};
int main()
{
	int n;
	scanf("%d",&n);
	struct psn hmn[200];
	for(int i=0;i<n;i++)
	{
		scanf("%s",&hmn[i].name);
		scanf("%s",&hmn[i].phn);
	}
	struct psn srt;
	for(int i=0;i<n-1;i++)
	{
		for(int j=0;j<n-1;j++)
		{
			if (strcmp(hmn[j].name,hmn[j+1].name)>0)
			{
				srt=hmn[j];
				hmn[j]=hmn[j+1];
				hmn[j+1]=srt;
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		printf("%s ",hmn[i].name);
		printf("%s\n",hmn[i].phn);
	}
	return 0;
}