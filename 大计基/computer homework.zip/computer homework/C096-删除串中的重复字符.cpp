#include <stdio.h>
#include <string.h>
int main()
{
	char str[200]={0};
	gets(str);
	int i,j,k;
	int l=strlen(str);
	for(i=0;i<strlen(str);i++)
	{
		for(j=0;j<i;j++)
		{
			if(str[j]==str[i])
			{
				for(k=i;k<l;k++)
				{
					str[k]=str[k+1];
				}
				i=i-1;
				break;
			}
		}
	}
	puts(str);
	return 0;
}