#include <stdio.h>
#
int main()
{
	int n,a[200],i=1;
	scanf("%d",&n);
	while (i<=n)
	{
		scanf("%d",&a[i]);
		i=i+1;
	}
	if(n>=2)
	{
		int j=0,b;
		while (j<n-1)
		{
			if(a[j]>a[j+1])
			{
				b=a[j];
			    a[j]=a[j+1];
			    a[j+1]=b;
			}			
		    j=j+1;
		}
		int k=1,t=0;
		while (k<=n)
		{
			if(a[k]==a[n-1])
			{
				t=t+1;
			}
		k=k+1;
	    }
	    printf("%d,%d",a[n-1],t);
	}
	else
	{
	    printf("%d,1",a[1]);
    }  
	return 0;
}