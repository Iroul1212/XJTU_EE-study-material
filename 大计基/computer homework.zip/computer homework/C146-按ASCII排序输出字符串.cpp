#include <stdio.h>
#include <string.h>
int main()
{
	char s[105]={0};
	char t[105]={0};
	char a[300]={0};
	char b[300]={0};
	scanf("%s %s",s,t);
	strupr(s);
	strupr(t);
	strcpy(a,s);
	strcat(a,t);
	int k=0;
	for(int i=0;i<strlen(a);i++)
	{
		int t=0;
		for(int j=0;j<i;j++)
		{
			if(a[i]==a[j])
			{
				t++;
			}
		}
		if(t==0)
		{
			b[k]=a[i];
			k++;
		}
	}
	char b1;
	for(int i=0;i<strlen(b)-1;i++)
	{
		for(int j=0;j<strlen(b)-1;j++)
		{
			if(b[j]>b[j+1])
			{
				b1=b[j];
				b[j]=b[j+1];
				b[j+1]=b1;
			}
		}
	}
	for(int i=0;i<strlen(b);i++)
	{
		printf("%c",b[i]);
	}
	return 0;
}