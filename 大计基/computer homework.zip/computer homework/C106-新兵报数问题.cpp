#include <stdio.h>
int main()
{
	int N;
	scanf("%d",&N);
	int a[6000]={0};
	for(int t=N,num=2;t>3;)
	{
		t=0;
		for(int i=0,j=1;i<N;i++)
		{
			if(a[i]==0)
			{
				if(j==num)
				{
					a[i]=-1;
					j=1;
				}
				else
			    {
				    j++;
				    t++;
			    }
			}
		}
		if(num==2)
		{
			num=3;
		}
		else
		{
			num=2;
		}
	}
	int flag=0;
	for(int i=0;i<N;i++)
	{
		if(a[i]==0)
		{
			if(flag)
			{
				printf(" ");
			}
			printf("%d",i+1);
			flag=1;
		}
	}
	return 0;
}