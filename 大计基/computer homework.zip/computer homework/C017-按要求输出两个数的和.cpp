#include <stdio.h>
int main()
{
	int a,b,c,d;
	scanf("%d %d",&a,&b);
	c=a*a+b*b;
	if(c>=100) d=c/100;
	else d=c;
	printf("%d\n",d);
	return 0;
}