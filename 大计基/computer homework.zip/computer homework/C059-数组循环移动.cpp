#include <stdio.h>
void reverse(int A[], int start, int end);
int main()
{
    int n, m;
    scanf("%d %d",&n,&m);
    int A[100];
    for(int i=0;i<n;i++)
    {
        scanf("%d",&A[i]);
    }
    m=m%n;
    reverse(A,0,n-1);
    reverse(A,0,m-1);
    reverse(A,m,n-1);
    for(int i=0;i<n;i++)
    {
        if(i==0)
        {
            printf("%d",A[i]);
        }
        else
        {
            printf(" %d",A[i]);
        }
    }
    return 0;
}

void reverse(int A[], int start, int end)
{
    while(start < end)
    {
        int temp = A[start];
        A[start] = A[end];
        A[end] = temp;
        start++;
        end--;
    }
}
