#include <stdio.h>
#include <string.h>
int main()
{
	char bin[35];
	char bin1[35];
	gets(bin);
	if(strlen(bin)<32)
	{ 
	    for(int i=0;i<32-strlen(bin);i++)
	    {
	    	bin1[i]='0';
		}
		int t=0;
		for(int i=32-strlen(bin);i<32;i++)
		{
			bin1[i]=bin[t];
			t++;
		}
	}
	else
	{
		for(int i=0;i<32;i++)
		bin1[i]=bin[i];
	}
	int j=0;
	for(j;j<32;j++)
	{
		if(bin1[j]!='0'&&bin1[j]!='1')
		{
			printf("该字符串不是正确的IP地址");
			break;
		}
	}
	if(j==32)
	{
		int m=0;
		int num[35];
		for(int i=0;i<32;i++)
		{
			if(bin1[i]=='0')
			{
				num[i]=0;
			}
			else
			{
				num[i]=1;
			}
		}
		int flag=0;
		for(int k=7;k<32;k=k+8)
		{
			m=num[k]+2*num[k-1]+4*num[k-2]+8*num[k-3]+16*num[k-4]+32*num[k-5]+64*num[k-6]+128*num[k-7];
			if(flag)
			printf(".");
			printf("%d",m);
			flag=1;
		}
	}
	return 0;
}