#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	printf("1");
	for(int i=2;i<=n;i++)
	{
		for(;n%i==0;n/=i)
		   printf("*%d",i);
	}
	printf("\n");
	return 0;
}