#include <stdio.h>
#include <string.h>
struct data
{
	char id[50];
	char it[50];
	char ot[20];
};
int main()
{
	int M;
	scanf("%d",&M);
	struct data dk[200];
	for(int i=0;i<M;i++)
	{
		scanf("%s",&dk[i].id);
		scanf("%s",&dk[i].it);
		scanf("%s",&dk[i].ot);
	}
	struct data ft=dk[0];
	struct data lt=dk[0];
	for(int i=0;i<M-1;i++)
	{
		if(strcmp(dk[i].it,dk[i+1].it)>0)
		{
			ft=dk[i+1];
		}
		if(strcmp(dk[i].ot,dk[i+1].ot)<0)
		{
			lt=dk[i+1];
		}
	}
	printf("%s %s",ft.id,lt.id);
	return 0;
}