#include <stdio.h>
int ack(int m,int n);
int main()
{
	int x,y;
	int v;
	scanf("%d %d",&x,&y);
	v=ack(x,y);
	printf("ack(%d,%d)=%d",x,y,v);
	return 0;
}

int ack(int m,int n)
{
	int r;
	if(m==0&&n!=0) {r=n+1;}
    if(n==0&&m!=0) {r=ack(m-1,1);}
    if(m==0&&n==0) {r=1;}
    if(m!=0&&n!=0) {r=ack(m-1,ack(m,n-1));}
    return r;
}