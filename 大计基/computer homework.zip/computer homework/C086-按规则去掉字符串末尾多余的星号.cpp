#include <stdio.h>
#include <string.h>
int main()
{
	char str[200]={0};
	int n;
	scanf("%s %d",&str,&n);
	int cut=strlen(str)-1;
	while(str[cut--]=='*');
	if(strlen(str)-cut-2>n)
		{
			str[cut+2+n]=0;
		}
	printf("%s",str);
	return 0;
}