#include <stdio.h>
int main()
{
	int a,b,c,n1,n2,n3,n4;
	scanf("%d",&a);
	n1=a/100000%10;
	n2=a/10000%10;
	n3=a/1000%10;
	n4=a/100%10;
	b=1000*n1+100*n2+10*n3+1*n4;
	c=b+1024;
	printf("%d %d\n",b,c);
	return 0;
}