#include <stdio.h>
int main()
{
	int t,h,m,s;
	scanf("%d",&t);
	h=t/3600;
	m=(t-3600*h)/60;
	s=t-3600*h-60*m;
	printf("%d:%.2d:%.2d\n", h, m, s);
	return 0;
}