#include <stdio.h>
int main()
{
	int n,k;
	scanf("%d %d",&n,&k);
	int win=0;
	for(int i=1;i<=n;i++)
	{
		win=(win+k)%i;
	}
	printf("%d",win+1);
}