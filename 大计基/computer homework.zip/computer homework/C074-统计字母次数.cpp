#include <stdio.h>
#include <string.h>
int main()
{
	char str[100]={0};
	gets(str);
	int a[26];
	char s[26];
	int a1;
	char s1;
	for(int i=0;i<26;i++)
	{
		s[i]='A'+i;
		a[i]=0;
	}
	strupr(str);
	for(int i=0;i<strlen(str);i++)
	{
		for(int j=0;j<26;j++)
		{
			if(str[i]==s[j])
			{
				a[str[i]-'A']++;
				break;
			}
		}
	}
	int flag=0;
	for(int i=0;i<25;i++)
	{
		for(int j=0;j<25;j++)
		{
			if(a[j]<a[j+1])
			{
				a1=a[j];
				a[j]=a[j+1];
				a[j+1]=a1;
				s1=s[j];
				s[j]=s[j+1];
				s[j+1]=s1;
			}
		}
	}
	for(int i=0;i<26;i++)
	{
		if(flag)
		{
			printf(" ");
		}
		printf("%c-%d",s[i],a[i]);
		flag=1;
	}
	return 0;
}