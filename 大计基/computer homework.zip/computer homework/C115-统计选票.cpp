#include <stdio.h>
int main()
{
	int cut[3]={0};
	int n;
	int t=0;
	scanf("%d",&n);
	while(n!=-1)
	{
		if(n>=1&&n<=3)
		{
			cut[n-1]=cut[n-1]+1;
		}
		else
		{
			t=t+1;
		}
		scanf("%d",&n);
	}
	printf("%d %d %d %d\n",cut[0],cut[1],cut[2],t);
	return 0;
}