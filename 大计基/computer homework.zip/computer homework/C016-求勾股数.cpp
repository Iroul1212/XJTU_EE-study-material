#include <stdio.h>
#include <math.h>
int main()
{
	int a,b,c,m,n,t=0;
	scanf("%d %d",&m,&n);
	a=m;
	while (a>=m&&a<=n)
	{
		b=a+1;
		while (b>=a+1&&b<=n)
		{
			c=b+1;
			while (c>=b+1&&c<=n)
			{
				if(c*c==a*a+b*b)
				{
					t=t+1;
				}
				c=c+1;
			}
			b=b+1;
		}
		a=a+1;
	}
	printf("%d\n",t);
	return 0;
}