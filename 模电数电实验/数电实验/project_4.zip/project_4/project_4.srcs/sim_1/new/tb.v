`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/06 11:09:26
// Design Name: 
// Module Name: tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb();
    reg  a;
    reg  b;
    reg  c;
    reg  m;
    wire y;

    // 实例化顶层模块
    main uut (
        .a(a),
        .b(b),
        .c(c),
        .m(m),
        .y(y)
    );

    initial begin
        a = 0;
        b = 0;
        c = 0;
        m = 0;
    end

    always #150 m = ~m;
    always #10  a = ~a;
    always #20  b = ~b;
    always #40  c = ~c;
endmodule
