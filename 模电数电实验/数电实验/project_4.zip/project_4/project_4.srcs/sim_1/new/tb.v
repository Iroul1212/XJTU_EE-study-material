`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/06 11:09:26
// Design Name: 
// Module Name: tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb();
    reg  a;
    reg  b;
    reg  c;
    reg  m;
    wire y;

    // 实例化顶层模块
    main uut (
        .a(a),
        .b(b),
        .c(c),
        .m(m),
        .y(y)
    );

    initial begin
        // 遍历所有输入组合
        // m = 0 (意见一致功能)
        {m, a, b, c} = 4'b0_000; #10;
        {m, a, b, c} = 4'b0_001; #10;
        {m, a, b, c} = 4'b0_010; #10;
        {m, a, b, c} = 4'b0_011; #10;
        {m, a, b, c} = 4'b0_100; #10;
        {m, a, b, c} = 4'b0_101; #10;
        {m, a, b, c} = 4'b0_110; #10;
        {m, a, b, c} = 4'b0_111; #10;

        // m = 1 (多数表决功能)
        {m, a, b, c} = 4'b1_000; #10;
        {m, a, b, c} = 4'b1_001; #10;
        {m, a, b, c} = 4'b1_010; #10;
        {m, a, b, c} = 4'b1_011; #10;
        {m, a, b, c} = 4'b1_100; #10;
        {m, a, b, c} = 4'b1_101; #10;
        {m, a, b, c} = 4'b1_110; #10;
        {m, a, b, c} = 4'b1_111; #10;
    end
endmodule
