`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/04/06 10:55:09
// Design Name: 
// Module Name: main
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module main(
    input  a,
    input  b,
    input  c,
    input  m,
    output y
);
    wire y_mv;
    wire y_uc;
    
    // 实例化多数表决器
    majority_voter mv (
        .a(a),
        .b(b),
        .c(c),
        .y(y_mv)
    );

    // 实例化一致性检查器
    unanimity_checker uc (
        .a(a),
        .b(b),
        .c(c),
        .y(y_uc)
    );

    assign y = (m) ? y_mv : y_uc; // 根据模式选择输出
endmodule
