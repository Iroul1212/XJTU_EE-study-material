module unanimity_checker (
    input  a,
    input  b,
    input  c,
    output y
);
    assign y = (a & b & c) | (~a & ~b & ~c);
endmodule