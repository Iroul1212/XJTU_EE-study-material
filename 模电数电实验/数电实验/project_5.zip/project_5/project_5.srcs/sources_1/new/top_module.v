module top_module (
    input wire clk,
    input wire rst_n,
    output wire [7:0] x,
    output wire [3:0] seg_an,
    output wire [6:0] seg_out
);
    wire w;

    // 实例化秒脉冲产生器
    sec_pulse u1_sec_pulse (
        .clk(clk),
        .rst_n(rst_n),
        .pulse_out(w)
    );

    // 实例化模60计数器
    cnt60 u2_cnt60 (
        .clk(clk),
        .rst_n(rst_n),
        .pulse_in(w),
        .x(x)
    );

    // 实例化数码管驱动
    seg_driver u3_seg_driver (
        .clk(clk),
        .rst_n(rst_n),
        .bcd_data(x),
        .seg_an(seg_an),
        .seg_out(seg_out)
    );

endmodule