module top_module (
    input wire clk,
    input wire rst_n,
    output wire [7:0] x,
    output wire [3:0] seg_an,
    output wire [6:0] seg_out
);
    wire w;
    wire [7:0] sec_bcd;
    wire [7:0] min_bcd;
    wire min_pulse;

    // 实例化秒脉冲产生器
    sec_pulse u1_sec_pulse (
        .clk(clk),
        .rst_n(rst_n),
        .pulse_out(w)
    );

    // 实例化模60计数器
    cnt60 u2_cnt60 (
        .clk(clk),
        .rst_n(rst_n),
        .pulse_in(w),
        .x(sec_bcd)
    );

    // 产生分钟进位脉冲
    assign min_pulse = w & (sec_bcd == 8'h59);

    // 实例化分钟模60计数器
    cnt60 u3_cnt60_min (
        .clk(clk),
        .rst_n(rst_n),
        .pulse_in(min_pulse),
        .x(min_bcd)
    );

    // LED继续显示秒
    assign x = sec_bcd;

    // 实例化数码管驱动
    seg_driver u4_seg_driver (
        .clk(clk),
        .rst_n(rst_n),
        .bcd_data(min_bcd),
        .seg_an(seg_an),
        .seg_out(seg_out)
    );

endmodule