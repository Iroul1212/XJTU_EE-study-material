module cnt60 (
    input wire clk,
    input wire rst_n,
    input wire pulse_in,
    output wire [7:0] x
);
    reg [3:0] units;
    reg [3:0] tens;

    assign x = {tens, units};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            units <= 4'd0;
            tens  <= 4'd0;
        end else if (pulse_in) begin
            if (units == 4'd9) begin
                units <= 4'd0;
                if (tens == 4'd5)
                    tens <= 4'd0;
                else
                    tens <= tens + 1'b1;
            end else begin
                units <= units + 1'b1;
            end
        end
    end
endmodule