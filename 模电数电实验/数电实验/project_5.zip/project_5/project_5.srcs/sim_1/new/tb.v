`timescale 1ns / 1ps

module tb_top();
    reg clk;
    reg rst_n;
    wire [7:0] x;

    top_module #(.CNT_MAX(49)) dut (
        .clk(clk),
        .rst_n(rst_n),
        .x(x)
    );

    initial clk = 0;
    always #10 clk = ~clk;

    initial begin
        rst_n = 0;
        #100 rst_n = 1;
    end
endmodule