// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2025.2 (win64) Build 6299465 Fri Nov 14 19:35:11 GMT 2025
// Date        : Sat Apr 11 16:33:28 2026
// Host        : Iroul-Laptop running 64-bit major release  (build 9200)
// Command     : write_verilog -mode timesim -nolib -sdf_anno true -force -file
//               D:/DigitalCircuitExperiment/FPGA/project_5/project_5.sim/sim_1/impl/timing/xsim/tb_top_time_impl.v
// Design      : top_module
// Purpose     : This verilog netlist is a timing simulation representation of the design and should not be modified or
//               synthesized. Please ensure that this netlist is used with the corresponding SDF file.
// Device      : xc7a35tcsg324-1
// --------------------------------------------------------------------------------
`timescale 1 ps / 1 ps
`define XIL_TIMING

module cnt60
   (x_OBUF,
    E,
    CLK,
    \units_reg[3]_0 );
  output [7:0]x_OBUF;
  input [0:0]E;
  input CLK;
  input \units_reg[3]_0 ;

  wire CLK;
  wire [0:0]E;
  wire [3:1]p_0_in;
  wire [0:0]tens;
  wire \tens[0]_i_1_n_0 ;
  wire \tens[1]_i_1_n_0 ;
  wire \tens[2]_i_1_n_0 ;
  wire \tens[3]_i_2_n_0 ;
  wire \units[0]_i_1_n_0 ;
  wire \units_reg[3]_0 ;
  wire [7:0]x_OBUF;

  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \tens[0]_i_1 
       (.I0(x_OBUF[4]),
        .O(\tens[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h5A52)) 
    \tens[1]_i_1 
       (.I0(x_OBUF[4]),
        .I1(x_OBUF[6]),
        .I2(x_OBUF[5]),
        .I3(x_OBUF[7]),
        .O(\tens[1]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair3" *) 
  LUT4 #(
    .INIT(16'h6C64)) 
    \tens[2]_i_1 
       (.I0(x_OBUF[4]),
        .I1(x_OBUF[6]),
        .I2(x_OBUF[5]),
        .I3(x_OBUF[7]),
        .O(\tens[2]_i_1_n_0 ));
  LUT5 #(
    .INIT(32'h00000080)) 
    \tens[3]_i_1 
       (.I0(E),
        .I1(x_OBUF[3]),
        .I2(x_OBUF[0]),
        .I3(x_OBUF[2]),
        .I4(x_OBUF[1]),
        .O(tens));
  (* SOFT_HLUTNM = "soft_lutpair2" *) 
  LUT4 #(
    .INIT(16'h7F80)) 
    \tens[3]_i_2 
       (.I0(x_OBUF[4]),
        .I1(x_OBUF[6]),
        .I2(x_OBUF[5]),
        .I3(x_OBUF[7]),
        .O(\tens[3]_i_2_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \tens_reg[0] 
       (.C(CLK),
        .CE(tens),
        .CLR(\units_reg[3]_0 ),
        .D(\tens[0]_i_1_n_0 ),
        .Q(x_OBUF[4]));
  FDCE #(
    .INIT(1'b0)) 
    \tens_reg[1] 
       (.C(CLK),
        .CE(tens),
        .CLR(\units_reg[3]_0 ),
        .D(\tens[1]_i_1_n_0 ),
        .Q(x_OBUF[5]));
  FDCE #(
    .INIT(1'b0)) 
    \tens_reg[2] 
       (.C(CLK),
        .CE(tens),
        .CLR(\units_reg[3]_0 ),
        .D(\tens[2]_i_1_n_0 ),
        .Q(x_OBUF[6]));
  FDCE #(
    .INIT(1'b0)) 
    \tens_reg[3] 
       (.C(CLK),
        .CE(tens),
        .CLR(\units_reg[3]_0 ),
        .D(\tens[3]_i_2_n_0 ),
        .Q(x_OBUF[7]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \units[0]_i_1 
       (.I0(x_OBUF[0]),
        .O(\units[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h5A52)) 
    \units[1]_i_1 
       (.I0(x_OBUF[0]),
        .I1(x_OBUF[3]),
        .I2(x_OBUF[1]),
        .I3(x_OBUF[2]),
        .O(p_0_in[1]));
  (* SOFT_HLUTNM = "soft_lutpair4" *) 
  LUT3 #(
    .INIT(8'h78)) 
    \units[2]_i_1 
       (.I0(x_OBUF[0]),
        .I1(x_OBUF[1]),
        .I2(x_OBUF[2]),
        .O(p_0_in[2]));
  (* SOFT_HLUTNM = "soft_lutpair1" *) 
  LUT4 #(
    .INIT(16'h6CC4)) 
    \units[3]_i_1 
       (.I0(x_OBUF[0]),
        .I1(x_OBUF[3]),
        .I2(x_OBUF[1]),
        .I3(x_OBUF[2]),
        .O(p_0_in[3]));
  FDCE #(
    .INIT(1'b0)) 
    \units_reg[0] 
       (.C(CLK),
        .CE(E),
        .CLR(\units_reg[3]_0 ),
        .D(\units[0]_i_1_n_0 ),
        .Q(x_OBUF[0]));
  FDCE #(
    .INIT(1'b0)) 
    \units_reg[1] 
       (.C(CLK),
        .CE(E),
        .CLR(\units_reg[3]_0 ),
        .D(p_0_in[1]),
        .Q(x_OBUF[1]));
  FDCE #(
    .INIT(1'b0)) 
    \units_reg[2] 
       (.C(CLK),
        .CE(E),
        .CLR(\units_reg[3]_0 ),
        .D(p_0_in[2]),
        .Q(x_OBUF[2]));
  FDCE #(
    .INIT(1'b0)) 
    \units_reg[3] 
       (.C(CLK),
        .CE(E),
        .CLR(\units_reg[3]_0 ),
        .D(p_0_in[3]),
        .Q(x_OBUF[3]));
endmodule

module sec_pulse
   (E,
    rst_n,
    CLK,
    rst_n_IBUF);
  output [0:0]E;
  output rst_n;
  input CLK;
  input rst_n_IBUF;

  wire CLK;
  wire [0:0]E;
  wire [31:0]cnt;
  wire cnt0_carry__0_n_0;
  wire cnt0_carry__1_n_0;
  wire cnt0_carry__2_n_0;
  wire cnt0_carry__3_n_0;
  wire cnt0_carry__4_n_0;
  wire cnt0_carry__5_n_0;
  wire cnt0_carry_n_0;
  wire \cnt[31]_i_2_n_0 ;
  wire \cnt[31]_i_3_n_0 ;
  wire \cnt[31]_i_4_n_0 ;
  wire \cnt[31]_i_5_n_0 ;
  wire \cnt[31]_i_6_n_0 ;
  wire \cnt[31]_i_7_n_0 ;
  wire \cnt[31]_i_8_n_0 ;
  wire \cnt[31]_i_9_n_0 ;
  wire [31:0]cnt_0;
  wire [31:1]data0;
  wire pulse_out;
  wire rst_n;
  wire rst_n_IBUF;
  wire [2:0]NLW_cnt0_carry_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0_carry__0_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0_carry__1_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0_carry__2_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0_carry__3_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0_carry__4_CO_UNCONNECTED;
  wire [2:0]NLW_cnt0_carry__5_CO_UNCONNECTED;
  wire [3:0]NLW_cnt0_carry__6_CO_UNCONNECTED;
  wire [3:3]NLW_cnt0_carry__6_O_UNCONNECTED;

  LUT1 #(
    .INIT(2'h1)) 
    \FSM_sequential_seg_an[1]_i_2 
       (.I0(rst_n_IBUF),
        .O(rst_n));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry
       (.CI(1'b0),
        .CO({cnt0_carry_n_0,NLW_cnt0_carry_CO_UNCONNECTED[2:0]}),
        .CYINIT(cnt[0]),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[4:1]),
        .S(cnt[4:1]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__0
       (.CI(cnt0_carry_n_0),
        .CO({cnt0_carry__0_n_0,NLW_cnt0_carry__0_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[8:5]),
        .S(cnt[8:5]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__1
       (.CI(cnt0_carry__0_n_0),
        .CO({cnt0_carry__1_n_0,NLW_cnt0_carry__1_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[12:9]),
        .S(cnt[12:9]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__2
       (.CI(cnt0_carry__1_n_0),
        .CO({cnt0_carry__2_n_0,NLW_cnt0_carry__2_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[16:13]),
        .S(cnt[16:13]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__3
       (.CI(cnt0_carry__2_n_0),
        .CO({cnt0_carry__3_n_0,NLW_cnt0_carry__3_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[20:17]),
        .S(cnt[20:17]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__4
       (.CI(cnt0_carry__3_n_0),
        .CO({cnt0_carry__4_n_0,NLW_cnt0_carry__4_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[24:21]),
        .S(cnt[24:21]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__5
       (.CI(cnt0_carry__4_n_0),
        .CO({cnt0_carry__5_n_0,NLW_cnt0_carry__5_CO_UNCONNECTED[2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O(data0[28:25]),
        .S(cnt[28:25]));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 cnt0_carry__6
       (.CI(cnt0_carry__5_n_0),
        .CO(NLW_cnt0_carry__6_CO_UNCONNECTED[3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({NLW_cnt0_carry__6_O_UNCONNECTED[3],data0[31:29]}),
        .S({1'b0,cnt[31:29]}));
  LUT1 #(
    .INIT(2'h1)) 
    \cnt[0]_i_1 
       (.I0(cnt[0]),
        .O(cnt_0[0]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[10]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[10]),
        .O(cnt_0[10]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[11]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[11]),
        .O(cnt_0[11]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[12]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[12]),
        .O(cnt_0[12]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[13]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[13]),
        .O(cnt_0[13]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[14]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[14]),
        .O(cnt_0[14]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[15]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[15]),
        .O(cnt_0[15]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[16]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[16]),
        .O(cnt_0[16]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[17]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[17]),
        .O(cnt_0[17]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[18]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[18]),
        .O(cnt_0[18]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[19]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[19]),
        .O(cnt_0[19]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[1]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[1]),
        .O(cnt_0[1]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[20]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[20]),
        .O(cnt_0[20]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[21]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[21]),
        .O(cnt_0[21]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[22]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[22]),
        .O(cnt_0[22]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[23]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[23]),
        .O(cnt_0[23]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[24]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[24]),
        .O(cnt_0[24]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[25]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[25]),
        .O(cnt_0[25]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[26]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[26]),
        .O(cnt_0[26]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[27]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[27]),
        .O(cnt_0[27]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[28]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[28]),
        .O(cnt_0[28]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[29]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[29]),
        .O(cnt_0[29]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[2]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[2]),
        .O(cnt_0[2]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[30]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[30]),
        .O(cnt_0[30]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[31]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[31]),
        .O(cnt_0[31]));
  LUT5 #(
    .INIT(32'hFFFFFBFF)) 
    \cnt[31]_i_2 
       (.I0(cnt[18]),
        .I1(cnt[19]),
        .I2(cnt[16]),
        .I3(cnt[17]),
        .I4(\cnt[31]_i_6_n_0 ),
        .O(\cnt[31]_i_2_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFEFF)) 
    \cnt[31]_i_3 
       (.I0(cnt[26]),
        .I1(cnt[27]),
        .I2(cnt[24]),
        .I3(cnt[25]),
        .I4(\cnt[31]_i_7_n_0 ),
        .O(\cnt[31]_i_3_n_0 ));
  LUT5 #(
    .INIT(32'hFFFF7FFF)) 
    \cnt[31]_i_4 
       (.I0(cnt[2]),
        .I1(cnt[3]),
        .I2(cnt[0]),
        .I3(cnt[1]),
        .I4(\cnt[31]_i_8_n_0 ),
        .O(\cnt[31]_i_4_n_0 ));
  LUT5 #(
    .INIT(32'hFFFFFFFE)) 
    \cnt[31]_i_5 
       (.I0(cnt[10]),
        .I1(cnt[11]),
        .I2(cnt[8]),
        .I3(cnt[9]),
        .I4(\cnt[31]_i_9_n_0 ),
        .O(\cnt[31]_i_5_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \cnt[31]_i_6 
       (.I0(cnt[21]),
        .I1(cnt[20]),
        .I2(cnt[23]),
        .I3(cnt[22]),
        .O(\cnt[31]_i_6_n_0 ));
  LUT4 #(
    .INIT(16'hFFFE)) 
    \cnt[31]_i_7 
       (.I0(cnt[29]),
        .I1(cnt[28]),
        .I2(cnt[31]),
        .I3(cnt[30]),
        .O(\cnt[31]_i_7_n_0 ));
  LUT4 #(
    .INIT(16'hFF7F)) 
    \cnt[31]_i_8 
       (.I0(cnt[5]),
        .I1(cnt[4]),
        .I2(cnt[6]),
        .I3(cnt[7]),
        .O(\cnt[31]_i_8_n_0 ));
  LUT4 #(
    .INIT(16'h7FFF)) 
    \cnt[31]_i_9 
       (.I0(cnt[13]),
        .I1(cnt[12]),
        .I2(cnt[15]),
        .I3(cnt[14]),
        .O(\cnt[31]_i_9_n_0 ));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[3]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[3]),
        .O(cnt_0[3]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[4]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[4]),
        .O(cnt_0[4]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[5]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[5]),
        .O(cnt_0[5]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[6]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[6]),
        .O(cnt_0[6]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[7]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[7]),
        .O(cnt_0[7]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[8]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[8]),
        .O(cnt_0[8]));
  LUT5 #(
    .INIT(32'hFFFE0000)) 
    \cnt[9]_i_1 
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .I4(data0[9]),
        .O(cnt_0[9]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[0]),
        .Q(cnt[0]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[10]),
        .Q(cnt[10]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[11]),
        .Q(cnt[11]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[12]),
        .Q(cnt[12]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[13]),
        .Q(cnt[13]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[14]),
        .Q(cnt[14]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[15]),
        .Q(cnt[15]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[16] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[16]),
        .Q(cnt[16]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[17] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[17]),
        .Q(cnt[17]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[18] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[18]),
        .Q(cnt[18]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[19] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[19]),
        .Q(cnt[19]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[1]),
        .Q(cnt[1]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[20] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[20]),
        .Q(cnt[20]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[21] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[21]),
        .Q(cnt[21]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[22] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[22]),
        .Q(cnt[22]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[23] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[23]),
        .Q(cnt[23]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[24] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[24]),
        .Q(cnt[24]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[25] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[25]),
        .Q(cnt[25]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[26] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[26]),
        .Q(cnt[26]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[27] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[27]),
        .Q(cnt[27]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[28] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[28]),
        .Q(cnt[28]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[29] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[29]),
        .Q(cnt[29]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[2]),
        .Q(cnt[2]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[30] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[30]),
        .Q(cnt[30]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[31] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[31]),
        .Q(cnt[31]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[3]),
        .Q(cnt[3]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[4]),
        .Q(cnt[4]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[5]),
        .Q(cnt[5]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[6]),
        .Q(cnt[6]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[7]),
        .Q(cnt[7]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[8]),
        .Q(cnt[8]));
  FDCE #(
    .INIT(1'b0)) 
    \cnt_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(cnt_0[9]),
        .Q(cnt[9]));
  (* SOFT_HLUTNM = "soft_lutpair0" *) 
  LUT4 #(
    .INIT(16'h0001)) 
    pulse_out_i_1
       (.I0(\cnt[31]_i_2_n_0 ),
        .I1(\cnt[31]_i_3_n_0 ),
        .I2(\cnt[31]_i_4_n_0 ),
        .I3(\cnt[31]_i_5_n_0 ),
        .O(pulse_out));
  FDCE #(
    .INIT(1'b0)) 
    pulse_out_reg
       (.C(CLK),
        .CE(1'b1),
        .CLR(rst_n),
        .D(pulse_out),
        .Q(E));
endmodule

module seg_driver
   (seg_an_OBUF,
    seg_out_OBUF,
    CLK,
    \scan_cnt_reg[15]_0 ,
    x_OBUF);
  output [2:0]seg_an_OBUF;
  output [6:0]seg_out_OBUF;
  input CLK;
  input \scan_cnt_reg[15]_0 ;
  input [7:0]x_OBUF;

  wire CLK;
  wire \FSM_sequential_seg_an[0]_i_1_n_0 ;
  wire \FSM_sequential_seg_an[1]_i_1_n_0 ;
  wire [3:0]current_digit;
  wire [3:0]current_digit_0;
  wire scan_clk;
  wire \scan_cnt[0]_i_2_n_0 ;
  wire \scan_cnt_reg[0]_i_1_n_0 ;
  wire \scan_cnt_reg[0]_i_1_n_4 ;
  wire \scan_cnt_reg[0]_i_1_n_5 ;
  wire \scan_cnt_reg[0]_i_1_n_6 ;
  wire \scan_cnt_reg[0]_i_1_n_7 ;
  wire \scan_cnt_reg[12]_i_1_n_4 ;
  wire \scan_cnt_reg[12]_i_1_n_5 ;
  wire \scan_cnt_reg[12]_i_1_n_6 ;
  wire \scan_cnt_reg[12]_i_1_n_7 ;
  wire \scan_cnt_reg[15]_0 ;
  wire \scan_cnt_reg[4]_i_1_n_0 ;
  wire \scan_cnt_reg[4]_i_1_n_4 ;
  wire \scan_cnt_reg[4]_i_1_n_5 ;
  wire \scan_cnt_reg[4]_i_1_n_6 ;
  wire \scan_cnt_reg[4]_i_1_n_7 ;
  wire \scan_cnt_reg[8]_i_1_n_0 ;
  wire \scan_cnt_reg[8]_i_1_n_4 ;
  wire \scan_cnt_reg[8]_i_1_n_5 ;
  wire \scan_cnt_reg[8]_i_1_n_6 ;
  wire \scan_cnt_reg[8]_i_1_n_7 ;
  wire \scan_cnt_reg_n_0_[0] ;
  wire \scan_cnt_reg_n_0_[10] ;
  wire \scan_cnt_reg_n_0_[11] ;
  wire \scan_cnt_reg_n_0_[12] ;
  wire \scan_cnt_reg_n_0_[13] ;
  wire \scan_cnt_reg_n_0_[14] ;
  wire \scan_cnt_reg_n_0_[1] ;
  wire \scan_cnt_reg_n_0_[2] ;
  wire \scan_cnt_reg_n_0_[3] ;
  wire \scan_cnt_reg_n_0_[4] ;
  wire \scan_cnt_reg_n_0_[5] ;
  wire \scan_cnt_reg_n_0_[6] ;
  wire \scan_cnt_reg_n_0_[7] ;
  wire \scan_cnt_reg_n_0_[8] ;
  wire \scan_cnt_reg_n_0_[9] ;
  wire [2:0]seg_an_OBUF;
  wire [1:0]seg_an__0;
  wire [6:0]seg_out_OBUF;
  wire [7:0]x_OBUF;
  wire [2:0]\NLW_scan_cnt_reg[0]_i_1_CO_UNCONNECTED ;
  wire [3:0]\NLW_scan_cnt_reg[12]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_scan_cnt_reg[4]_i_1_CO_UNCONNECTED ;
  wire [2:0]\NLW_scan_cnt_reg[8]_i_1_CO_UNCONNECTED ;

  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT2 #(
    .INIT(4'hB)) 
    \FSM_sequential_seg_an[0]_i_1 
       (.I0(seg_an__0[1]),
        .I1(seg_an__0[0]),
        .O(\FSM_sequential_seg_an[0]_i_1_n_0 ));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT2 #(
    .INIT(4'h2)) 
    \FSM_sequential_seg_an[1]_i_1 
       (.I0(seg_an__0[0]),
        .I1(seg_an__0[1]),
        .O(\FSM_sequential_seg_an[1]_i_1_n_0 ));
  (* FSM_ENCODED_STATES = "iSTATE:10,iSTATE0:01,iSTATE1:00" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_seg_an_reg[0] 
       (.C(scan_clk),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\FSM_sequential_seg_an[0]_i_1_n_0 ),
        .Q(seg_an__0[0]));
  (* FSM_ENCODED_STATES = "iSTATE:10,iSTATE0:01,iSTATE1:00" *) 
  FDCE #(
    .INIT(1'b0)) 
    \FSM_sequential_seg_an_reg[1] 
       (.C(scan_clk),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\FSM_sequential_seg_an[1]_i_1_n_0 ),
        .Q(seg_an__0[1]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \current_digit[0]_i_1 
       (.I0(x_OBUF[4]),
        .I1(seg_an__0[0]),
        .I2(seg_an__0[1]),
        .I3(x_OBUF[0]),
        .O(current_digit_0[0]));
  (* SOFT_HLUTNM = "soft_lutpair9" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \current_digit[1]_i_1 
       (.I0(x_OBUF[5]),
        .I1(seg_an__0[0]),
        .I2(seg_an__0[1]),
        .I3(x_OBUF[1]),
        .O(current_digit_0[1]));
  (* SOFT_HLUTNM = "soft_lutpair10" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \current_digit[2]_i_1 
       (.I0(x_OBUF[6]),
        .I1(seg_an__0[0]),
        .I2(seg_an__0[1]),
        .I3(x_OBUF[2]),
        .O(current_digit_0[2]));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT4 #(
    .INIT(16'hFB08)) 
    \current_digit[3]_i_1 
       (.I0(x_OBUF[7]),
        .I1(seg_an__0[0]),
        .I2(seg_an__0[1]),
        .I3(x_OBUF[3]),
        .O(current_digit_0[3]));
  FDCE #(
    .INIT(1'b0)) 
    \current_digit_reg[0] 
       (.C(scan_clk),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(current_digit_0[0]),
        .Q(current_digit[0]));
  FDCE #(
    .INIT(1'b0)) 
    \current_digit_reg[1] 
       (.C(scan_clk),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(current_digit_0[1]),
        .Q(current_digit[1]));
  FDCE #(
    .INIT(1'b0)) 
    \current_digit_reg[2] 
       (.C(scan_clk),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(current_digit_0[2]),
        .Q(current_digit[2]));
  FDCE #(
    .INIT(1'b0)) 
    \current_digit_reg[3] 
       (.C(scan_clk),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(current_digit_0[3]),
        .Q(current_digit[3]));
  LUT1 #(
    .INIT(2'h1)) 
    \scan_cnt[0]_i_2 
       (.I0(\scan_cnt_reg_n_0_[0] ),
        .O(\scan_cnt[0]_i_2_n_0 ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[0] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[0]_i_1_n_7 ),
        .Q(\scan_cnt_reg_n_0_[0] ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \scan_cnt_reg[0]_i_1 
       (.CI(1'b0),
        .CO({\scan_cnt_reg[0]_i_1_n_0 ,\NLW_scan_cnt_reg[0]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b1}),
        .O({\scan_cnt_reg[0]_i_1_n_4 ,\scan_cnt_reg[0]_i_1_n_5 ,\scan_cnt_reg[0]_i_1_n_6 ,\scan_cnt_reg[0]_i_1_n_7 }),
        .S({\scan_cnt_reg_n_0_[3] ,\scan_cnt_reg_n_0_[2] ,\scan_cnt_reg_n_0_[1] ,\scan_cnt[0]_i_2_n_0 }));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[10] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[8]_i_1_n_5 ),
        .Q(\scan_cnt_reg_n_0_[10] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[11] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[8]_i_1_n_4 ),
        .Q(\scan_cnt_reg_n_0_[11] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[12] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[12]_i_1_n_7 ),
        .Q(\scan_cnt_reg_n_0_[12] ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \scan_cnt_reg[12]_i_1 
       (.CI(\scan_cnt_reg[8]_i_1_n_0 ),
        .CO(\NLW_scan_cnt_reg[12]_i_1_CO_UNCONNECTED [3:0]),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\scan_cnt_reg[12]_i_1_n_4 ,\scan_cnt_reg[12]_i_1_n_5 ,\scan_cnt_reg[12]_i_1_n_6 ,\scan_cnt_reg[12]_i_1_n_7 }),
        .S({scan_clk,\scan_cnt_reg_n_0_[14] ,\scan_cnt_reg_n_0_[13] ,\scan_cnt_reg_n_0_[12] }));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[13] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[12]_i_1_n_6 ),
        .Q(\scan_cnt_reg_n_0_[13] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[14] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[12]_i_1_n_5 ),
        .Q(\scan_cnt_reg_n_0_[14] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[15] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[12]_i_1_n_4 ),
        .Q(scan_clk));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[1] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[0]_i_1_n_6 ),
        .Q(\scan_cnt_reg_n_0_[1] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[2] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[0]_i_1_n_5 ),
        .Q(\scan_cnt_reg_n_0_[2] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[3] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[0]_i_1_n_4 ),
        .Q(\scan_cnt_reg_n_0_[3] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[4] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[4]_i_1_n_7 ),
        .Q(\scan_cnt_reg_n_0_[4] ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \scan_cnt_reg[4]_i_1 
       (.CI(\scan_cnt_reg[0]_i_1_n_0 ),
        .CO({\scan_cnt_reg[4]_i_1_n_0 ,\NLW_scan_cnt_reg[4]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\scan_cnt_reg[4]_i_1_n_4 ,\scan_cnt_reg[4]_i_1_n_5 ,\scan_cnt_reg[4]_i_1_n_6 ,\scan_cnt_reg[4]_i_1_n_7 }),
        .S({\scan_cnt_reg_n_0_[7] ,\scan_cnt_reg_n_0_[6] ,\scan_cnt_reg_n_0_[5] ,\scan_cnt_reg_n_0_[4] }));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[5] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[4]_i_1_n_6 ),
        .Q(\scan_cnt_reg_n_0_[5] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[6] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[4]_i_1_n_5 ),
        .Q(\scan_cnt_reg_n_0_[6] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[7] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[4]_i_1_n_4 ),
        .Q(\scan_cnt_reg_n_0_[7] ));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[8] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[8]_i_1_n_7 ),
        .Q(\scan_cnt_reg_n_0_[8] ));
  (* ADDER_THRESHOLD = "35" *) 
  CARRY4 \scan_cnt_reg[8]_i_1 
       (.CI(\scan_cnt_reg[4]_i_1_n_0 ),
        .CO({\scan_cnt_reg[8]_i_1_n_0 ,\NLW_scan_cnt_reg[8]_i_1_CO_UNCONNECTED [2:0]}),
        .CYINIT(1'b0),
        .DI({1'b0,1'b0,1'b0,1'b0}),
        .O({\scan_cnt_reg[8]_i_1_n_4 ,\scan_cnt_reg[8]_i_1_n_5 ,\scan_cnt_reg[8]_i_1_n_6 ,\scan_cnt_reg[8]_i_1_n_7 }),
        .S({\scan_cnt_reg_n_0_[11] ,\scan_cnt_reg_n_0_[10] ,\scan_cnt_reg_n_0_[9] ,\scan_cnt_reg_n_0_[8] }));
  FDCE #(
    .INIT(1'b0)) 
    \scan_cnt_reg[9] 
       (.C(CLK),
        .CE(1'b1),
        .CLR(\scan_cnt_reg[15]_0 ),
        .D(\scan_cnt_reg[8]_i_1_n_6 ),
        .Q(\scan_cnt_reg_n_0_[9] ));
  (* SOFT_HLUTNM = "soft_lutpair11" *) 
  LUT1 #(
    .INIT(2'h1)) 
    \seg_an_OBUF[0]_inst_i_1 
       (.I0(seg_an__0[0]),
        .O(seg_an_OBUF[0]));
  LUT1 #(
    .INIT(2'h1)) 
    \seg_an_OBUF[1]_inst_i_1 
       (.I0(seg_an__0[1]),
        .O(seg_an_OBUF[1]));
  (* SOFT_HLUTNM = "soft_lutpair8" *) 
  LUT2 #(
    .INIT(4'h7)) 
    \seg_an_OBUF[3]_inst_i_1 
       (.I0(seg_an__0[0]),
        .I1(seg_an__0[1]),
        .O(seg_an_OBUF[2]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hEAA5)) 
    \seg_out_OBUF[0]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[0]),
        .I2(current_digit[2]),
        .I3(current_digit[1]),
        .O(seg_out_OBUF[0]));
  (* SOFT_HLUTNM = "soft_lutpair5" *) 
  LUT4 #(
    .INIT(16'hFB98)) 
    \seg_out_OBUF[1]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[2]),
        .I2(current_digit[0]),
        .I3(current_digit[1]),
        .O(seg_out_OBUF[1]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hFFB8)) 
    \seg_out_OBUF[2]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[1]),
        .I2(current_digit[2]),
        .I3(current_digit[0]),
        .O(seg_out_OBUF[2]));
  (* SOFT_HLUTNM = "soft_lutpair6" *) 
  LUT4 #(
    .INIT(16'hEA9C)) 
    \seg_out_OBUF[3]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[2]),
        .I2(current_digit[0]),
        .I3(current_digit[1]),
        .O(seg_out_OBUF[3]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hAAB0)) 
    \seg_out_OBUF[4]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[0]),
        .I2(current_digit[1]),
        .I3(current_digit[2]),
        .O(seg_out_OBUF[4]));
  (* SOFT_HLUTNM = "soft_lutpair7" *) 
  LUT4 #(
    .INIT(16'hAEC8)) 
    \seg_out_OBUF[5]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[2]),
        .I2(current_digit[0]),
        .I3(current_digit[1]),
        .O(seg_out_OBUF[5]));
  LUT4 #(
    .INIT(16'hAA9C)) 
    \seg_out_OBUF[6]_inst_i_1 
       (.I0(current_digit[3]),
        .I1(current_digit[2]),
        .I2(current_digit[0]),
        .I3(current_digit[1]),
        .O(seg_out_OBUF[6]));
endmodule

(* ECO_CHECKSUM = "77847bbe" *) 
(* NotValidForBitStream *)
(* \DesignAttr:ENABLE_NOC_NETLIST_VIEW  *) 
(* \DesignAttr:ENABLE_AIE_NETLIST_VIEW  *) 
module top_module
   (clk,
    rst_n,
    x,
    seg_an,
    seg_out);
  input clk;
  input rst_n;
  output [7:0]x;
  output [3:0]seg_an;
  output [6:0]seg_out;

  wire clk;
  wire clk_IBUF;
  wire clk_IBUF_BUFG;
  wire rst_n;
  wire rst_n_IBUF;
  wire [3:0]seg_an;
  wire [2:0]seg_an_OBUF;
  wire [6:0]seg_out;
  wire [6:0]seg_out_OBUF;
  wire u1_sec_pulse_n_1;
  wire w;
  wire [7:0]x;
  wire [7:0]x_OBUF;

initial begin
 $sdf_annotate("tb_top_time_impl.sdf",,,,"tool_control");
end
  BUFG clk_IBUF_BUFG_inst
       (.I(clk_IBUF),
        .O(clk_IBUF_BUFG));
  IBUF clk_IBUF_inst
       (.I(clk),
        .O(clk_IBUF));
  IBUF rst_n_IBUF_inst
       (.I(rst_n),
        .O(rst_n_IBUF));
  OBUF \seg_an_OBUF[0]_inst 
       (.I(seg_an_OBUF[0]),
        .O(seg_an[0]));
  OBUF \seg_an_OBUF[1]_inst 
       (.I(seg_an_OBUF[1]),
        .O(seg_an[1]));
  OBUF \seg_an_OBUF[2]_inst 
       (.I(seg_an_OBUF[2]),
        .O(seg_an[2]));
  OBUF \seg_an_OBUF[3]_inst 
       (.I(seg_an_OBUF[2]),
        .O(seg_an[3]));
  OBUF \seg_out_OBUF[0]_inst 
       (.I(seg_out_OBUF[0]),
        .O(seg_out[0]));
  OBUF \seg_out_OBUF[1]_inst 
       (.I(seg_out_OBUF[1]),
        .O(seg_out[1]));
  OBUF \seg_out_OBUF[2]_inst 
       (.I(seg_out_OBUF[2]),
        .O(seg_out[2]));
  OBUF \seg_out_OBUF[3]_inst 
       (.I(seg_out_OBUF[3]),
        .O(seg_out[3]));
  OBUF \seg_out_OBUF[4]_inst 
       (.I(seg_out_OBUF[4]),
        .O(seg_out[4]));
  OBUF \seg_out_OBUF[5]_inst 
       (.I(seg_out_OBUF[5]),
        .O(seg_out[5]));
  OBUF \seg_out_OBUF[6]_inst 
       (.I(seg_out_OBUF[6]),
        .O(seg_out[6]));
  sec_pulse u1_sec_pulse
       (.CLK(clk_IBUF_BUFG),
        .E(w),
        .rst_n(u1_sec_pulse_n_1),
        .rst_n_IBUF(rst_n_IBUF));
  cnt60 u2_cnt60
       (.CLK(clk_IBUF_BUFG),
        .E(w),
        .\units_reg[3]_0 (u1_sec_pulse_n_1),
        .x_OBUF(x_OBUF));
  seg_driver u3_seg_driver
       (.CLK(clk_IBUF_BUFG),
        .\scan_cnt_reg[15]_0 (u1_sec_pulse_n_1),
        .seg_an_OBUF(seg_an_OBUF),
        .seg_out_OBUF(seg_out_OBUF),
        .x_OBUF(x_OBUF));
  OBUF \x_OBUF[0]_inst 
       (.I(x_OBUF[0]),
        .O(x[0]));
  OBUF \x_OBUF[1]_inst 
       (.I(x_OBUF[1]),
        .O(x[1]));
  OBUF \x_OBUF[2]_inst 
       (.I(x_OBUF[2]),
        .O(x[2]));
  OBUF \x_OBUF[3]_inst 
       (.I(x_OBUF[3]),
        .O(x[3]));
  OBUF \x_OBUF[4]_inst 
       (.I(x_OBUF[4]),
        .O(x[4]));
  OBUF \x_OBUF[5]_inst 
       (.I(x_OBUF[5]),
        .O(x[5]));
  OBUF \x_OBUF[6]_inst 
       (.I(x_OBUF[6]),
        .O(x[6]));
  OBUF \x_OBUF[7]_inst 
       (.I(x_OBUF[7]),
        .O(x[7]));
endmodule
`ifndef GLBL
`define GLBL
`timescale  1 ps / 1 ps

module glbl ();

    parameter ROC_WIDTH = 100000;
    parameter TOC_WIDTH = 0;
    parameter GRES_WIDTH = 10000;
    parameter GRES_START = 10000;

//--------   STARTUP Globals --------------
    wire GSR;
    wire GTS;
    wire GWE;
    wire PRLD;
    wire GRESTORE;
    tri1 p_up_tmp;
    tri (weak1, strong0) PLL_LOCKG = p_up_tmp;

    wire PROGB_GLBL;
    wire CCLKO_GLBL;
    wire FCSBO_GLBL;
    wire [3:0] DO_GLBL;
    wire [3:0] DI_GLBL;
   
    reg GSR_int;
    reg GTS_int;
    reg PRLD_int;
    reg GRESTORE_int;

//--------   JTAG Globals --------------
    wire JTAG_TDO_GLBL;
    wire JTAG_TCK_GLBL;
    wire JTAG_TDI_GLBL;
    wire JTAG_TMS_GLBL;
    wire JTAG_TRST_GLBL;

    reg JTAG_CAPTURE_GLBL;
    reg JTAG_RESET_GLBL;
    reg JTAG_SHIFT_GLBL;
    reg JTAG_UPDATE_GLBL;
    reg JTAG_RUNTEST_GLBL;

    reg JTAG_SEL1_GLBL = 0;
    reg JTAG_SEL2_GLBL = 0 ;
    reg JTAG_SEL3_GLBL = 0;
    reg JTAG_SEL4_GLBL = 0;

    reg JTAG_USER_TDO1_GLBL = 1'bz;
    reg JTAG_USER_TDO2_GLBL = 1'bz;
    reg JTAG_USER_TDO3_GLBL = 1'bz;
    reg JTAG_USER_TDO4_GLBL = 1'bz;

    assign (strong1, weak0) GSR = GSR_int;
    assign (strong1, weak0) GTS = GTS_int;
    assign (weak1, weak0) PRLD = PRLD_int;
    assign (strong1, weak0) GRESTORE = GRESTORE_int;

    initial begin
	GSR_int = 1'b1;
	PRLD_int = 1'b1;
	#(ROC_WIDTH)
	GSR_int = 1'b0;
	PRLD_int = 1'b0;
    end

    initial begin
	GTS_int = 1'b1;
	#(TOC_WIDTH)
	GTS_int = 1'b0;
    end

    initial begin 
	GRESTORE_int = 1'b0;
	#(GRES_START);
	GRESTORE_int = 1'b1;
	#(GRES_WIDTH);
	GRESTORE_int = 1'b0;
    end

endmodule
`endif
