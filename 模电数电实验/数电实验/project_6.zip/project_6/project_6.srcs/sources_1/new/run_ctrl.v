module run_ctrl (
    input wire clk,
    input wire rst_n,
    input wire start_pulse,
    output reg run_en
);
    always @(posedge clk or posedge rst_n) begin
        if (rst_n)
            run_en <= 1'b0;
        else if (start_pulse)
            run_en <= ~run_en;
    end
endmodule
