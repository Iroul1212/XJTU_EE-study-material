module seg_driver (
    input wire clk,
    input wire rst_n,
    input wire [15:0] bcd_data,
    output reg [3:0] seg_an,
    output reg [6:0] seg_out
);

    reg [15:0] scan_cnt;
    always @(posedge clk or posedge rst_n) begin
        if (rst_n) scan_cnt <= 16'd0;
        else scan_cnt <= scan_cnt + 1'b1;
    end
    wire scan_clk = scan_cnt[15];

    reg [3:0] current_digit;
    always @(posedge scan_clk or posedge rst_n) begin
        if (rst_n) begin
            seg_an <= 4'b1000;
            current_digit <= bcd_data[3:0];
        end else begin
            case (seg_an)
                4'b1000: begin seg_an <= 4'b0100; current_digit <= bcd_data[7:4]; end
                4'b0100: begin seg_an <= 4'b0010; current_digit <= bcd_data[11:8]; end
                4'b0010: begin seg_an <= 4'b0001; current_digit <= bcd_data[15:12]; end
                default: begin seg_an <= 4'b1000; current_digit <= bcd_data[3:0]; end
            endcase
        end
    end

    always @(*) begin
        case (current_digit)
            4'd0: seg_out = 7'b1111110;
            4'd1: seg_out = 7'b0110000;
            4'd2: seg_out = 7'b1101101;
            4'd3: seg_out = 7'b1111001;
            4'd4: seg_out = 7'b0110011;
            4'd5: seg_out = 7'b1011011;
            4'd6: seg_out = 7'b1011111;
            4'd7: seg_out = 7'b1110000;
            4'd8: seg_out = 7'b1111111;
            4'd9: seg_out = 7'b1111011;
            default: seg_out = 7'b0000000;
        endcase
    end
endmodule