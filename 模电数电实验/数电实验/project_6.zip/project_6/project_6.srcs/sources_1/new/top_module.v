module top_module (
    input wire clk,
    input wire rst_n,
    input wire key_start_n,
    input wire key_clear_n,
    output wire [7:0] x,
    output wire [3:0] seg_an,
    output wire [6:0] seg_out
);
    wire w;
    wire [7:0] sec_bcd;
    wire [15:0] disp_bcd;
    wire run_en;

    wire start_pressed;
    wire clear_pressed;
    wire cnt_clr;

    assign cnt_clr = clear_pressed & ~run_en;

    // 实例化秒脉冲产生器
    sec_pulse u1_sec_pulse (
        .clk(clk),
        .rst_n(rst_n),
        .pulse_out(w)
    );

    key_debounce_pulse u2_key_start (
        .clk(clk),
        .rst_n(rst_n),
        .key_n(key_start_n),
        .press_pulse(start_pressed)
    );

    key_debounce_pulse u3_key_clear (
        .clk(clk),
        .rst_n(rst_n),
        .key_n(key_clear_n),
        .press_pulse(clear_pressed)
    );

    run_ctrl u4_run_ctrl (
        .clk(clk),
        .rst_n(rst_n),
        .start_pulse(start_pressed),
        .run_en(run_en)
    );

    // 实例化模60计数器
    cnt60 u5_cnt60 (
        .clk(clk),
        .rst_n(rst_n),
        .clr(cnt_clr),
        .pulse_in(w & run_en),
        .x(sec_bcd)
    );

    // LED显示秒
    assign x = sec_bcd;
    assign disp_bcd = {8'h00, sec_bcd};

    // 实例化数码管驱动
    seg_driver u6_seg_driver (
        .clk(clk),
        .rst_n(rst_n),
        .bcd_data(disp_bcd),
        .seg_an(seg_an),
        .seg_out(seg_out)
    );

endmodule