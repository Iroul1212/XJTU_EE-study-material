module sec_pulse #(
    parameter CNT_MAX = 32'd99_999_999 // 100MHz时钟产生1Hz脉冲
)(
    input wire clk,
    input wire rst_n,
    output reg pulse_out
);
    reg [31:0] cnt;

    always @(posedge clk or posedge rst_n) begin
        if (rst_n) begin
            cnt <= 32'd0;
            pulse_out <= 1'b0;
        end else if (cnt == CNT_MAX) begin
            cnt <= 32'd0;
            pulse_out <= 1'b1; // 产生一个时钟周期的使能信号
        end else begin
            cnt <= cnt + 1'b1;
            pulse_out <= 1'b0;
        end
    end
endmodule