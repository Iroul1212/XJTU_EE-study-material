"""
EGO1 信号发生器 - 远程蓝牙控制面板
通过 BLE 连接 STM32，远程控制 FPGA 信号输出

支持的指令集 (单字符):
  波形: '0'=正弦, '1'=方波, '2'=三角波, '3'=锯齿波, 'W'=轮换
  频率: '+', '-'
  占空比: 'D'(+5%), 'd'(-5%)
  幅值: 'A'(+100mV), 'a'(-100mV)
  偏置: 'O'(+100mV), 'o'(-100mV)
  复位: 'R'
"""

import flet as ft
import asyncio
from bleak import BleakClient, BleakScanner

# ── 配置 ──────────────────────────────────────────────
UART_SERVICE_UUID = "0000ffe0-0000-1000-8000-00805f9b34fb"
UART_CHAR_UUID    = "0000ffe1-0000-1000-8000-00805f9b34fb"

# 硬件参数范围
FREQ_MIN, FREQ_MAX = 0, 2_000_000    # Hz
AMP_MIN,  AMP_MAX  = 0, 3700         # mV
DC_MIN,   DC_MAX   = 0, 3300         # mV
DUTY_MIN, DUTY_MAX = 0, 100          # %

# 波形选项
WAVEFORMS = ["正弦波", "方波", "三角波"]


def _safe_icon(name, fallback):
    """安全获取图标，兼容 flet 各版本"""
    try:
        return getattr(ft.Icons, name)
    except AttributeError:
        return getattr(ft.Icons, fallback)


async def main(page: ft.Page):
    # ── 页面基础设置 ───────────────────────────────────
    page.title = "EGO1 信号发生器"
    page.theme_mode = ft.ThemeMode.DARK
    page.window_width = 420
    page.window_height = 780
    page.scroll = ft.ScrollMode.ADAPTIVE
    page.padding = 16

    # 波形图标（安全回退）
    WAVE_ICONS = [
        _safe_icon("INSERT_CHART", "WAVES"),
        _safe_icon("CHECK_BOX_OUTLINE_BLANK", "STOP"),
        _safe_icon("CHANGE_HISTORY", "WAVES"),
    ]

    client: BleakClient | None = None
    cmd_log: list[str] = []

    # ── 工具函数 ───────────────────────────────────────
    async def send_char(ch: str) -> bool:
        """发送单字符指令，返回是否成功"""
        nonlocal client
        if client and client.is_connected:
            try:
                data = ch.encode()
                print(f"[BLE] 发送: {ch!r} → {data.hex()}")
                # response=False 对 BLE UART 模块 (HM-10/HC-08/JDY-31) 至关重要
                await client.write_gatt_char(UART_CHAR_UUID, data, response=False)
                cmd_log.append(ch)
                if len(cmd_log) > 50:
                    cmd_log.pop(0)
                log_text.value = " → ".join(cmd_log[-12:])
                log_text.update()
                show_toast(f"已发送: {ch}")
                return True
            except Exception as ex:
                print(f"[BLE] 发送失败: {ex}")
                show_toast(f"发送失败: {ex}", is_error=True)
                return False
        else:
            show_toast("请先连接蓝牙设备", is_error=True)
            return False

    def show_toast(msg: str, is_error: bool = False):
        snack = ft.SnackBar(
            ft.Text(msg, color=ft.Colors.WHITE if is_error else None),
            bgcolor=ft.Colors.RED_800 if is_error else None,
            duration=2000,
        )
        page.overlay.append(snack)
        snack.open = True
        page.update()

    # ── 更新 UI 辅助 ───────────────────────────────────
    def set_connection_ui(connected: bool, address: str = ""):
        """统一更新连接状态 UI"""
        if connected:
            status_icon.name = ft.Icons.BLUETOOTH_CONNECTED
            status_icon.color = ft.Colors.GREEN_ACCENT_400
            status_text.value = f"已连接 {address}"
            status_text.color = ft.Colors.GREEN_ACCENT_400
            connect_btn.text = "断开连接"
            connect_btn.icon = ft.Icons.BLUETOOTH_DISABLED
            connect_btn.style = ft.ButtonStyle(bgcolor=ft.Colors.RED_800)
            addr_field.disabled = True
            scan_btn.disabled = True
            device_dropdown.disabled = True
            control_container.disabled = False
        else:
            status_icon.name = ft.Icons.BLUETOOTH_DISABLED
            status_icon.color = ft.Colors.RED_400
            status_text.value = "未连接"
            status_text.color = ft.Colors.RED_400
            connect_btn.text = "连接设备"
            connect_btn.icon = ft.Icons.BLUETOOTH
            connect_btn.style = ft.ButtonStyle(bgcolor=ft.Colors.TEAL_700)
            addr_field.disabled = False
            scan_btn.disabled = False
            device_dropdown.disabled = False
            control_container.disabled = True
        page.update()

    # ── 连接 / 断开 ────────────────────────────────────
    async def connect_toggle(e):
        nonlocal client
        if client and client.is_connected:
            await client.disconnect()
            client = None
            set_connection_ui(False)
            return

        addr = addr_field.value.strip().upper()
        if not addr:
            show_toast("请输入蓝牙 MAC 地址", is_error=True)
            return

        scan_btn.disabled = True
        connect_btn.disabled = True
        status_text.value = f"正在连接 {addr}..."
        status_text.color = ft.Colors.ORANGE_400
        page.update()

        try:
            client = BleakClient(addr, timeout=8.0)
            await client.connect()
            print(f"[BLE] 已连接 {addr}")
            set_connection_ui(True, addr)
            # 服务发现单独容错，失败不影响连接
            try:
                # bleak 3.0: services 是属性而非方法
                if hasattr(client, 'get_services'):
                    services = await client.get_services()
                else:
                    services = client.services
                for svc in services:
                    print(f"[BLE]  Service: {svc.uuid}")
                    for ch in svc.characteristics:
                        props = ch.properties
                        write_ok = "write" in props or "write-without-response" in props
                        print(f"[BLE]    Char: {ch.uuid}  props={props} 可写={write_ok}")
            except Exception as svc_ex:
                print(f"[BLE] 服务发现失败(可忽略): {svc_ex}")
        except Exception as ex:
            print(f"[BLE] 连接失败: {ex}")
            status_text.value = "连接失败"
            status_text.color = ft.Colors.RED_400
            show_toast(f"连接失败: {ex}", is_error=True)
        finally:
            scan_btn.disabled = False
            connect_btn.disabled = False
        page.update()

    # ── 设备扫描 ────────────────────────────────────────
    device_map: dict[str, str] = {}  # label -> MAC

    async def scan_devices(e):
        scan_btn.disabled = True
        connect_btn.disabled = True
        status_text.value = "正在扫描 BLE 设备..."
        status_text.color = ft.Colors.ORANGE_400
        device_dropdown.options.clear()
        device_dropdown.value = None
        page.update()

        try:
            devices = await BleakScanner.discover(timeout=5.0)
            if not devices:
                show_toast("未发现任何 BLE 设备", is_error=True)
            else:
                device_map.clear()
                named = 0
                for d in devices:
                    if d.name:
                        label = f"{d.name}  [{d.address}]"
                        named += 1
                    else:
                        label = d.address
                    device_map[label] = d.address
                    device_dropdown.options.append(ft.dropdown.Option(
                        key=d.address, text=label,
                    ))
                device_dropdown.visible = True
                show_toast(f"发现 {named} 个已命名设备, {len(devices)-named} 个未命名 — 请在下拉框中选择")
        except Exception as ex:
            show_toast(f"扫描失败: {ex}", is_error=True)
        finally:
            scan_btn.disabled = False
            connect_btn.disabled = False
            status_text.value = "未连接"
            status_text.color = ft.Colors.RED_400
            page.update()

    def on_device_selected(e):
        """下拉框选中设备后自动填入 MAC 地址"""
        if device_dropdown.value:
            addr_field.value = device_dropdown.value
            addr_field.update()

    # ── 命令发送包装 ───────────────────────────────────
    async def cmd_waveform(index: int):
        """直接选择波形，index: 0=正弦 1=方波 2=三角 3=锯齿"""
        await send_char(str(index))

    async def cmd_freq_up(e):
        await send_char("+")

    async def cmd_freq_down(e):
        await send_char("-")

    async def cmd_duty_up(e):
        await send_char("D")

    async def cmd_duty_down(e):
        await send_char("d")

    async def cmd_amp_up(e):
        await send_char("A")

    async def cmd_amp_down(e):
        await send_char("a")

    async def cmd_dc_up(e):
        await send_char("O")

    async def cmd_dc_down(e):
        await send_char("o")

    async def cmd_reset(e):
        await send_char("R")
        show_toast("已发送复位指令")

    # ── 页面关闭时断开 ─────────────────────────────────
    async def on_page_close(e):
        nonlocal client
        if client and client.is_connected:
            await client.disconnect()

    page.on_close = on_page_close

    # ── UI 组件：连接区 ─────────────────────────────────
    status_icon = ft.Icon(ft.Icons.BLUETOOTH_DISABLED, color=ft.Colors.RED_400, size=20)
    status_text = ft.Text("未连接", color=ft.Colors.RED_400, size=14, weight="bold")

    addr_field = ft.TextField(
        label="蓝牙 MAC 地址",
        hint_text="XX:XX:XX:XX:XX:XX",
        value="",
        text_style=ft.TextStyle(size=13, font_family="monospace"),
        border_color=ft.Colors.TEAL_400,
        focused_border_color=ft.Colors.TEAL_ACCENT_400,
        prefix_icon=ft.Icons.BLUETOOTH,
    )

    scan_btn = ft.Button(
        "扫描设备",
        icon=ft.Icons.SEARCH,
        on_click=scan_devices,
        style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_GREY_700),
    )

    connect_btn = ft.Button(
        "连接设备",
        icon=ft.Icons.BLUETOOTH,
        on_click=connect_toggle,
        style=ft.ButtonStyle(bgcolor=ft.Colors.TEAL_700),
    )

    device_dropdown = ft.Dropdown(
        label="扫描到的设备",
        hint_text="点击扫描按钮后在此选择",
        visible=False,
        on_text_change=on_device_selected,
        expand=True,
    )

    # ── UI 组件：波形控制 ───────────────────────────────
    wave_buttons = []
    for i, (name, icon) in enumerate(zip(WAVEFORMS, WAVE_ICONS)):
        wave_buttons.append(
            ft.FilledTonalButton(
                content=ft.Text(name),
                icon=icon,
                expand=True,
                on_click=lambda e, idx=i: page.run_task(cmd_waveform, idx),
                style=ft.ButtonStyle(
                    padding=ft.Padding(4, 12, 4, 12),
                ),
            )
        )

    # ── UI 组件：频率控制 ───────────────────────────────
    async def cmd_freq_up_custom(e):
        await send_char("+")

    async def cmd_freq_down_custom(e):
        await send_char("-")

    # ── UI 组件：参数微调区 ─────────────────────────────
    def make_stepper(label: str, icon_name, up_cmd, down_cmd, value_text: str):
        """创建 +/- 步进控制行"""
        return ft.Container(
            content=ft.Row([
                ft.Icon(icon_name, size=20, color=ft.Colors.TEAL_300),
                ft.Text(label, size=13, weight="bold", width=50),
                ft.Text(value_text, size=12, color=ft.Colors.GREY_400, width=70, text_align=ft.TextAlign.CENTER),
                ft.IconButton(
                    ft.Icons.REMOVE_CIRCLE_OUTLINE,
                    icon_color=ft.Colors.RED_300, icon_size=28,
                    on_click=down_cmd,
                ),
                ft.IconButton(
                    ft.Icons.ADD_CIRCLE_OUTLINE,
                    icon_color=ft.Colors.GREEN_300, icon_size=28,
                    on_click=up_cmd,
                ),
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN, vertical_alignment=ft.CrossAxisAlignment.CENTER),
            padding=ft.Padding(8, 4, 8, 4),
            border_radius=8,
            bgcolor=ft.Colors.SURFACE,
        )

    # ── UI 组件：日志区 ─────────────────────────────────
    log_text = ft.Text(
        "",
        size=11,
        color=ft.Colors.GREY_400,
        font_family="monospace",
        selectable=True,
    )

    # ── 将控制区包裹在一个容器内，用于整体禁用 ──────────
    control_container = ft.Container(
        content=ft.Column([
            # 波形选择
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.ListTile(
                            leading=ft.Icon(ft.Icons.WAVES, color=ft.Colors.TEAL_300),
                            title=ft.Text("波形选择", weight="bold"),
                            subtitle=ft.Text("选择输出波形类型"),
                        ),
                        ft.Row(wave_buttons, tight=True),
                    ], tight=True),
                    padding=12,
                ),
            ),

            # 频率控制
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.ListTile(
                            leading=ft.Icon(ft.Icons.SPEED, color=ft.Colors.ORANGE_300),
                            title=ft.Text("频率控制", weight="bold"),
                            subtitle=ft.Text("每次 +/- 100Hz，连续点击快速调节"),
                        ),
                        ft.Divider(height=4, color="transparent"),
                        ft.Row([
                            ft.IconButton(
                                ft.Icons.REMOVE_CIRCLE, icon_color=ft.Colors.RED_400,
                                icon_size=44, on_click=cmd_freq_down_custom,
                            ),
                            ft.Text("频率\n步进", size=14, weight="bold", text_align=ft.TextAlign.CENTER),
                            ft.IconButton(
                                ft.Icons.ADD_CIRCLE, icon_color=ft.Colors.GREEN_400,
                                icon_size=44, on_click=cmd_freq_up_custom,
                            ),
                        ], alignment=ft.MainAxisAlignment.SPACE_AROUND),
                    ], tight=True),
                    padding=12,
                ),
            ),

            # 参数微调
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.ListTile(
                            leading=ft.Icon(ft.Icons.TUNE, color=ft.Colors.PURPLE_300),
                            title=ft.Text("参数微调", weight="bold"),
                            subtitle=ft.Text("占空比 ±5%  |  幅值 ±100mV  |  偏置 ±100mV"),
                        ),
                        make_stepper("占空比", ft.Icons.PIE_CHART,
                                     cmd_duty_up, cmd_duty_down, "±5%"),
                        ft.Divider(height=4, color="transparent"),
                        make_stepper("幅值", ft.Icons.VERTICAL_ALIGN_TOP,
                                     cmd_amp_up, cmd_amp_down, "±100mV"),
                        ft.Divider(height=4, color="transparent"),
                        make_stepper("偏置", ft.Icons.VERTICAL_ALIGN_CENTER,
                                     cmd_dc_up, cmd_dc_down, "±100mV"),
                    ], tight=True),
                    padding=12,
                ),
            ),

            # 复位按钮
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.ListTile(
                            leading=ft.Icon(ft.Icons.RESTART_ALT, color=ft.Colors.YELLOW_400),
                            title=ft.Text("系统复位", weight="bold"),
                            subtitle=ft.Text("恢复默认参数: 方波 500Hz 50%占空比 1Vpp"),
                        ),
                        ft.FilledButton(
                            content=ft.Text("恢复默认设置"),
                            icon=ft.Icons.REFRESH,
                            on_click=cmd_reset,
                            style=ft.ButtonStyle(bgcolor=ft.Colors.AMBER_800),
                        ),
                    ], tight=True, alignment=ft.MainAxisAlignment.CENTER,
                       horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    padding=12,
                ),
            ),

            # 命令日志
            ft.Card(
                content=ft.Container(
                    content=ft.Column([
                        ft.ListTile(
                            leading=ft.Icon(ft.Icons.TERMINAL, color=ft.Colors.GREY_400, size=20),
                            title=ft.Text("指令日志", size=13, weight="bold"),
                            subtitle=ft.Text("最近发送的指令序列"),
                        ),
                        ft.Container(
                            content=log_text,
                            padding=ft.Padding(8, 4, 8, 8),
                            border_radius=6,
                            bgcolor=ft.Colors.with_opacity(0.26, ft.Colors.BLACK),
                        ),
                    ], tight=True),
                    padding=ft.Padding(12, 8, 12, 12),
                ),
            ),
        ], tight=True, spacing=10),
        disabled=True,
    )

    # ── 整体布局 ────────────────────────────────────────
    page.add(
        ft.Row([
            ft.Icon(ft.Icons.SETTINGS_REMOTE, size=28, color=ft.Colors.TEAL_300),
            ft.Text("EGO1 信号发生器", size=22, weight="bold",
                    color=ft.Colors.TEAL_200),
        ], alignment=ft.MainAxisAlignment.CENTER),
        ft.Divider(height=8, color="transparent"),

        ft.Row([status_icon, status_text], alignment=ft.MainAxisAlignment.CENTER),
        ft.Divider(height=8, color="transparent"),

        device_dropdown,
        ft.Row([addr_field], tight=True),
        ft.Row([scan_btn, connect_btn], alignment=ft.MainAxisAlignment.SPACE_EVENLY),
        ft.Divider(height=8, color="transparent"),

        control_container,
    )


if __name__ == "__main__":
    ft.run(main)
