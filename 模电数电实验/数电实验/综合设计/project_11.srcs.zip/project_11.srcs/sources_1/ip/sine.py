import math

# 文件名
filename = "sine.coe"
depth = 1024
width = 8
max_val = 2**width - 1

with open(filename, 'w') as f:
    f.write("memory_initialization_radix=10;\n")
    f.write("memory_initialization_vector=\n")
    for i in range(depth):
        # 计算正弦值并映射到 0-255
        val = int((math.sin(2 * math.pi * i / depth) + 1) * max_val / 2)
        if i == depth - 1:
            f.write(f"{val};")
        else:
            f.write(f"{val},\n")