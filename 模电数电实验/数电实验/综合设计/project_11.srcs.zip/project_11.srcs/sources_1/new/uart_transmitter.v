// =============================================================================
// 模块: uart_transmitter - UART发送模块 (115200bps, 8N1, LSB first)
// =============================================================================
// 功能: 将8位并行数据转换为串行UART帧发送。
//       帧格式: 1起始位(0) + 8数据位(LSB first) + 1停止位(1)
//       空闲状态: tx_line=1 (高电平)
//       握手协议: tx_start脉冲启动 -> tx_busy=1 -> 发送完成 -> tx_busy=0
//
// AI参与: [AI生成] Copilot辅助生成UART发送状态机框架
// =============================================================================
module uart_transmitter (
    input  wire        clk,         // 系统时钟 100MHz
    input  wire        rst_n,       // 复位
    input  wire        tx_start,    // 启动发送脉冲
    input  wire [7:0]  tx_data,     // 待发送字节
    output reg         tx_line,     // UART TX 输出
    output reg         tx_busy      // 忙标志
);

    parameter BAUD_CLK = 868;       // 100MHz / 115200

    reg [15:0]  baud_cnt;
    reg [3:0]   bit_cnt;
    reg [7:0]   data_buf;
    reg         transmitting;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_line      <= 1'b1;
            tx_busy      <= 1'b0;
            baud_cnt     <= 16'd0;
            bit_cnt      <= 4'd0;
            data_buf     <= 8'd0;
            transmitting <= 1'b0;
        end else begin
            if (!transmitting) begin
                tx_line <= 1'b1;           // 空闲高电平
                if (tx_start) begin
                    transmitting <= 1'b1;
                    tx_busy      <= 1'b1;
                    data_buf     <= tx_data;
                    baud_cnt     <= 16'd0;
                    bit_cnt      <= 4'd0;
                end
            end else begin
                if (baud_cnt == BAUD_CLK - 1) begin
                    baud_cnt <= 16'd0;
                    case (bit_cnt)
                        4'd0: begin
                            tx_line <= 1'b0;              // 起始位
                            bit_cnt <= 4'd1;
                        end
                        4'd1, 4'd2, 4'd3, 4'd4,
                        4'd5, 4'd6, 4'd7, 4'd8: begin
                            tx_line <= data_buf[bit_cnt - 1]; // 数据位 LSB first
                            bit_cnt <= bit_cnt + 4'd1;
                        end
                        4'd9: begin
                            tx_line <= 1'b1;              // 停止位
                            bit_cnt <= 4'd10;
                        end
                        default: begin
                            tx_line      <= 1'b1;
                            tx_busy      <= 1'b0;
                            transmitting <= 1'b0;
                        end
                    endcase
                end else begin
                    baud_cnt <= baud_cnt + 16'd1;
                end
            end
        end
    end

endmodule
