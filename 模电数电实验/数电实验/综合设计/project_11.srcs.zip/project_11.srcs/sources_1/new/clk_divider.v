// =============================================================================
// 模块: clk_divider - 时钟分频模块
// =============================================================================
// 功能: 将板载100MHz系统时钟分频为三路:
//       25MHz(VGA像素时钟,4分频), 1kHz(数码管动态扫描), 50Hz(按键消抖采样)
// 设计原理: 计数器翻转法,占空比50%
//
// AI初版假定50MHz, 重新计算所有分频参数适配EGO1的100MHz
// =============================================================================
module clk_divider (
    input  wire sys_clk,     // 系统时钟 100MHz (EGO1板载)
    input wire sys_rst_n,    // 异步复位
    output reg  clk_1k,      // 1kHz 数码管扫描时钟 (周期 = 100M/1000/2 = 50000)
    output reg  clk_50hz,    // 50Hz 按键采样时钟 (周期 = 100M/50/2 = 1000000)
    output reg  clk_25m      // 25MHz VGA像素时钟 (4分频)
);
    reg [1:0] cnt_25m;
    reg [15:0] cnt_1k; 
    reg [19:0] cnt_50hz;
    
    // 100MHz->25MHz VGA时钟: 4分频 (周期=4, 翻转于计数值1)
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin cnt_25m <= 0; clk_25m <= 0; end 
        else begin
            cnt_25m <= cnt_25m + 1;
            if (cnt_25m == 2'd1) begin cnt_25m <= 0; clk_25m <= ~clk_25m; end
        end
    end
    
    // 100MHz->1kHz 数码管扫描: 周期50000 (100M/1k/2-1=49999)
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin cnt_1k <= 0; clk_1k <= 0; end
        else if (cnt_1k == 16'd49_999) begin cnt_1k <= 0; clk_1k <= ~clk_1k; end
        else cnt_1k <= cnt_1k + 1;
    end
    
    // 100MHz->50Hz 按键消抖: 周期1000000 (100M/50/2-1=999999)
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin cnt_50hz <= 0; clk_50hz <= 0; end
        else if (cnt_50hz == 20'd999_999) begin cnt_50hz <= 0; clk_50hz <= ~clk_50hz; end
        else cnt_50hz <= cnt_50hz + 1;
    end
endmodule