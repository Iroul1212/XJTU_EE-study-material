// =============================================================================
// 模块: uart_receiver - UART接收模块 (115200bps, 8N1)
// =============================================================================
// 功能: 接收来自STM32的串行数据,解析为8位并行字节。
//       波特率: 115200 (100MHz / 115200 ~= 868周期/bit)
//       采样策略: 检测下降沿 -> 等半个位周期 -> 在每bit中心采样
//       包含: 输入同步器(防亚稳态), 起始位验证, 停止位校验
//
// AI参与: [AI生成] Copilot辅助生成UART接收状态机框架
//         波特率参数适配100MHz, 增加half_done机制
// =============================================================================
module uart_receiver (
    input  wire        clk,        // 系统时钟 100MHz
    input  wire        rst_n,      // 复位信号
    input  wire        rx,         // 串口接收数据线
    
    output reg  [7:0]  data_out,   // 接收到的数据
    output reg         data_valid  // 数据有效信号 (1个时钟周期脉冲)
);

    parameter BAUD_CLK = 868;      // 100MHz/115200 ~= 868 (完整位周期)
    parameter HALF_BAUD = 434;     // 半个位周期,用于起始位中心采样
    
    reg [15:0]  baud_cnt;          // 波特率计数器
    reg [3:0]   bit_cnt;           // 当前正在采样的位: 0=起始位, 1~8=数据位, 9=停止位
    reg [7:0]   data_buf;          // 数据缓冲
    reg         rx_sync0, rx_sync1, rx_sync2;  // 输入同步
    
    reg         receiving;         // 正在接收状态标志
    reg         half_done;         // 半比特等待完成标志: 0=等待HALF_BAUD, 1=正常BAUD_CLK采样

    // 输入同步和边沿检测
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_sync0 <= 1'b1;
            rx_sync1 <= 1'b1;
            rx_sync2 <= 1'b1;
        end else begin
            rx_sync0 <= rx;
            rx_sync1 <= rx_sync0;
            rx_sync2 <= rx_sync1;
        end
    end

    wire rx_falling_edge = ~rx_sync1 & rx_sync2;  // 下降沿 = 开始位（rx_sync1=0, rx_sync2=1）

    // UART接收状态机
    // 时序: 检测下降沿(start bit)
    //   -> 等HALF_BAUD周期到达起始位中心
    //   -> 之后每BAUD_CLK周期采样一个bit中心 (LSB first)
    //   -> bit_cnt=1: D0, bit_cnt=2: D1, ..., bit_cnt=8: D7
    //   -> bit_cnt=9: 停止位中心 -> 输出数据
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            baud_cnt   <= 16'd0;
            bit_cnt    <= 4'd0;
            data_buf   <= 8'd0;
            data_out   <= 8'd0;
            data_valid <= 1'b0;
            receiving  <= 1'b0;
            half_done  <= 1'b0;
        end else begin
            data_valid <= 1'b0;

            if (!receiving) begin
                // 不在接收状态，等待开始位（下降沿）
                if (rx_falling_edge) begin
                    receiving <= 1'b1;
                    baud_cnt  <= 16'd0;
                    bit_cnt   <= 4'd0;
                    data_buf  <= 8'd0;
                    half_done <= 1'b0;
                end
            end else if (!half_done) begin
                // 阶段1: 等待 HALF_BAUD 到达起始位的中心
                if (baud_cnt == HALF_BAUD - 1) begin
                    baud_cnt  <= 16'd0;
                    half_done <= 1'b1;
                    bit_cnt   <= 4'd1;    // ★ 起始位已过，下一个采样点是数据位0
                end else begin
                    baud_cnt <= baud_cnt + 1;
                end
            end else begin
                // 阶段2: 每隔 BAUD_CLK 到达下一个比特的中心
                if (baud_cnt == BAUD_CLK - 1) begin
                    baud_cnt <= 16'd0;

                    if (bit_cnt >= 1 && bit_cnt <= 8) begin
                        // 数据位0~7中心采样 (LSB first)
                        // bit_cnt=1 → data_buf[0], bit_cnt=2 → data_buf[1], …
                        data_buf[bit_cnt - 1] <= rx_sync1;
                        bit_cnt <= bit_cnt + 1;
                    end else begin
                        // bit_cnt == 9: 停止位中心，接收完成
                        data_out   <= data_buf;
                        data_valid <= 1'b1;
                        receiving  <= 1'b0;
                    end
                end else begin
                    baud_cnt <= baud_cnt + 1;
                end
            end
        end
    end

endmodule
