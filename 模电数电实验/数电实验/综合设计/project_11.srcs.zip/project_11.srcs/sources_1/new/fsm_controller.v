// =============================================================================
// 模块: fsm_controller - 有限状态机控制器 (Moore型三段式FSM)
// =============================================================================
// 功能: 管理5种参数编辑模式,接收按键+UART双通道输入,输出DDS全部参数。
//       模式: 0=波形 1=频率 2=占空比 3=幅值 4=直流偏置
//       特性: (1) 双层寄存器(显示值+物理值分离)
//             (2) dp_pos_arr[0:4] 各模式独立小数点记忆
//             (3) digit_step() 按编辑数位1/10/100/1k/10k步进
//             (4) show_to_freq_word() 显示值->频率控制字转换
//             (5) UART各参数独立更新脉冲,不覆盖未修改参数
//
// AI参与: [AI生成] Gemini提供5模式基本框架(3键)
//         增加digit/dp键,双层架构,独立dp_pos,UART双通道
// =============================================================================
module fsm_controller (
    input wire clk, input wire rst_n, input wire key_mode, input wire key_add, input wire key_sub,
    input wire key_digit, input wire key_dp, 
    
    // UART 参数输入 (来自蓝牙)
    input wire [1:0]   uart_wave_type,
    input wire [19:0]  uart_freq_show,
    input wire [19:0]  uart_duty_show,
    input wire [19:0]  uart_amp_show,
    input wire [19:0]  uart_dc_show,
    // 独立更新脉冲（只更新对应参数，不再全覆盖）
    input wire         uart_wave_update,
    input wire         uart_freq_update,
    input wire         uart_duty_update,
    input wire         uart_amp_update,
    input wire         uart_dc_update,
    
    output reg [1:0] wave_type, output reg [31:0] freq_word,
    output reg [7:0] duty_cycle, output reg [2:0] amp_ctrl, output reg [7:0] dc_offset,
    output reg [2:0] current_mode, output reg [2:0] edit_digit, output reg [1:0] dp_pos,
    output reg [1:0] dp_pos_freq, output reg [1:0] dp_pos_amp, output reg [1:0] dp_pos_dc,
    output reg [19:0] freq_show, output reg [19:0] duty_show, output reg [19:0] amp_show, output reg [19:0] dc_show
);

    reg [1:0] next_wave_type; reg [31:0] next_freq_word; reg [7:0] next_duty_cycle;
    reg [2:0] next_amp_ctrl;
    reg [7:0] next_dc_offset; reg [2:0] next_current_mode;
    reg [2:0] next_edit_digit; reg [1:0] next_dp_pos; reg [19:0] next_freq_show;
    reg [19:0] next_duty_show;
    reg [19:0] next_amp_show; reg [19:0] next_dc_show;
    reg [19:0] step_value;
    // dp_pos 缩放后的中间值
    reg [19:0] scaled_freq_show;
    reg [19:0] scaled_dc_show;

    // 每个模式独立记忆dp_pos,切换模式不丢失
    reg [1:0] dp_pos_arr [0:4];   // mode 0~4 各自的 dp_pos
    reg [1:0] next_dp_pos_freq, next_dp_pos_amp, next_dp_pos_dc;

    // 步进值函数: 按当前编辑数位返回对应步进量
    // edit_digit: 0->1, 1->10, 2->100, 3->1000, 4->10000
    function [19:0] digit_step(input [2:0] digit);
        begin
            case (digit)
                3'd0: digit_step = 20'd1;
                3'd1: digit_step = 20'd10;
                3'd2: digit_step = 20'd100;
                3'd3: digit_step = 20'd1000;
                3'd4: digit_step = 20'd10000;
                default: digit_step = 20'd1;
            endcase
        end
    endfunction

    // dp_pos量程缩放: 将显示值换算为实际物理值
    // dp_pos=0: x1(无小数点) dp_pos=1: /10 dp_pos=2: /100 dp_pos=3: /1000
    function [19:0] apply_dp_scale(input [19:0] val, input [1:0] dp);
        begin
            case (dp)
                2'd0: apply_dp_scale = val;
                2'd1: apply_dp_scale = val / 10;
                2'd2: apply_dp_scale = val / 100;
                2'd3: apply_dp_scale = val / 1000;
                default: apply_dp_scale = val;
            endcase
        end
    endfunction

    // freq_word -> freq_show 转换: K -> 实际频率(Hz)
    // f_actual = K * 100MHz / 2^32, 用64位乘法防溢出
    function [19:0] freq_word_to_show(input [31:0] word);
        reg [63:0] scaled;
        begin
            scaled = (64'd100_000_000 * word) >> 32;
            if (scaled > 64'd99999) freq_word_to_show = 20'd99999;
            else freq_word_to_show = scaled[19:0];
        end
    endfunction

    // freq_show -> freq_word 逆转换: 频率(Hz) -> K
    // K = f_actual * 2^32 / 100MHz
    function [31:0] show_to_freq_word(input [19:0] show_value);
        reg [63:0] scaled;
        begin
            scaled = (64'h1_0000_0000 * show_value + 64'd50_000_000) / 64'd100_000_000;
            show_to_freq_word = scaled[31:0];
        end
    endfunction

    // ===============================================================
    // 组合逻辑段: 根据按键和当前状态计算next_*值
    // key_mode切换模式, key_digit切换数位, key_dp切换小数点
    // ===============================================================
    always @(*) begin
        next_wave_type = wave_type;
        next_freq_word = freq_word; next_duty_cycle = duty_cycle;
        next_amp_ctrl = amp_ctrl; next_dc_offset = dc_offset; next_current_mode = current_mode;
        next_edit_digit = edit_digit;
        next_dp_pos = dp_pos; next_freq_show = freq_show;
        next_duty_show = duty_show; next_amp_show = amp_show; next_dc_show = dc_show;

        if (key_mode) next_current_mode = (current_mode == 4) ? 0 : current_mode + 1;
        if (key_digit) next_edit_digit = (edit_digit == 4) ? 0 : edit_digit + 1;
        // key_dp 只改变当前模式的 dp_pos，各模式独立记忆
        if (key_dp) next_dp_pos = (dp_pos_arr[current_mode] == 3) ? 0 : dp_pos_arr[current_mode] + 1;
        else        next_dp_pos = dp_pos_arr[current_mode];
        // 输出各模式的独立 dp_pos（用于物理量缩放）
        next_dp_pos_freq = dp_pos_arr[1];
        next_dp_pos_amp  = dp_pos_arr[3];
        next_dp_pos_dc   = dp_pos_arr[4];
        
        // 使用更新后的步进逻辑
        step_value = digit_step(next_edit_digit);

        case (current_mode)
            0: begin
                if (key_add) next_wave_type = (wave_type == 2) ? 0 : wave_type + 1;
                else if (key_sub) next_wave_type = (wave_type == 0) ? 2 : wave_type - 1;
            end
            1: begin
                if (key_add) next_freq_show = (freq_show + step_value > 20'd99999) ? 20'd99999 : freq_show + step_value;
                else if (key_sub) next_freq_show = (freq_show < step_value) ? 20'd0 : freq_show - step_value;
                // dp_pos 量程缩放（使用频率模式自己的 dp_pos）
                scaled_freq_show = apply_dp_scale(next_freq_show, next_dp_pos_freq);
                next_freq_word = show_to_freq_word(scaled_freq_show);
            end
            2: begin
                if (key_add) next_duty_show = (duty_show + step_value > 20'd10000) ? 20'd10000 : duty_show + step_value;
                else if (key_sub) next_duty_show = (duty_show < step_value) ? 20'd0 : duty_show - step_value;
                next_duty_cycle = (next_duty_show + 20'd50) / 20'd100;
                if (next_duty_cycle > 100) next_duty_cycle = 100;
            end
            3: begin
                // 修改：解除下限限制，允许调到 0
                if (key_add) next_amp_show = (amp_show + step_value > 20'd99999) ? 20'd99999 : amp_show + step_value;
                else if (key_sub) next_amp_show = (amp_show < step_value) ? 20'd0 : amp_show - step_value;
                next_amp_ctrl = 1; // 废弃该信号，但赋予合法默认值
            end
            4: begin
                if (key_add) next_dc_show = (dc_show + step_value > 20'd3300) ? 20'd3300 : dc_show + step_value;
                else if (key_sub) next_dc_show = (dc_show < step_value) ? 20'd0 : dc_show - step_value;
                // dp_pos 量程缩放（使用 DC 模式自己的 dp_pos）
                scaled_dc_show = apply_dp_scale(next_dc_show, next_dp_pos_dc);
                if (scaled_dc_show > 20'd3300) next_dc_offset = 8'd255;
                else next_dc_offset = (scaled_dc_show * 20'd4526) >> 16;
            end
        endcase
    end

    // ===============================================================
    // 时序逻辑段: 将next_*值锁存到输出寄存器
    // ===============================================================
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_mode <= 0;
            edit_digit <= 0; dp_pos <= 0; wave_type <= 0;
            freq_show <= 20'd500; duty_show <= 20'd5000;
            amp_show <= 20'd1000;
            dc_show <= 20'd0;
            freq_word <= 32'd21475;
            duty_cycle <= 50; amp_ctrl <= 1;
            dc_offset <= 8'd0;
            dp_pos_freq <= 0; dp_pos_amp <= 0; dp_pos_dc <= 0;
            // 所有模式的 dp_pos 初始化为 0（无小数点）
            dp_pos_arr[0] <= 0; dp_pos_arr[1] <= 0;
            dp_pos_arr[2] <= 0; dp_pos_arr[3] <= 0;
            dp_pos_arr[4] <= 0;
        end else begin
            // 首先应用按键更新
            current_mode <= next_current_mode; edit_digit <= next_edit_digit;
            // key_dp 按下时，只更新当前模式的 dp_pos
            if (key_dp) dp_pos_arr[current_mode] <= next_dp_pos;
            dp_pos <= next_dp_pos;
            dp_pos_freq <= next_dp_pos_freq;
            dp_pos_amp  <= next_dp_pos_amp;
            dp_pos_dc   <= next_dp_pos_dc;
            wave_type <= next_wave_type; freq_show <= next_freq_show; duty_show <= next_duty_show;
            amp_show <= next_amp_show; dc_show <= next_dc_show;
            freq_word <= next_freq_word;
            duty_cycle <= next_duty_cycle; amp_ctrl <= next_amp_ctrl; dc_offset <= next_dc_offset;
            
            // 独立 UART 参数更新（使用各参数自己的 dp_pos）
            if (uart_wave_update) begin
                wave_type <= uart_wave_type;
            end
            if (uart_freq_update) begin
                freq_show <= uart_freq_show;
                freq_word <= show_to_freq_word(apply_dp_scale(uart_freq_show, dp_pos_arr[1]));
            end
            if (uart_duty_update) begin
                duty_show <= uart_duty_show;
                duty_cycle <= (uart_duty_show + 20'd50) / 20'd100;
                if (((uart_duty_show + 20'd50) / 20'd100) > 100)
                    duty_cycle <= 8'd100;
            end
            if (uart_amp_update) begin
                amp_show <= uart_amp_show;
            end
            if (uart_dc_update) begin
                dc_show <= uart_dc_show;
                if (apply_dp_scale(uart_dc_show, dp_pos_arr[4]) > 20'd3300)
                    dc_offset <= 8'd255;
                else
                    dc_offset <= (apply_dp_scale(uart_dc_show, dp_pos_arr[4]) * 20'd4526) >> 16;
            end
        end
    end
endmodule