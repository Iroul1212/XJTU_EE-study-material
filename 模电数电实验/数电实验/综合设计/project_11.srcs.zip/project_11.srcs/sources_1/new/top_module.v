// =============================================================================
// 模块: top_module — FPGA多功能数字信号发生器顶层模块
// =============================================================================
// 功能: 系统顶层连线,负责将时钟分频、按键消抖、FSM控制、DDS核心、
//       数码管驱动、VGA显示、UART收发、参数上报等子模块互联。
//       实现本地按键操作与远程蓝牙控制双通道参数调节。
//
// AI参与: [AI生成] 初版模块互联框架由Gemini提供,用户进行大量适配修改:
//         (1) 时钟重算 50M→100M (2) 增加5按键支持 (3) 添加跨时钟域同步
//         (4) 添加DAC直通配置 (5) 集成UART双工通信 (6) 添加amp/dc量程换算
// =============================================================================

module top_module (
    // ── 时钟与复位 ──
    input  wire        sys_clk,      // 系统时钟 100MHz (EGO1板载晶振)
    input  wire        sys_rst_n,    // 系统复位，低电平有效，接板载按键

    // ── 按键输入（共5个）──
    input  wire        key_mode,     // 模式切换: WAVE→FREQ→DUTY→AMP→DC 循环
    input  wire        key_add,      // 参数增加 (按当前编辑数位的步进量)
    input  wire        key_sub,      // 参数减少 (按当前编辑数位的步进量)
    input  wire        key_digit,    // 编辑数位选择: 个->十->百->千->万 循环
    input  wire        key_dp,       // 小数点位置切换 (各模式独立记忆)

    // ── UART 串口 (与STM32蓝牙模块通信) ──
    input  wire        uart_rx,      // UART接收,来自STM32 (手机→蓝牙→STM32→FPGA)
    output wire        uart_tx,      // UART发送,发往STM32 (FPGA参数变化上报→手机)

    // ── EGO1 并口DAC控制 (DAC0832直通模式) ──
    // 将DAC配置为直通: 所有控制信号固定有效,数据直接输出
    output wire        dac_ile,      // 输入锁存使能,固定高=直通
    output wire        dac_cs_n,     // 片选,固定低=选中
    output wire        dac_wr1_n,    // 写1,固定低=直通
    output wire        dac_wr2_n,    // 写2,固定低=直通
    output wire        dac_xfer_n,   // 传输控制,固定低=直通
    output wire [7:0]  dac_data,     // 8位波形数据并行输出到DAC
    
    // ── 数码管接口 (EGO1共阴极8位数码管) ──
    output wire [7:0]  seg_cs,       // 8位数码管位选 (低电平选中对应位)
    output wire [7:0]  seg_data_0,   // 右侧4位数码管段选 (共阴极编码)
    output wire [7:0]  seg_data_1,   // 左侧4位数码管段选 (与data_0并联)
    
    // ── VGA 显示接口 (640×480@60Hz) ──
    output wire        vga_hs,       // VGA行同步信号
    output wire        vga_vs,       // VGA场同步信号
    output wire [11:0] vga_rgb       // VGA 12位颜色 (R[11:8] G[7:4] B[3:0])
);

    // ═══════════════════════════════════════════════════════════════
    // 内部互连信号定义
    // ═══════════════════════════════════════════════════════════════

    // ── 时钟网络 ──
    wire clk_1k, clk_50hz, vga_clk;           // 1kHz数码管扫描|50Hz按键采样|25MHz VGA

    // ── 按键消抖输出 (50Hz域) ──
    wire mode_pulse, add_pulse, sub_pulse;     // 3个基本按键脉冲
    wire digit_pulse, dp_pulse;                 // 数位/小数点按键脉冲

    // 跨时钟域同步器 (50Hz -> 100MHz)
    // 两级同步寄存器 + 边沿检测,防止亚稳态传播
    reg mode_sync0, mode_sync1, mode_sync1_d;
    reg add_sync0, add_sync1, add_sync1_d;
    reg sub_sync0, sub_sync1, sub_sync1_d;
    reg digit_sync0, digit_sync1, digit_sync1_d;
    reg dp_sync0, dp_sync1, dp_sync1_d;

    wire mode_pulse_sys;   // 同步到100MHz域的模式脉冲
    wire add_pulse_sys;    // 同步到100MHz域的增加脉冲
    wire sub_pulse_sys;    // 同步到100MHz域的减少脉冲
    wire digit_pulse_sys;  // 同步后的数位脉冲
    wire dp_pulse_sys;     // 同步后的小数点脉冲

    // ── UART 通信信号 ──
    wire [7:0]  uart_data;           // UART接收到的原始字节
    wire        uart_valid;          // UART字节有效脉冲
    wire [1:0]  uart_wave_type;      // 解析后的波形类型 (0正弦/1方波/2三角)
    wire [19:0] uart_freq_show;      // 解析后的频率显示值
    wire [19:0] uart_duty_show;      // 解析后的占空比显示值
    wire [19:0] uart_amp_show;       // 解析后的幅值显示值
    wire [19:0] uart_dc_show;        // 解析后的直流偏置显示值
    wire        uart_param_update;   // (保留兼容) 参数更新总脉冲
    // 各参数独立更新脉冲,避免未修改参数被覆盖
    wire        uart_wave_update;
    wire        uart_freq_update;
    wire        uart_duty_update;
    wire        uart_amp_update;
    wire        uart_dc_update;
    
    // ── DDS 参数 (FSM输出→DDS输入) ──
    wire [1:0]  wave_type;           // 波形选择: 00=正弦 01=方波 10=三角
    wire [31:0] freq_word;           // 32位频率控制字 K = fout * 2^32 / fclk
    wire [7:0]  duty_cycle;          // 占空比 0~100 (仅方波有效)
    wire [2:0]  amp_ctrl;            // (已废弃) 幅度衰减控制
    wire [7:0]  dc_offset;           // (已废弃) 直流偏置DAC值

    // ── 数码管显示信号 ──
    wire [2:0]  current_mode;        // 当前编辑模式 0~4
    wire [2:0]  edit_digit;          // 当前编辑数位 0~4
    wire [1:0]  dp_pos;              // 当前模式小数点位置
    wire [1:0]  dp_pos_freq, dp_pos_amp, dp_pos_dc;  // 各模式独立小数点
    wire [19:0] freq_show;           // 频率显示值 (含小数点位置信息)
    wire [19:0] duty_show;           // 占空比显示值
    wire [19:0] amp_show;            // 幅值显示值
    wire [19:0] dc_show;             // 直流偏置显示值

    // ── 波形采样与VGA信号 ──
    wire [7:0]  dds_wave;            // DDS输出的8位波形数据 (0~255)
    wire [7:0]  seg_led;             // 数码管段选编码
    wire [9:0]  wr_addr, vga_addr;   // BRAM写地址|VGA读地址
    wire [7:0]  wr_data, ram_read_data; // BRAM写数据|BRAM读数据
    wire        wr_en;               // BRAM写使能

    // ═══════════════════════════════════════════════════════════════
    // DAC0832 直通模式配置
    // EGO1板载DAC0832为8位并行接口,将所有控制信号固定为有效电平,
    // DDS波形数据不经锁存直接转换为模拟电压输出
    // ═══════════════════════════════════════════════════════════════
    assign dac_ile    = 1'b1;      // ILE=1: 输入锁存使能,允许数据进入
    assign dac_cs_n   = 1'b0;      // CS=0: 片选始终有效
    assign dac_wr1_n  = 1'b0;      // WR1=0: 第一级锁存直通
    assign dac_wr2_n  = 1'b0;      // WR2=0: 第二级锁存直通
    assign dac_xfer_n = 1'b0;      // XFER=0: 传输控制直通
    assign dac_data   = dds_wave;  // DDS 8bit数据直接送入DAC数据总线

    // ── UART 发送通道信号 ──
    wire        tx_start;          // 启动发送脉冲 (由param_reporter产生)
    wire [7:0]  tx_byte;           // 待发送字节
    wire        tx_busy;           // 发送忙标志 (握手用)
    wire        tx_line;           // UART TX物理线
    assign uart_tx = tx_line;      // 连接到FPGA输出引脚

    // ── [9] UART发送: FPGA→STM32 参数同步 (115200bps) ──
    uart_transmitter u_uart_tx (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .tx_start(tx_start), .tx_data(tx_byte),
        .tx_line(tx_line), .tx_busy(tx_busy)
    );

    // [10] 参数上报: 检测FSM参数变化,自动经UART上报至STM32
    param_reporter u_reporter (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .wave_type(wave_type), .freq_show(freq_show),
        .duty_show(duty_show), .amp_show(amp_show), .dc_show(dc_show),
        .dp_pos_freq(dp_pos_freq), .dp_pos_amp(dp_pos_amp), .dp_pos_dc(dp_pos_dc),
        .tx_start(tx_start), .tx_data(tx_byte), .tx_busy(tx_busy)
    );

    // ── 数码管段选并联: EGO1左右各4位共用同一段选编码 ──
    assign seg_data_0 = seg_led;
    assign seg_data_1 = seg_led;

    // ═══════════════════════════════════════════════════════════════
    // 跨时钟域同步器 (50Hz按键域 -> 100MHz系统域)
    // 两级同步寄存器 + 上升沿检测,消除亚稳态传播风险
    // 原理: 50Hz脉冲宽度约20ms,在100MHz域(10ns周期)被连续多次采样,
    //       通过sync0→sync1→sync1_d三级打拍后再用 &~ 检测上升沿
    // ═══════════════════════════════════════════════════════════════
    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            mode_sync0 <= 1'b0; mode_sync1 <= 1'b0; mode_sync1_d <= 1'b0;
            add_sync0  <= 1'b0; add_sync1  <= 1'b0; add_sync1_d  <= 1'b0;
            sub_sync0  <= 1'b0; sub_sync1  <= 1'b0; sub_sync1_d  <= 1'b0;
            digit_sync0 <= 1'b0; digit_sync1 <= 1'b0; digit_sync1_d <= 1'b0;
            dp_sync0 <= 1'b0; dp_sync1 <= 1'b0; dp_sync1_d <= 1'b0;
        end else begin
            mode_sync0 <= mode_pulse; mode_sync1 <= mode_sync0; mode_sync1_d <= mode_sync1;
            add_sync0  <= add_pulse;  add_sync1  <= add_sync0;  add_sync1_d  <= add_sync1;
            sub_sync0  <= sub_pulse;  sub_sync1  <= sub_sync0;  sub_sync1_d  <= sub_sync1;
            digit_sync0 <= digit_pulse; digit_sync1 <= digit_sync0; digit_sync1_d <= digit_sync1;
            dp_sync0    <= dp_pulse;    dp_sync1    <= dp_sync0;    dp_sync1_d    <= dp_sync1;
        end
    end

    // 上升沿检测: sync1_d保存上一拍值,sync1为当前值
    // 当上一拍为0、当前拍为1时,产生单周期正脉冲
    assign mode_pulse_sys = mode_sync1 & ~mode_sync1_d;
    assign add_pulse_sys  = add_sync1  & ~add_sync1_d;
    assign sub_pulse_sys  = sub_sync1  & ~sub_sync1_d;
    assign digit_pulse_sys = digit_sync1 & ~digit_sync1_d;
    assign dp_pulse_sys    = dp_sync1 & ~dp_sync1_d;

    // ═══════════════════════════════════════════════════════════════
    // 子模块实例化 (按数据流顺序: 时钟→UART→按键→FSM→DDS→显示)
    // ═══════════════════════════════════════════════════════════════

    // ── [1] 时钟分频: 100MHz → 1kHz(数码管)/50Hz(按键)/25MHz(VGA) ──
    clk_divider u_clk_div (
        .sys_clk(sys_clk), .sys_rst_n(sys_rst_n),
        .clk_1k(clk_1k), .clk_50hz(clk_50hz), .clk_25m(vga_clk)
    );

    // [1.5] UART接收+命令解析: 接收STM32蓝牙透传数据
    // 手机→蓝牙→STM32→UART→FPGA: 解析文本协议 "T,0\r\nF,1000\r\n..."
    uart_receiver u_uart_rx (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .rx(uart_rx),
        .data_out(uart_data), .data_valid(uart_valid)
    );

    uart_cmd_parser u_uart_parser (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .uart_data(uart_data), .uart_valid(uart_valid),
        .wave_type(uart_wave_type),
        .freq_show(uart_freq_show),
        .duty_show(uart_duty_show),
        .amp_show(uart_amp_show),
        .dc_show(uart_dc_show),
        .param_update(uart_param_update),
        .wave_update(uart_wave_update),
        .freq_update(uart_freq_update),
        .duty_update(uart_duty_update),
        .amp_update(uart_amp_update),
        .dc_update(uart_dc_update)
    );

    // ── [2] 按键消抖 (5个按键各实例化一次,50Hz采样) ──
    key_debounce u_key_mode (.clk(clk_50hz), .rst_n(sys_rst_n), .key_in(key_mode), .key_pulse(mode_pulse));
    key_debounce u_key_add  (.clk(clk_50hz), .rst_n(sys_rst_n), .key_in(key_add),  .key_pulse(add_pulse));
    key_debounce u_key_sub  (.clk(clk_50hz), .rst_n(sys_rst_n), .key_in(key_sub),  .key_pulse(sub_pulse));
    key_debounce u_key_digit(.clk(clk_50hz), .rst_n(sys_rst_n), .key_in(key_digit), .key_pulse(digit_pulse));
    key_debounce u_key_dp   (.clk(clk_50hz), .rst_n(sys_rst_n), .key_in(key_dp),    .key_pulse(dp_pulse));

    // ── [3] FSM状态机控制器: 管理5种编辑模式,接收按键+UART双通道输入 ──
    fsm_controller u_fsm (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .key_mode(mode_pulse_sys), .key_add(add_pulse_sys), .key_sub(sub_pulse_sys),
        .key_digit(digit_pulse_sys), .key_dp(dp_pulse_sys),
        .uart_wave_type(uart_wave_type), .uart_freq_show(uart_freq_show),
        .uart_duty_show(uart_duty_show), .uart_amp_show(uart_amp_show),
        .uart_dc_show(uart_dc_show),
        .uart_wave_update(uart_wave_update), .uart_freq_update(uart_freq_update),
        .uart_duty_update(uart_duty_update), .uart_amp_update(uart_amp_update),
        .uart_dc_update(uart_dc_update),
        .wave_type(wave_type), .freq_word(freq_word), 
        .duty_cycle(duty_cycle), .amp_ctrl(amp_ctrl), .dc_offset(dc_offset),
        .current_mode(current_mode),
        .edit_digit(edit_digit), .dp_pos(dp_pos),
        .dp_pos_freq(dp_pos_freq), .dp_pos_amp(dp_pos_amp), .dp_pos_dc(dp_pos_dc),
        .freq_show(freq_show), .duty_show(duty_show),
        .amp_show(amp_show), .dc_show(dc_show)
    );

    // 幅值/偏置量程换算
    // 数码管显示值包含小数点信息,需根据各模式独立的 dp_pos 换算为实际mV值
    // 公式: actual_mV = display_value / 10^dp_pos
    wire [19:0] actual_amp_mV;
    assign actual_amp_mV = (dp_pos_amp == 2'd0) ? amp_show :
                           (dp_pos_amp == 2'd1) ? (amp_show / 10)  :
                           (dp_pos_amp == 2'd2) ? (amp_show / 100) :
                                                   (amp_show / 1000);

    // dc_show 单位为 mV，用 DC 模式自己的 dp_pos 切换量程
    wire [19:0] actual_dc_mV;
    assign actual_dc_mV = (dp_pos_dc == 2'd0) ? dc_show :
                          (dp_pos_dc == 2'd1) ? (dc_show / 10)  :
                          (dp_pos_dc == 2'd2) ? (dc_show / 100) :
                                                 (dc_show / 1000);

    // ── [4] DDS核心: 相位累加+波形查找+幅值/偏置运算 ──
    // 传入经过 dp_pos 换算后的实际物理值 (mV)
    dds_core u_dds (
        .sys_clk(sys_clk), .rst_n(sys_rst_n),
        .wave_type(wave_type), .freq_word(freq_word),
        .duty_cycle(duty_cycle), .amp_mV(actual_amp_mV), .dc_mV(actual_dc_mV),
        .wave_out(dds_wave)
    );

    // ── [5] 数码管驱动: 8位动态扫描,显示当前模式/波形/参数值 ──
    seg_driver u_seg (
        .clk_1k(clk_1k), .rst_n(sys_rst_n),
        .current_mode(current_mode), .wave_type(wave_type), 
        .edit_digit(edit_digit), .dp_pos(dp_pos),
        .freq_show(freq_show), .duty_show(duty_show),
        .amp_show(amp_show), .dc_show(dc_show),
        .seg_sel(seg_cs), .seg_led(seg_led)
    );

    // [6] 波形采样器: 捕获-冻结模式,每2秒刷新一轮640点
    wave_sampler u_sampler (
        .clk(sys_clk), .rst_n(sys_rst_n),
        .adc_data(dds_wave),
        .wr_addr(wr_addr), .wr_data(wr_data), .wr_en(wr_en)
    );

    // ── [7] 双口Block RAM: A口(sampler写,100MHz) B口(VGA读,25MHz) ──
    // 需在Vivado中使用Block Memory Generator IP生成,配置为True Dual Port
    blk_mem_gen_0 u_ram (
        .clka(sys_clk),  .ena(1'b1), .wea(wr_en), .addra(wr_addr), .dina(wr_data), 
        .clkb(vga_clk),  .addrb(vga_addr), .doutb(ram_read_data)       
    );

    // ── [8] VGA显示: 640×480@60Hz,网格+刻度+波形曲线 ──
    vga_display u_vga (
        .vga_clk(vga_clk), .rst_n(sys_rst_n), .wave_data(ram_read_data),
        .vga_hs(vga_hs), .vga_vs(vga_vs),
        .vga_r(vga_rgb[11:8]), .vga_g(vga_rgb[7:4]), .vga_b(vga_rgb[3:0]),
        .wave_addr(vga_addr)
    );

endmodule