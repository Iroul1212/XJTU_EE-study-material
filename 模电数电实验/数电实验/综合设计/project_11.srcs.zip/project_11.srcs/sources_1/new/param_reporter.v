// =============================================================================
// 模块: param_reporter - FPGA->STM32参数变化上报
// =============================================================================
// 功能: 持续监测FSM输出参数变化,检测到任何参数改变时自动经UART发送
//       5字节二进制协议包至STM32,实现FPGA按键操作->手机App双向同步。
//       协议: [0xAA] [CMD] [Data19:12] [Data11:4] [Data3:0]
//       特性: 上电延时10ms后首次上报, 各参数独立变化检测,
//             dp_pos量程缩放(各模式使用自己的dp_pos), 发送握手防冲突
//
// =============================================================================
module param_reporter (
    input  wire        clk,
    input  wire        rst_n,

    // 当前参数值 (来自 FSM) + 各模式独立的小数点位置
    input  wire [1:0]  wave_type,
    input  wire [19:0] freq_show,
    input  wire [19:0] duty_show,
    input  wire [19:0] amp_show,
    input  wire [19:0] dc_show,
    input  wire [1:0]  dp_pos_freq,    // 频率模式自己的 dp_pos
    input  wire [1:0]  dp_pos_amp,     // 幅度模式自己的 dp_pos
    input  wire [1:0]  dp_pos_dc,      // DC 模式自己的 dp_pos

    // UART 发送接口
    output reg         tx_start,
    output reg  [7:0]  tx_data,
    input  wire        tx_busy
);

    // 上次已上报的参数值 (复位时故意设成与FSM默认值不同的值，触发上电自动上报)
    reg [1:0]   prev_wave;
    reg [19:0]  prev_freq;
    reg [19:0]  prev_duty;
    reg [19:0]  prev_amp;
    reg [19:0]  prev_dc;

    // ── 使用各模式自己的 dp_pos 做量程缩放（全统一为 ÷10^dp） ──
    wire [19:0] scaled_freq = (dp_pos_freq == 2'd0) ? freq_show :
                              (dp_pos_freq == 2'd1) ? (freq_show / 10) :
                              (dp_pos_freq == 2'd2) ? (freq_show / 100) :
                                                      (freq_show / 1000);

    wire [19:0] scaled_amp = (dp_pos_amp == 2'd0) ? amp_show :
                             (dp_pos_amp == 2'd1) ? (amp_show / 10)  :
                             (dp_pos_amp == 2'd2) ? (amp_show / 100) :
                                                     (amp_show / 1000);

    wire [19:0] scaled_dc = (dp_pos_dc == 2'd0) ? dc_show :
                            (dp_pos_dc == 2'd1) ? (dc_show / 10) :
                            (dp_pos_dc == 2'd2) ? (dc_show / 100) :
                                                   (dc_show / 1000);

    // 上电延时计数器，等10ms后再开始上报（避免FPGA刚配置完就发数据）
    reg [23:0]  init_timer;  // 100MHz * 10ms = 1,000,000
    reg         init_done;

    // 变化检测（用缩放后的物理值比较，各参数独立）
    wire wave_chg = (wave_type != prev_wave);
    wire freq_chg = (scaled_freq != prev_freq);
    wire duty_chg = (duty_show != prev_duty);
    wire amp_chg  = (scaled_amp  != prev_amp);
    wire dc_chg   = (scaled_dc   != prev_dc);

    // 上报状态机（修正握手：先等 busy 变高，再等 busy 变低）
    localparam IDLE       = 3'd0;
    localparam TX_START   = 3'd1;  // 发出 tx_start 脉冲
    localparam WAIT_HI    = 3'd2;  // 等 tx_busy 变高
    localparam WAIT_LO    = 3'd3;  // 等 tx_busy 变低

    reg [2:0]   state;
    reg [7:0]   cmd_byte;
    reg [19:0]  param_val;
    reg [2:0]   byte_cnt;   // 0=HDR, 1=CMD, 2=DH, 3=DM, 4=DL

    wire any_change = wave_chg || freq_chg || duty_chg || amp_chg || dc_chg;

    // 当前要发的字节
    wire [7:0] cur_byte = (byte_cnt == 0) ? 8'hAA :
                          (byte_cnt == 1) ? cmd_byte :
                          (byte_cnt == 2) ? param_val[19:12] :
                          (byte_cnt == 3) ? param_val[11:4]  :
                                             {4'd0, param_val[3:0]};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state      <= IDLE;
            tx_start   <= 1'b0;
            tx_data    <= 8'd0;
            cmd_byte   <= 8'd0;
            param_val  <= 20'd0;
            byte_cnt   <= 3'd0;
            prev_wave  <= 2'd3;
            prev_freq  <= 20'hFFFFF;
            prev_duty  <= 20'hFFFFF;
            prev_amp   <= 20'hFFFFF;
            prev_dc    <= 20'hFFFFF;
            init_timer <= 24'd0;
            init_done  <= 1'b0;
        end else begin
            tx_start <= 1'b0;

            if (!init_done) begin
                if (init_timer < 24'd1_000_000)
                    init_timer <= init_timer + 1;
                else
                    init_done <= 1'b1;
            end

            case (state)
                IDLE: begin
                    if (init_done && any_change) begin
                        if (wave_chg) begin
                            cmd_byte <= 8'h01; param_val <= {18'd0, wave_type}; prev_wave <= wave_type;
                        end else if (freq_chg) begin
                            cmd_byte <= 8'h04; param_val <= scaled_freq; prev_freq <= scaled_freq;
                        end else if (duty_chg) begin
                            cmd_byte <= 8'h05; param_val <= duty_show; prev_duty <= duty_show;
                        end else if (amp_chg) begin
                            cmd_byte <= 8'h06; param_val <= scaled_amp;  prev_amp  <= scaled_amp;
                        end else begin
                            cmd_byte <= 8'h07; param_val <= scaled_dc;   prev_dc   <= scaled_dc;
                        end
                        byte_cnt <= 3'd0;
                        state    <= TX_START;
                    end
                end

                TX_START: begin
                    tx_start <= 1'b1;
                    tx_data  <= cur_byte;
                    state    <= WAIT_HI;
                end

                WAIT_HI: begin
                    // 等发送器抓取字节，tx_busy 变高
                    if (tx_busy)
                        state <= WAIT_LO;
                end

                WAIT_LO: begin
                    // 等发送器完成，tx_busy 变低
                    if (!tx_busy) begin
                        if (byte_cnt < 4) begin
                            byte_cnt <= byte_cnt + 1;
                            state    <= TX_START;
                        end else begin
                            state <= IDLE;
                        end
                    end
                end

                default: state <= IDLE;
            endcase
        end
    end

endmodule
