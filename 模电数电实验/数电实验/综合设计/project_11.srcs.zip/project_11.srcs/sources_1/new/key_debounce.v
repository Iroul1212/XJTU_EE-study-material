// =============================================================================
// 模块: key_debounce - 按键消抖模块 (移位寄存器法)
// =============================================================================
// 功能: 以50Hz采样按键输入,通过3位移位寄存器检测下降沿(3'b110),
//       输出单周期正脉冲。20ms采样间隔足以覆盖机械按键抖动窗口。
//
// AI参与: [AI生成] Gemini提供移位寄存器消抖框架
// =============================================================================
module key_debounce (
    input wire clk,       // 50Hz采样时钟
    input wire rst_n,     // 复位
    input wire key_in,    // 按键原始输入 (按下=0,松开=1)
    output wire key_pulse // 消抖后单周期正脉冲 (检测到按下时输出1)
);
    reg [2:0] key_shift;
    // [AI生成] 移位寄存器法消抖: 连续3次采样一致则判定稳定
    // 检测序列 3'b110 (高->低下降沿) = 按键按下, 输出单周期脉冲
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) key_shift <= 3'b111;
        else key_shift <= {key_shift[1:0], key_in};
    end
    assign key_pulse = (key_shift == 3'b110);
endmodule