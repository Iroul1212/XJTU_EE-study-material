// =============================================================================
// 模块: vga_display - VGA波形显示模块 (640x480@60Hz)
// =============================================================================
// 功能: 从BRAM读取波形数据,生成标准VGA时序,在屏幕上绘制:
//       - 绿色波形曲线 (wave_y = 240 + 128 - wave_data)
//       - 灰色暗网格 (水平80像素/格, 垂直60像素/格)
//       - 蓝色0V基准线 (Y=240)
//       - 黄色刻度标记 (网格交叉点+左侧短刻度线)
//       - 白色纵轴量程标签 (-1.5V ~ +2.0V, 5x7点阵字体)
//       - 纯黑背景
//
// AI参与: [AI生成] Gemini提供VGA时序参数和基本坐标映射框架
//         (1) 5x7点阵字体渲染(glyph5x7函数,支持0-9/+/-/./V/m/s)
//                    (2) 网格坐标系统+刻度标注(scale_label_char)
//                    (3) BRAM读延迟打拍适配(h_cnt_d/v_cnt_d)
//                    (4) 从时间坐标轴改为静态纵轴量程标注
// =============================================================================

module vga_display (
    // -- 时钟与复位 --
    input wire vga_clk,           // VGA像素时钟 25MHz
    input wire rst_n,             // 异步复位

    // -- 波形数据输入 (来自BRAM B端口) --
    input wire [7:0] wave_data,   // 8位波形采样值 (0~255)

    // -- VGA时序输出 --
    output reg vga_hs,            // 行同步 (低有效脉冲)
    output reg vga_vs,            // 场同步 (低有效脉冲)

    // -- VGA颜色输出 (12位: R[11:8] G[7:4] B[3:0]) --
    output reg [3:0] vga_r,       // 红色分量 0~15
    output reg [3:0] vga_g,       // 绿色分量 0~15
    output reg [3:0] vga_b,       // 蓝色分量 0~15

    // -- BRAM读地址 (提前1周期送出, 下一周期返回数据) --
    output wire [9:0] wave_addr   // 10位读地址 (0~639对应屏幕x坐标)
);

    // ===============================================================
    // VGA时序参数 (640x480@60Hz, 25MHz像素时钟)
    // 一行: 800像素 = 640(有效) + 16(前肩) + 96(同步) + 48(后肩)
    // 一帧: 525行   = 480(有效) + 10(前肩) + 2(同步)  + 33(后肩)
    // ===============================================================
    parameter H_ACTIVE = 640, H_FP = 16, H_SYNC = 96, H_BP = 48, H_TOTAL = 800;
    parameter V_ACTIVE = 480, V_FP = 10, V_SYNC = 2,  V_BP = 33, V_TOTAL = 525;
    
    reg [9:0] h_cnt, v_cnt;

    // 5x7点阵字体渲染函数
    // 每个字符7行(row 0~6) x 5列, bit=1表示点亮该像素
    // 支持: 0-9, +, -, ., V, m, s
    function [4:0] glyph5x7;
        input [7:0] ch;
        input [2:0] row;
        begin
            case (ch)
                "+": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b00100;
                        3'd1: glyph5x7 = 5'b00100;
                        3'd2: glyph5x7 = 5'b11111;
                        3'd3: glyph5x7 = 5'b00100;
                        3'd4: glyph5x7 = 5'b00100;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "-": begin
                    case (row)
                        3'd2: glyph5x7 = 5'b11111;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                ".": begin
                    case (row)
                        3'd5: glyph5x7 = 5'b00100;
                        3'd6: glyph5x7 = 5'b00100;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "0": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b01110;
                        3'd1: glyph5x7 = 5'b10001;
                        3'd2: glyph5x7 = 5'b10011;
                        3'd3: glyph5x7 = 5'b10101;
                        3'd4: glyph5x7 = 5'b11001;
                        3'd5: glyph5x7 = 5'b10001;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "1": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b00100;
                        3'd1: glyph5x7 = 5'b01100;
                        3'd2: glyph5x7 = 5'b00100;
                        3'd3: glyph5x7 = 5'b00100;
                        3'd4: glyph5x7 = 5'b00100;
                        3'd5: glyph5x7 = 5'b00100;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "2": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b01110;
                        3'd1: glyph5x7 = 5'b10001;
                        3'd2: glyph5x7 = 5'b00001;
                        3'd3: glyph5x7 = 5'b00010;
                        3'd4: glyph5x7 = 5'b00100;
                        3'd5: glyph5x7 = 5'b01000;
                        3'd6: glyph5x7 = 5'b11111;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "3": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b01110;
                        3'd1: glyph5x7 = 5'b10001;
                        3'd2: glyph5x7 = 5'b00001;
                        3'd3: glyph5x7 = 5'b00110;
                        3'd4: glyph5x7 = 5'b00001;
                        3'd5: glyph5x7 = 5'b10001;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "4": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b00010;
                        3'd1: glyph5x7 = 5'b00110;
                        3'd2: glyph5x7 = 5'b01010;
                        3'd3: glyph5x7 = 5'b10010;
                        3'd4: glyph5x7 = 5'b11111;
                        3'd5: glyph5x7 = 5'b00010;
                        3'd6: glyph5x7 = 5'b00010;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "5": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b11111;
                        3'd1: glyph5x7 = 5'b10000;
                        3'd2: glyph5x7 = 5'b11110;
                        3'd3: glyph5x7 = 5'b00001;
                        3'd4: glyph5x7 = 5'b00001;
                        3'd5: glyph5x7 = 5'b10001;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "6": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b00110;
                        3'd1: glyph5x7 = 5'b01000;
                        3'd2: glyph5x7 = 5'b11110;
                        3'd3: glyph5x7 = 5'b10001;
                        3'd4: glyph5x7 = 5'b10001;
                        3'd5: glyph5x7 = 5'b10001;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "8": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b01110;
                        3'd1: glyph5x7 = 5'b10001;
                        3'd2: glyph5x7 = 5'b01110;
                        3'd3: glyph5x7 = 5'b10001;
                        3'd4: glyph5x7 = 5'b10001;
                        3'd5: glyph5x7 = 5'b10001;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "m": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b00000;
                        3'd1: glyph5x7 = 5'b11010;
                        3'd2: glyph5x7 = 5'b10101;
                        3'd3: glyph5x7 = 5'b10101;
                        3'd4: glyph5x7 = 5'b10101;
                        3'd5: glyph5x7 = 5'b10101;
                        3'd6: glyph5x7 = 5'b10101;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "s": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b01111;
                        3'd1: glyph5x7 = 5'b10000;
                        3'd2: glyph5x7 = 5'b01110;
                        3'd3: glyph5x7 = 5'b00001;
                        3'd4: glyph5x7 = 5'b00001;
                        3'd5: glyph5x7 = 5'b10001;
                        3'd6: glyph5x7 = 5'b01110;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                "V": begin
                    case (row)
                        3'd0: glyph5x7 = 5'b10001;
                        3'd1: glyph5x7 = 5'b10001;
                        3'd2: glyph5x7 = 5'b10001;
                        3'd3: glyph5x7 = 5'b01010;
                        3'd4: glyph5x7 = 5'b01010;
                        3'd5: glyph5x7 = 5'b00100;
                        3'd6: glyph5x7 = 5'b00100;
                        default: glyph5x7 = 5'b00000;
                    endcase
                end
                default: glyph5x7 = 5'b00000;
            endcase
        end
    endfunction

    // 纵轴量程标签字符映射
    // idx 0~7 对应8条网格线,各标签为4~5字符 (如 "2.0V", "-1.5V")
    function [7:0] scale_label_char;
        input [2:0] idx;
        input [2:0] pos;
        begin
            case (idx)
                3'd0: case (pos) 3'd0: scale_label_char = "2"; 3'd1: scale_label_char = "."; 3'd2: scale_label_char = "0"; 3'd3: scale_label_char = "V"; default: scale_label_char = " "; endcase
                3'd1: case (pos) 3'd0: scale_label_char = "1"; 3'd1: scale_label_char = "."; 3'd2: scale_label_char = "5"; 3'd3: scale_label_char = "V"; default: scale_label_char = " "; endcase
                3'd2: case (pos) 3'd0: scale_label_char = "1"; 3'd1: scale_label_char = "."; 3'd2: scale_label_char = "0"; 3'd3: scale_label_char = "V"; default: scale_label_char = " "; endcase
                3'd3: case (pos) 3'd0: scale_label_char = "0"; 3'd1: scale_label_char = "."; 3'd2: scale_label_char = "5"; 3'd3: scale_label_char = "V"; default: scale_label_char = " "; endcase
                3'd4: case (pos) 3'd0: scale_label_char = "0"; 3'd1: scale_label_char = "."; 3'd2: scale_label_char = "0"; 3'd3: scale_label_char = "V"; default: scale_label_char = " "; endcase
                3'd5: case (pos) 3'd0: scale_label_char = "-"; 3'd1: scale_label_char = "0"; 3'd2: scale_label_char = "."; 3'd3: scale_label_char = "5"; 3'd4: scale_label_char = "V"; default: scale_label_char = " "; endcase
                3'd6: case (pos) 3'd0: scale_label_char = "-"; 3'd1: scale_label_char = "1"; 3'd2: scale_label_char = "."; 3'd3: scale_label_char = "0"; 3'd4: scale_label_char = "V"; default: scale_label_char = " "; endcase
                default: case (pos) 3'd0: scale_label_char = "-"; 3'd1: scale_label_char = "1"; 3'd2: scale_label_char = "."; 3'd3: scale_label_char = "5"; 3'd4: scale_label_char = "V"; default: scale_label_char = " "; endcase
            endcase
        end
    endfunction

    // ===============================================================
    // [1] 行列坐标计数: 驱动VGA扫描时序
    // h_cnt: 0~799(行内), v_cnt: 0~524(帧内)
    // ===============================================================
    always @(posedge vga_clk or negedge rst_n) begin
        if (!rst_n) begin 
            h_cnt <= 0;
            v_cnt <= 0; 
        end else begin
            if (h_cnt == H_TOTAL - 1) begin 
                h_cnt <= 0;
                v_cnt <= (v_cnt == V_TOTAL - 1) ? 0 : v_cnt + 1;
            end else h_cnt <= h_cnt + 1;
        end
    end
    
    // ===============================================================
    // [2] 同步信号生成: 在消隐区产生负脉冲
    // HSYNC: h_cnt在 [640+16, 640+16+96) 区间为低
    // VSYNC: v_cnt在 [480+10, 480+10+2) 区间为低
    // ===============================================================
    reg vga_hs_pre, vga_vs_pre;
    always @(posedge vga_clk) begin
        vga_hs_pre <= ((h_cnt >= (H_ACTIVE + H_FP)) && (h_cnt < (H_ACTIVE + H_FP + H_SYNC))) ? 1'b0 : 1'b1;
        vga_vs_pre <= ((v_cnt >= (V_ACTIVE + V_FP)) && (v_cnt < (V_ACTIVE + V_FP + V_SYNC))) ? 1'b0 : 1'b1;
        vga_hs <= vga_hs_pre;
        vga_vs <= vga_vs_pre;
    end
    
    // BRAM读地址: 当前周期送出,下周期返回wave_data
    assign wave_addr = (h_cnt < H_ACTIVE) ? h_cnt[9:0] : 10'd0;
    
    // ===============================================================
    // [3] BRAM读延迟打拍: 坐标推迟1周期等待BRAM数据对齐
    // ===============================================================
    reg [9:0] h_cnt_d, v_cnt_d;
    reg video_on_d;
    always @(posedge vga_clk) begin
        h_cnt_d <= h_cnt;
        v_cnt_d <= v_cnt;
        video_on_d <= (h_cnt < H_ACTIVE) && (v_cnt < V_ACTIVE);
    end
    
    // ===============================================================
    // [4] 坐标映射与图形元素判断
    // ===============================================================

    // 波形居中映射: wave_data=128(DAC中点) -> 屏幕Y=240(0.0V网格线)
    wire [9:0] wave_y = 10'd240 + 10'd128 - {2'b00, wave_data};
    
    // 网格线: 垂直每80像素(v_cnt_d%60==0), 水平每60像素(h_cnt_d%80==0)
    wire grid_on = ((v_cnt_d % 60 == 0) || (h_cnt_d % 80 == 0));
    
    // 蓝色0V基准线: Y=240,对齐0.0V网格线
    wire baseline_on = (v_cnt_d == 240);
    
    // 刻度标记: 网格交叉点(Y=240+-2, X为80的倍数) + 左侧短刻度(h<6, Y为60的倍数)
    wire tick_on = ((v_cnt_d >= 238) && (v_cnt_d <= 242) && (h_cnt_d % 80 == 0)) ||
                   ((h_cnt_d < 6) && (v_cnt_d % 60 == 0));

    wire [2:0] scale_idx = v_cnt_d / 60;
    wire [5:0] scale_row = v_cnt_d - (scale_idx * 60);
    wire [2:0] scale_col = (h_cnt_d >= 8 && h_cnt_d < 38) ? ((h_cnt_d - 8) / 6) : 3'd7;
    wire [2:0] scale_glyph_col = (h_cnt_d >= 8 && h_cnt_d < 38) ? ((h_cnt_d - 8) - (((h_cnt_d - 8) / 6) * 6)) : 3'd7;
    wire [7:0] scale_char = scale_label_char(scale_idx, scale_col);
    wire [4:0] scale_bits = glyph5x7(scale_char, scale_row[2:0]);
    wire scale_text_on = video_on_d && (h_cnt_d >= 8) && (h_cnt_d < 38) && (scale_row < 7) && (scale_char != 8'h20) && (scale_glyph_col < 5) && scale_bits[4 - scale_glyph_col];
    
    // ===============================================================
    // [5] 像素渲染: 按优先级输出颜色值
    // 优先级: 刻度文字(白) > 波形(绿) > 刻度标记(黄) > 0V线(蓝) > 网格(灰) > 背景(黑)
    // ===============================================================
    always @(posedge vga_clk) begin
        if (!video_on_d) {vga_r, vga_g, vga_b} <= 12'h000;
        else begin
            if (scale_text_on)          {vga_r, vga_g, vga_b} <= 12'hFFF; // 纵轴刻度数值/单位
            else if (v_cnt_d == wave_y) {vga_r, vga_g, vga_b} <= 12'h0F0; // 绿色波形
            else if (tick_on)           {vga_r, vga_g, vga_b} <= 12'hFF0; // 黄色刻度
            else if (baseline_on)       {vga_r, vga_g, vga_b} <= 12'hF00; // 蓝色 0V 基准线
            else if (grid_on)           {vga_r, vga_g, vga_b} <= 12'h333; // 灰色暗网格
            else                        {vga_r, vga_g, vga_b} <= 12'h000; // 纯黑背景
        end
    end
endmodule