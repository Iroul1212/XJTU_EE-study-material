/**
 * 命令解析模块 - UART文本协议解析器
 * 接收来自UART的字符流，解析波形参数命令
 * 
 * 协议格式说明:
 * T,0\r\n      - 设置波形类型: 0=正弦, 1=方波, 2=三角波
 * F,1000\r\n   - 设置频率 (0-99999 Hz)
 * D,5000\r\n   - 设置占空比 (0-10000, 即0-100%)
 * A,1000\r\n   - 设置幅度 (0-99999 mV)
 * O,500\r\n    - 设置直流偏移 (0-3300 mV)
 * 
 * 例如通过蓝牙发送: "T,1\r\nF,2000\r\nA,1500\r\n"
 * 
 * 特性: 4状态FSM, 超时看门狗(1ms), 非法字符过滤, 各参数独立更新脉冲
 * AI参与: [AI生成] Gemini提供基础协议格式建议, 完整状态机+看门狗
 */

module uart_cmd_parser (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [7:0]  uart_data,
    input  wire        uart_valid,
    
    // 输出参数
    output reg  [1:0]  wave_type,
    output reg  [19:0] freq_show,
    output reg  [19:0] duty_show,
    output reg  [19:0] amp_show,
    output reg  [19:0] dc_show,
    
    // 独立更新脉冲（指示哪个参数刚被更新）
    output reg         param_update,   // 保留兼容
    output reg         wave_update,
    output reg         freq_update,
    output reg         duty_update,
    output reg         amp_update,
    output reg         dc_update
);

    // 定义状态
    localparam IDLE       = 4'd0;
    localparam CMD_WAIT   = 4'd1;
    localparam NUM_READ   = 4'd2;
    localparam END_WAIT   = 4'd3;
    
    reg [3:0]   state;
    reg [7:0]   cmd_char;           // 命令类型 ('T', 'F', 'D', 'A', 'O')
    reg [19:0]  num_buffer;         // 数字缓冲（最大5位数字）
    reg [2:0]   digit_count;        // 收到的数字位数
    
    // 看门狗计数器: 1ms内无有效字节则自动复位状态机
    // 防止因蓝牙断连/数据丢失导致状态机永久卡死
    // 100MHz * 1ms = 100,000 cycles ~= 17 bits
    reg [16:0]  wdog_cnt;           // 看门狗计数器
    
    // ASCII码定义
    localparam COMMA = 8'h2C;        // ','
    localparam CR    = 8'h0D;        // '\r'
    localparam LF    = 8'h0A;        // '\n'
    
    // 判断是否为命令字母 (A-Z 或 a-z，排除数字和符号)
    wire is_cmd_letter = (uart_data >= 8'h41 && uart_data <= 8'h5A) ||
                         (uart_data >= 8'h61 && uart_data <= 8'h7A);
    
    // 状态机主逻辑 (4状态: IDLE->CMD_WAIT->NUM_READ->END_WAIT)
    // 任何状态下遇到异常字符时自动恢复IDLE,防止永久卡死
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= IDLE;
            cmd_char <= 8'd0;
            num_buffer <= 20'd0;
            digit_count <= 3'd0;
            param_update <= 1'b0;
            wave_update  <= 1'b0;
            freq_update  <= 1'b0;
            duty_update  <= 1'b0;
            amp_update   <= 1'b0;
            dc_update    <= 1'b0;
            wave_type <= 2'd0;
            freq_show <= 20'd500;
            duty_show <= 20'd5000;
            amp_show <= 20'd1000;
            dc_show <= 20'd0;
            wdog_cnt <= 17'd0;
        end else begin
            // 默认清零所有脉冲信号
            param_update <= 1'b0;
            wave_update  <= 1'b0;
            freq_update  <= 1'b0;
            duty_update  <= 1'b0;
            amp_update   <= 1'b0;
            dc_update    <= 1'b0;
            
            // 看门狗：在非 IDLE 状态下计时，超时自动复位
            if (state != IDLE) begin
                if (uart_valid)
                    wdog_cnt <= 17'd0;          // 收到任何字节，清零计时器
                else if (wdog_cnt < 17'd100_000)
                    wdog_cnt <= wdog_cnt + 1;
                else begin
                    // 超过 1ms 无有效数据 → 强制回 IDLE
                    state <= IDLE;
                    wdog_cnt <= 17'd0;
                end
            end else begin
                wdog_cnt <= 17'd0;
            end
            
            case (state)
                IDLE: begin
                    // 等待命令字母 (A-Z/a-z)
                    if (uart_valid) begin
                        if (is_cmd_letter) begin
                            cmd_char <= uart_data;
                            state <= CMD_WAIT;
                        end
                        // 非字母字符(数字/符号/CR/LF)直接忽略，保持在IDLE
                    end
                end
                
                CMD_WAIT: begin
                    // 等待逗号；遇到异常字符时自动恢复
                    if (uart_valid) begin
                        if (uart_data == COMMA) begin
                            // 正常收到逗号 → 准备读取数字
                            num_buffer <= 20'd0;
                            digit_count <= 3'd0;
                            state <= NUM_READ;
                        end else if (is_cmd_letter) begin
                            // 又来了一个命令字母(上一条的逗号丢了)
                            // → 用新命令覆盖，保持在 CMD_WAIT
                            cmd_char <= uart_data;
                        end else if (uart_data == CR || uart_data == LF) begin
                            // 无效：只有命令字母没有逗号和数字 → 回 IDLE
                            state <= IDLE;
                        end
                        // 数字等其他字符：忽略，继续等逗号
                    end
                end
                
                NUM_READ: begin
                    // 读取数字，遇到终止符或新命令时退出
                    if (uart_valid) begin
                        if (uart_data >= 8'h30 && uart_data <= 8'h39) begin
                            // 正常数字，累加
                            num_buffer <= num_buffer * 20'd10 + (uart_data - 8'h30);
                            digit_count <= digit_count + 1;
                        end else if (uart_data == CR || uart_data == LF) begin
                            // 终止符 → 提交当前参数
                            state <= END_WAIT;
                            param_update <= 1'b1;
                            case (cmd_char)
                                8'h54, 8'h74: begin  // 'T'/'t'
                                    wave_type <= num_buffer[1:0];
                                    wave_update <= 1'b1;
                                end
                                8'h46, 8'h66: begin  // 'F'/'f'
                                    freq_show <= num_buffer;
                                    freq_update <= 1'b1;
                                end
                                8'h44, 8'h64: begin  // 'D'/'d'
                                    duty_show <= num_buffer;
                                    duty_update <= 1'b1;
                                end
                                8'h41, 8'h61: begin  // 'A'/'a'
                                    amp_show <= num_buffer;
                                    amp_update <= 1'b1;
                                end
                                8'h4F, 8'h6F: begin  // 'O'/'o'
                                    dc_show <= num_buffer;
                                    dc_update <= 1'b1;
                                end
                            endcase
                        end else if (is_cmd_letter) begin
                            // 新命令字母(上一条的终止符丢了)
                            // → 丢弃当前数字，开启新命令
                            cmd_char <= uart_data;
                            num_buffer <= 20'd0;
                            digit_count <= 3'd0;
                            state <= CMD_WAIT;
                        end else if (uart_data == COMMA) begin
                            // 多余逗号 → 重置数字累加，继续等数字
                            num_buffer <= 20'd0;
                            digit_count <= 3'd0;
                        end
                        // 其他字符：忽略，继续等数字或终止符
                    end
                end
                
                END_WAIT: begin
                    // 等待剩余的 \r 或 \n；遇到新命令直接切换
                    if (uart_valid) begin
                        if (uart_data == CR || uart_data == LF) begin
                            // 正常结束 → 回 IDLE
                            state <= IDLE;
                        end else if (is_cmd_letter) begin
                            // 新命令直接开始(跳过残留的终止符等待)
                            cmd_char <= uart_data;
                            state <= CMD_WAIT;
                        end
                        // 其他字符：可能是噪声，忽略并继续等
                    end
                end
                
                default: state <= IDLE;
            endcase
        end
    end

endmodule
