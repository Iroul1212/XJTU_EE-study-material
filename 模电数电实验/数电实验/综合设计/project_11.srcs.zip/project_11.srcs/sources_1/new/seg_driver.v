// =============================================================================
// 模块: seg_driver - 8位数码管动态扫描驱动 (EGO1共阴极)
// =============================================================================
// 功能: 以1kHz频率动态扫描8位数码管,根据当前模式显示对应参数值。
//       显示格式: [模式号] [波形类型] [空白] [5位参数值]
//       支持: 前导零消隐、小数点位置控制(dp_pos)、共阴极段选编码
//
// AI参与: [AI生成] Gemini提供动态扫描框架(位选编码+段选译码)
//         (1) 段选表从共阳极改为EGO1共阴极编码
//                    (2) display_value按模式选择不同参数源
//                    (3) 前导零消隐(高位为0时不显示)
//                    (4) dp_pos可视小数点渲染
//                    (5) 占空比模式强制小数点在百分位(dp_pos=1)
// =============================================================================

module seg_driver (
    input wire clk_1k,            // 1kHz扫描时钟 (来自clk_divider)
    input wire rst_n,             // 异步复位

    // -- 状态信息 (来自FSM) --
    input wire [2:0] current_mode,// 当前编辑模式 0~4
    input wire [1:0] wave_type,   // 波形类型 0~2
    input wire [2:0] edit_digit,  // 当前编辑数位 (用于指示正在编辑的位)
    input wire [1:0] dp_pos,      // 当前模式小数点位置 0~3

    // -- 各参数显示值 (来自FSM,含小数点信息) --
    input wire [19:0] freq_show,  // 频率显示值
    input wire [19:0] duty_show,  // 占空比显示值
    input wire [19:0] amp_show,   // 幅值显示值
    input wire [19:0] dc_show,    // 偏置显示值

    // -- 数码管硬件接口 --
    output reg [7:0] seg_sel,     // 8位位选 (低电平选中对应位)
    output reg [7:0] seg_led      // 8段段选 (共阴极,1=点亮)
);

    reg [2:0] scan_cnt;           // 扫描计数器 0~7
    reg [3:0] display_num;        // 当前位要显示的数字 0~15
    reg seg_dp;                   // 当前位小数点 (1=点亮)
    reg [19:0] display_value;     // 当前模式对应的显示值

    // 共阴极段选编码表 (EGO1适配)
    // 段顺序: a(0) b(1) c(2) d(3) e(4) f(5) g(6) dp(7)
    // 共阴极: 1=段点亮, 0=段熄灭
    function [7:0] seg_encode;
        input [3:0] num;
        begin
            case (num)
                4'd0: seg_encode = 8'b0111_1110;
                4'd1: seg_encode = 8'b0011_0000;
                4'd2: seg_encode = 8'b0110_1101;
                4'd3: seg_encode = 8'b0111_1001;
                4'd4: seg_encode = 8'b0011_0011;
                4'd5: seg_encode = 8'b0101_1011;
                4'd6: seg_encode = 8'b0101_1111;
                4'd7: seg_encode = 8'b0111_0000;
                4'd8: seg_encode = 8'b0111_1111;
                4'd9: seg_encode = 8'b0111_1011;
                default: seg_encode = 8'b0000_0000;
            endcase
        end
    endfunction

    // 共阴极段选表 (EGO1适配)
    // 段序: a=bit0, b=bit1, c=bit2, d=bit3, e=bit4, f=bit5, g=bit6, dp=bit7
    always @(posedge clk_1k or negedge rst_n) begin
        if (!rst_n) scan_cnt <= 0;
        else scan_cnt <= scan_cnt + 1;    // 自由累加 0->1->...->7->0回绕
    end

    // ===============================================================
    // 动态扫描逻辑: 每个clk_1k周期选择一个数码管位,送出对应段选
    // scan_cnt: 0=模式号, 1=波形类型, 2=空白分隔, 3~7=参数值(5位)
    // ===============================================================
    always @(*) begin
        // 根据当前模式选择要显示的参数值源
        case (current_mode)
            1: display_value = freq_show;
            2: display_value = duty_show;
            3: display_value = amp_show;
            4: display_value = dc_show;
            default: display_value = {18'd0, wave_type};
        endcase

        seg_sel = 8'h00;
        display_num = 4'hF;
        seg_dp = 1'b0;
        
        // 逐位选择: 位选seg_sel低有效,每个clk_1k周期激活1位
        case (scan_cnt)
            0: begin
                seg_sel = 8'h01;
                display_num = current_mode;
            end
            1: begin
                seg_sel = 8'h02;
                display_num = wave_type;
            end
            2: begin
                seg_sel = 8'h04;
                display_num = 4'hF; // blank
            end
            3: begin
                seg_sel = (current_mode != 0) ? 8'h08 : 8'h00;
                if (current_mode != 0) display_num = (display_value < 20'd10000) ? 4'hF : (display_value / 20'd10000) % 10;
                else display_num = 4'hF;
            end
            4: begin
                seg_sel = (current_mode != 0) ? 8'h10 : 8'h00;
                if (current_mode != 0) display_num = (display_value < 20'd1000) ? 4'hF : (display_value / 20'd1000) % 10;
                else display_num = 4'hF;
                // dp_pos == 3 时，显示 X.XXX
                seg_dp = (current_mode == 2) ? 1'b0 : ((current_mode != 0) && (dp_pos == 2'd3));
            end
            5: begin
                seg_sel = (current_mode != 0) ? 8'h20 : 8'h00;
                if (current_mode != 0) display_num = (display_value / 20'd100) % 10;
                else display_num = 4'hF;
                // dp_pos == 2 时，显示 XX.XX (占空比模式强制为1)
                seg_dp = (current_mode == 2) ? 1'b1 : ((current_mode != 0) && (dp_pos == 2'd2));
            end
            6: begin
                seg_sel = (current_mode != 0) ? 8'h40 : 8'h00;
                if (current_mode != 0) display_num = (display_value / 20'd10) % 10;
                else display_num = 4'hF;
                // dp_pos == 1 时，显示 XXX.X
                seg_dp = (current_mode == 2) ? 1'b0 : ((current_mode != 0) && (dp_pos == 2'd1));
            end
            7: begin
                seg_sel = (current_mode != 0) ? 8'h80 : 8'h00;
                if (current_mode != 0) display_num = display_value % 10;
                else display_num = 4'hF;
                // dp_pos == 0 时，显示 XXXX.
                seg_dp = (current_mode == 2) ? 1'b0 : ((current_mode != 0) && (dp_pos == 2'd0));
            end
        endcase

        seg_led = seg_encode(display_num);
        if (seg_dp) seg_led[7] = 1'b1;
    end
endmodule