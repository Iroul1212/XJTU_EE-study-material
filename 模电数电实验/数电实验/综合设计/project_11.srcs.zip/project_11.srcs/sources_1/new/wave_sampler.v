// =============================================================================
// 模块: wave_sampler - 波形采样与冻结控制
// =============================================================================
// 功能: 以~100kHz速率采样DDS输出,写入BRAM 640点后进入冻结期(~2秒),
//       冻结期内BRAM内容不变,VGA显示静止波形。到期后自动重新捕获一轮。
//       解决了VGA读取速率(25MHz)与采样写入速率(100kHz)不同步导致的波形滑动问题。
//
// =============================================================================
module wave_sampler (
    input wire clk,           // 系统时钟 100MHz
    input wire rst_n,         // 复位
    input wire [7:0] adc_data,// 输入波形数据 (来自DDS输出)
    output reg [9:0] wr_addr, // BRAM写地址 0~639
    output reg [7:0] wr_data, // BRAM写数据
    output reg wr_en          // BRAM写使能
);
    reg [15:0] clk_div;          // 采样分频器 (100MHz/1001 ~= 100kHz)
    reg [27:0] hold_cnt;         // 28bit冻结计数器,最大~2.68s@100MHz
    reg        hold_mode;        // 1=冻结期(禁止写BRAM), 0=捕获期(采样640点)

    // 捕获-冻结双模式状态机
    // 捕获期: 采样640点填入BRAM (~6.4ms @100kHz采样率)
    // 冻结期: BRAM内容静止~2秒, VGA显示静止波形
    // 2秒后自动回到捕获期,重新采样一轮
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin 
            wr_en     <= 0;
            wr_addr   <= 0;
            wr_data   <= 0;
            clk_div   <= 0;
            hold_cnt  <= 0;
            hold_mode <= 1'b0;
        end else begin
            if (hold_mode) begin
                // 冻结期: BRAM完全静止,禁止写操作
                wr_en <= 1'b0;
                if (hold_cnt == 28'd200_000_000) begin   // 2s @ 100MHz
                    hold_cnt  <= 28'd0;
                    hold_mode <= 1'b0;                    // 退出冻结,准备下一轮捕获
                    wr_addr   <= 10'd0;
                    clk_div   <= 16'd0;
                end else begin
                    hold_cnt <= hold_cnt + 28'd1;
                end
            end else begin
                // 捕获期: 以~100kHz速率采样640点填入BRAM
                if (clk_div == 16'd1000) begin
                    clk_div <= 16'd0;
                    wr_en   <= 1'b1;
                    wr_data <= adc_data;
                    if (wr_addr == 10'd639) begin
                        wr_addr   <= 10'd0;
                        hold_mode <= 1'b1;   // 采满一轮 → 进入长冻结
                        hold_cnt  <= 28'd0;
                    end else begin
                        wr_addr <= wr_addr + 10'd1;
                    end
                end else begin
                    clk_div <= clk_div + 16'd1;
                    wr_en   <= 1'b0;
                end
            end
        end
    end
endmodule