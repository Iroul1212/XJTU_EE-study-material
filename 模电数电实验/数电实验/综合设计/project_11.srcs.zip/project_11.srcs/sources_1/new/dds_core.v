// =============================================================================
// 模块: dds_core — 直接数字频率合成(DDS)核心模块
// =============================================================================
// 功能: 基于32位相位累加器实现DDS波形生成。
//       - 正弦波: 查找ROM表(sine_rom,1024×8bit)
//       - 方波:   相位比较+占空比控制
//       - 三角波: 相位高位算术合成(纯逻辑,无需ROM)
//       输出经幅值标定(mV→DAC值)和直流偏置叠加后限幅至0~255。
//
// AI参与: [AI生成] Gemini提供基础相位累加+波形选择框架
//         (1)重写幅值/偏置运算为mV标定公式
//                    (2)修正方波占空比计算避免32位溢出
//                    (3)集成sine_rom IP核替代三角波占位
//                    (4)添加有符号运算防止负值溢出
// =============================================================================

module dds_core (
    // ── 时钟与复位 ──
    input wire sys_clk,          // 系统时钟 100MHz
    input wire rst_n,            // 异步复位,低有效

    // ── 波形参数输入 (来自FSM控制器) ──
    input wire [1:0] wave_type,  // 波形选择: 00=正弦 01=方波 10=三角
    input wire [31:0] freq_word, // 32位频率控制字 K = fout * 2^32 / 100MHz
    input wire [7:0] duty_cycle, // 方波占空比 0~100 (仅方波模式有效)
    input wire [19:0] amp_mV,    // 幅值(峰峰值mV),经标定换算后控制幅度
    input wire [19:0] dc_mV,     // 直流偏置(mV),经标定换算后叠加到输出

    // ── 波形输出 ──
    output wire [7:0] wave_out   // 8位DDS波形数据 (0~255),直送DAC
);

    // ═══════════════════════════════════════════════════════════════
    // [1] 32位相位累加器
    // 每个时钟周期累加 freq_word,取高10位[31:22]作为ROM地址
    // 输出频率: fout = freq_word * 100MHz / 2^32
    // ═══════════════════════════════════════════════════════════════
    reg [31:0] phase_acc;
    always @(posedge sys_clk or negedge rst_n) begin
        if (!rst_n) phase_acc <= 32'd0;
        else phase_acc <= phase_acc + freq_word;  // 自由累加,自然溢出回绕
    end

    // ROM地址: 取相位累加器高10位,寻址1024深度查找表
    wire [9:0] rom_addr = phase_acc[31:22];

    // ── 正弦波ROM IP核实例化 (Vivado Block Memory Generator生成) ──
    // sine_rom: 1024深度×8位宽,初始化文件sine.coe (含1周期正弦波1024采样点)
    wire [7:0] sine_data;
    sine_rom u_sine_rom (
        .clka(sys_clk),           // 时钟A端口
        .addra(rom_addr),         // 地址A: 相位累加器高10位
        .douta(sine_data)         // 数据A: 8位正弦波采样值(无符号0~255)
    );

    // ═══════════════════════════════════════════════════════════════
    // [2] 波形生成: 根据wave_type选择正弦/方波/三角
    // ═══════════════════════════════════════════════════════════════
    reg [7:0] raw_wave;
    always @(*) begin
        case (wave_type)
            2'b00: raw_wave = sine_data;  // 正弦: 直接输出ROM查找表值
            2'b01: begin                  // [AI生成基础框架] 方波: 相位比较+占空比控制
                  // 占空比映射: duty_cycle(0~100) → 32位比较阈值
                  // 相位低于阈值时输出高电平(0xFF),否则输出低电平(0x00)
                  if (phase_acc < ({24'd0, duty_cycle} * (32'hFFFFFFFF / 100)))
                      raw_wave = 8'hFF;   // 高电平
                  else
                      raw_wave = 8'h00;   // 低电平
            end
            2'b10: begin                  // [AI生成] 三角波: 纯逻辑合成(无需ROM)
                  // 前半周期: 线性上升 0→255, 后半周期: 线性下降 255→0
                  if (rom_addr < 512)
                      raw_wave = rom_addr[8:1];        // 上升段: addr[0..511]映射0..255
                  else
                      raw_wave = 255 - rom_addr[8:1];  // 下降段: addr[512..1023]映射255..0
            end
            default: raw_wave = 8'h80;     // 默认中点值(对应0V)
        endcase
    end

    // ═══════════════════════════════════════════════════════════════
    // [3] 幅值标定与直流偏置运算
    // 硬件标定前提: DAC参考电压~3.7V,8位满量程(256级)≈3700mV
    //   即 DAC 1LSB ≈ 3700/256 ≈ 14.453mV
    //
    // 幅值运算: (raw_wave - 128) × amp_mV(mV) × 标定系数
    //   标定系数: 256 / (3700×2) ≈ 0.03459 → 定点化 × 2^16 得 2268
    //   最终: scaled = ((raw-128) × amp_mV × 2268) >> 22
    //
    // 偏置运算: dc_mV / 14.453 ≈ dc_mV × 4534 >> 16
    // ═══════════════════════════════════════════════════════════════

    // 将有符号波形值映射到 ±128 范围 (raw_wave=128 → 0V)
    wire signed [9:0] raw_signed = $signed({1'b0, raw_wave}) - 10'sd128;

    // 幅值标定: raw_signed * amp_mV -> DAC码值
    wire signed [31:0] mul_raw_amp = raw_signed * $signed({1'b0, amp_mV}); 
    wire signed [31:0] scaled_signed = (mul_raw_amp * 32'sd2268) >>> 22;

    // 直流偏置换算: dc_mV / 14.453 ~= (dc_mV * 4534) >> 16
    wire [31:0] dc_byte_w = (dc_mV * 32'd4534) >> 16;
    wire [8:0] dc_byte = (dc_byte_w > 32'd255) ? 9'd255 : dc_byte_w[8:0];

    // ===============================================================
    // [4] 波形合成: 幅度分量 + 中点(128) + 直流偏置 -> 限幅输出
    // ===============================================================
    wire signed [31:0] mixed_signed = scaled_signed + 32'sd128 + $signed({1'b0, dc_byte});

    // 输出限幅: 防止溢出导致波形反转
    reg [7:0] wave_out_reg;
    always @(*) begin
        if (mixed_signed <= 0)      wave_out_reg = 8'd0;    // 负向限幅
        else if (mixed_signed >= 255) wave_out_reg = 8'd255; // 正向限幅
        else                         wave_out_reg = mixed_signed[7:0];
    end

    assign wave_out = wave_out_reg;
endmodule