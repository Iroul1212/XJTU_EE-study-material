`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/03/11 21:58:18
// Design Name: 
// Module Name: tb_majority_voter
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module tb_majority_voter();

    reg a;
    reg b;
    reg c;
    reg d;
    
    wire y;

    integer i;

    majority_voter_en uut (
        .a(a), 
        .b(b), 
        .c(c), 
        .d(d), 
        .y(y)
    );
    initial begin
        for (i = 0; i < 32; i = i + 1) begin
            {a, b, c, d} = i;
            #10;
        end
    end

endmodule
