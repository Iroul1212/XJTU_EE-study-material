set_property -dict {PACKAGE_PIN R1 IOSTANDARD LVCMOS33} [get_ports a]
set_property -dict {PACKAGE_PIN N4 IOSTANDARD LVCMOS33} [get_ports b]
set_property -dict {PACKAGE_PIN M4 IOSTANDARD LVCMOS33} [get_ports c]
set_property -dict {PACKAGE_PIN R2 IOSTANDARD LVCMOS33} [get_ports d]

set_property -dict {PACKAGE_PIN K3 IOSTANDARD LVCMOS33} [get_ports y]
