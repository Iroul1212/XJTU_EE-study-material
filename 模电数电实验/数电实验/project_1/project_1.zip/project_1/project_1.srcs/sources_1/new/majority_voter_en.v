`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 2026/03/11 21:55:54
// Design Name: 
// Module Name: majority_voter_en
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module majority_voter_en (
    input  wire a,
    input  wire b,
    input  wire c,
    input  wire d,
    output wire y
);

    assign y = ~((a & b) | (c & d));

endmodule