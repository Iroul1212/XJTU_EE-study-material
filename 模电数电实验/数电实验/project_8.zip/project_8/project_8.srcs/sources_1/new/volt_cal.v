module volt_cal(
    input clk,
    input rst_n,
    input [15:0] adc_data,
    output reg [3:0] digit_3, // 整数位 (0 或 1)
    output reg [3:0] digit_2, // 小数点后第一位
    output reg [3:0] digit_1, // 小数点后第二位
    output reg [3:0] digit_0  // 小数点后第三位
);

    wire [11:0] adc_12b = adc_data[15:4]; // 提取高12位有效数据
    wire [23:0] norm_x1000 = (adc_12b * 24'd1000) / 12'd4095; // 归一化到 0~1000 (对应 0.000~1.000)

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            digit_3 <= 0;
            digit_2 <= 0;
            digit_1 <= 0;
            digit_0 <= 0;
        end else begin
            // 提取各个位上的十进制数
            digit_3 <= norm_x1000 / 1000;
            digit_2 <= (norm_x1000 / 100) % 10;
            digit_1 <= (norm_x1000 / 10) % 10;
            digit_0 <= norm_x1000 % 10;
        end
    end
endmodule