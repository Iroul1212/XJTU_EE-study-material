module top_meter(
    input sys_clk_in,
    input sys_rst_n,
    
    // XADC 模拟接口
    input XADC_AUX_v_p,
    input XADC_AUX_v_n,
    
    // 数码管接口
    output [7:0] seg_cs_pin,     // 位选
    output [7:0] seg_data_0_pin, // 段选0
    output [7:0] seg_data_1_pin  // 段选1
);

    wire [15:0] adc_out;
    wire eoc_out;
    wire [3:0] d3, d2, d1, d0;
    wire [7:0] seg_data_wire;

    // 为了兼容EGo1的两组段选数据线设计，将同样的段选数据赋给它们
    assign seg_data_0_pin = seg_data_wire;
    assign seg_data_1_pin = seg_data_wire;

    // 1. 实例化 XADC IP 核
    xadc_wiz_0 u_xadc(
        .daddr_in       (7'h11),
        .dclk_in        (sys_clk_in),
        .den_in         (eoc_out),
        .di_in          (16'b0),
        .dwe_in         (1'b0),
        .reset_in       (~sys_rst_n),
        .vauxp1         (XADC_AUX_v_p),
        .vauxn1         (XADC_AUX_v_n),
        .busy_out       (),
        .channel_out    (),
        .do_out         (adc_out),
        .drdy_out       (),
        .eoc_out        (eoc_out),
        .eos_out        (),
        .alarm_out      (),
        .vp_in          (1'b0),
        .vn_in          (1'b0)
    );
    

    // 2. 实例化电压计算模块
    volt_cal u_volt_cal(
        .clk     (sys_clk_in),
        .rst_n   (sys_rst_n),
        .adc_data(adc_out),
        .digit_3 (d3),
        .digit_2 (d2),
        .digit_1 (d1),
        .digit_0 (d0)
    );

    // 3. 实例化数码管驱动模块
    seg_driver u_seg_driver(
        .clk      (sys_clk_in),
        .rst_n    (sys_rst_n),
        .digit_3  (d3),
        .digit_2  (d2),
        .digit_1  (d1),
        .digit_0  (d0),
        .seg_cs   (seg_cs_pin),
        .seg_data (seg_data_wire)
    );

endmodule