module seg_driver(
    input wire clk,
    input wire rst_n,        // EGo1 通常为低电平复位
    input wire [3:0] digit_3, // 对应最左边显示的数字 (整数位，带小数点)
    input wire [3:0] digit_2,
    input wire [3:0] digit_1,
    input wire [3:0] digit_0, // 对应最右边显示的数字
    output reg [7:0] seg_cs,  // 8位位选
    output reg [7:0] seg_data // 8位段选 (DP + ABCDEFG)
);

    // 1. 扫描时钟分频 (保留你提供的 scan_cnt[15] 方式)
    reg [15:0] scan_cnt;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) scan_cnt <= 16'd0;
        else scan_cnt <= scan_cnt + 1'b1;
    end
    wire scan_clk = scan_cnt[15];

    // 2. 位选与数据切换
    reg [3:0] current_digit;
    always @(posedge scan_clk or negedge rst_n) begin
        if (!rst_n) begin
            seg_cs <= 8'b0000_1000;
            current_digit <= digit_3;
        end else begin
            // 扫描右侧 4 位数码管，高电平有效
            case (seg_cs)
                8'b0000_1000: begin seg_cs <= 8'b0000_0100; current_digit <= digit_2; end
                8'b0000_0100: begin seg_cs <= 8'b0000_0010; current_digit <= digit_1; end
                8'b0000_0010: begin seg_cs <= 8'b0000_0001; current_digit <= digit_0; end
                8'b0000_0001: begin seg_cs <= 8'b0000_1000; current_digit <= digit_3; end
                default:      begin seg_cs <= 8'b0000_1000; current_digit <= digit_3; end
            endcase
        end
    end

    always @(*) begin
        case (current_digit)
            4'd0: seg_data = 8'b0_1111110;
            4'd1: seg_data = 8'b0_0110000;
            4'd2: seg_data = 8'b0_1101101;
            4'd3: seg_data = 8'b0_1111001;
            4'd4: seg_data = 8'b0_0110011;
            4'd5: seg_data = 8'b0_1011011;
            4'd6: seg_data = 8'b0_1011111;
            4'd7: seg_data = 8'b0_1110000;
            4'd8: seg_data = 8'b0_1111111;
            4'd9: seg_data = 8'b0_1111011;
            default: seg_data = 8'b0_0000000; 
        endcase

        // 当扫描到 digit_3 (即整数位) 时，强制将最高位 DP (seg_data[7]) 置 1 点亮小数点
        if (seg_cs == 8'b0000_1000) begin
            seg_data[7] = 1'b1; 
        end
    end
endmodule