module triangle_gen(
    input  wire       clk,
    input  wire       rst_n,
    output reg  [7:0] wave_out
);
    reg [7:0] div_cnt;
    reg       dir; // 0:上升, 1:下降
    localparam [7:0] MAX_CODE = 8'd207; // 3V / 3.7V * 255 ≈ 207
    localparam [7:0] DIV_LIMIT = 8'd120; // 约 121 个时钟步进一次，频率约 2kHz
    
    // 2kHz周期内包含 207*2=414 个阶梯。100,000 / 2,000 / 414 ≈ 121 个时钟步进一次
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_cnt <= 0;
            wave_out <= 0;
            dir <= 0;
        end else if (div_cnt == DIV_LIMIT) begin
            div_cnt <= 0;
            if (dir == 0) begin
                if (wave_out >= MAX_CODE) dir <= 1;
                else wave_out <= wave_out + 1;
            end else begin
                if (wave_out <= 8'd1) dir <= 0;
                else wave_out <= wave_out - 1;
            end
        end else begin
            div_cnt <= div_cnt + 1;
        end
    end
endmodule