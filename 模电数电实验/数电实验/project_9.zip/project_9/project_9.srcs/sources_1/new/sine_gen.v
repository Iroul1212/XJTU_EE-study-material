module sine_gen(
    input  wire       clk,
    input  wire       rst_n,
    output reg  [7:0] wave_out
);
    reg [11:0] div_cnt;
    reg [4:0]  addr;
    
    // 100,000 / 32 = 3125 时钟步进一次地址
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_cnt <= 0;
            addr <= 0;
        end else if (div_cnt == 12'd3124) begin
            div_cnt <= 0;
            addr <= addr + 1;
        end else begin
            div_cnt <= div_cnt + 1;
        end
    end

    always @(*) begin
        case(addr)
            5'd0: wave_out = 8'd128; 5'd1: wave_out = 8'd153; 5'd2: wave_out = 8'd177; 5'd3: wave_out = 8'd198;
            5'd4: wave_out = 8'd218; 5'd5: wave_out = 8'd234; 5'd6: wave_out = 8'd245; 5'd7: wave_out = 8'd253;
            5'd8: wave_out = 8'd255; 5'd9: wave_out = 8'd253; 5'd10:wave_out = 8'd245; 5'd11:wave_out = 8'd234;
            5'd12:wave_out = 8'd218; 5'd13:wave_out = 8'd198; 5'd14:wave_out = 8'd177; 5'd15:wave_out = 8'd153;
            5'd16:wave_out = 8'd128; 5'd17:wave_out = 8'd103; 5'd18:wave_out = 8'd79;  5'd19:wave_out = 8'd57;
            5'd20:wave_out = 8'd38;  5'd21:wave_out = 8'd22;  5'd22:wave_out = 8'd11;  5'd23:wave_out = 8'd3;
            5'd24:wave_out = 8'd1;   5'd25:wave_out = 8'd3;   5'd26:wave_out = 8'd11;  5'd27:wave_out = 8'd22;
            5'd28:wave_out = 8'd38;  5'd29:wave_out = 8'd57;  5'd30:wave_out = 8'd79;  5'd31:wave_out = 8'd103;
        endcase
    end
endmodule