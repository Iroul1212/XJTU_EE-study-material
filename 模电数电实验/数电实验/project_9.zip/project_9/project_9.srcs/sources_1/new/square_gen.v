module square_gen(
    input  wire       clk,
    input  wire       rst_n,
    output reg  [7:0] wave_out
);
    reg [15:0] cnt;
    localparam [7:0] HIGH_CODE = 8'd138; // 2V / 3.7V * 255 ≈ 138
    // 100MHz时钟，1kHz周期 = 100,000个时钟周期
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt <= 0;
            wave_out <= 0;
        end else if (cnt == 16'd49999) begin // 半周期翻转
            cnt <= 0;
            wave_out <= (wave_out == HIGH_CODE) ? 8'd0 : HIGH_CODE; 
        end else begin
            cnt <= cnt + 1;
        end
    end
endmodule