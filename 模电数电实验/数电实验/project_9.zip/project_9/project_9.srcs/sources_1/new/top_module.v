module top_module(
    input  wire       sys_clk_in,
    input  wire       sys_rst_n,
    input  wire [2:0] sw_pin,
    // DAC 接口引脚
    output wire       dac_ile,
    output wire       dac_cs_n,
    output wire       dac_wr1_n,
    output wire       dac_wr2_n,
    output wire       dac_xfer_n,
    output wire [7:0] dac_data
);
    wire [7:0] w_sq, w_tri, w_sin;
    reg  [7:0] selected_wave;

    // 实例化波形发生器
    square_gen   u1 (.clk(sys_clk_in), .rst_n(sys_rst_n), .wave_out(w_sq));
    triangle_gen u2 (.clk(sys_clk_in), .rst_n(sys_rst_n), .wave_out(w_tri));
    sine_gen     u3 (.clk(sys_clk_in), .rst_n(sys_rst_n), .wave_out(w_sin));

    // 根据拨码开关选择模式
    always @(*) begin
        case(sw_pin)
            3'b001: selected_wave = w_sq;  // 3.7V 参考下约 2V 方波
            3'b010: selected_wave = w_tri; // 3.7V 参考下约 3V 三角波
            3'b100: selected_wave = w_sin; // 3.7V 参考下满量程正弦波
            default: selected_wave = 8'd0;
        endcase
    end

    // 实例化 DAC 驱动
    dac_driver u_dac (
        .wave_data(selected_wave),
        .dac_ile(dac_ile),
        .dac_cs_n(dac_cs_n),
        .dac_wr1_n(dac_wr1_n),
        .dac_wr2_n(dac_wr2_n),
        .dac_xfer_n(dac_xfer_n),
        .dac_data_pins(dac_data)
    );
endmodule