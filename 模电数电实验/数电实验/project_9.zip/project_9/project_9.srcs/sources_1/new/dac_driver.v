module dac_driver(
    input  wire [7:0] wave_data,
    output wire       dac_ile,
    output wire       dac_cs_n,
    output wire       dac_wr1_n,
    output wire       dac_wr2_n,
    output wire       dac_xfer_n,
    output wire [7:0] dac_data_pins
);
    assign dac_ile    = 1'b1; // 高电平有效使能
    assign dac_cs_n   = 1'b0; // 片选使能
    assign dac_wr1_n  = 1'b0; // 写入使能
    assign dac_wr2_n  = 1'b0; // 写入使能
    assign dac_xfer_n = 1'b0; // 传输使能
    assign dac_data_pins = wave_data; // 数据总线
endmodule