module run_ctrl (
    input wire clk,
    input wire rst,
    input wire start_pulse,
    input wire clear_pulse,
    input wire set_mode_pulse, 
    output reg run_en,
    output reg cnt_clr,
    output reg init_en,        // 决定是否处于“同步设置值”模式
        // 状态编码：
        // S_IDLE      = 初始/待机状态
        // S_SET_TENS  = 设置十位状态
        // S_SET_UNITS = 设置个位状态
        // S_RUN       = 运行状态
        // S_PAUSE     = 暂停状态
    output reg set_tens_en,
    output reg set_units_en
);
    localparam [2:0] S_IDLE      = 3'd0,
                     S_SET_TENS  = 3'd1,
                     S_SET_UNITS = 3'd2,
                     S_RUN       = 3'd3,
                     S_PAUSE     = 3'd4;

        // 现态寄存器和次态寄存器。
    reg [2:0] state, state_n;

        // 状态寄存器：复位后回到初始态。
    always @(posedge clk or posedge rst) begin
        if (rst) state <= S_IDLE;
        else     state <= state_n;
    end

    always @(*) begin
        state_n = state;
        cnt_clr = 1'b0;
        case (state)
            S_IDLE: begin
                    // 现态：S_IDLE
                    // 条件：按下置数键 -> 次态：S_SET_TENS
                if (set_mode_pulse) state_n = S_SET_TENS;
                    // 条件：按下开始键 -> 次态：S_RUN
                else if (start_pulse) state_n = S_RUN;
                    // 条件：按下清零键 -> 仅输出 cnt_clr 脉冲，次态保持不变
                else if (clear_pulse) cnt_clr = 1'b1;
            end
            S_SET_TENS: begin
                    // 现态：S_SET_TENS
                    // 条件：按下置数键 -> 次态：S_SET_UNITS
                if (set_mode_pulse) state_n = S_SET_UNITS;
                    // 条件：按下开始键 -> 次态：S_RUN
                else if (start_pulse) state_n = S_RUN;
            end
            S_SET_UNITS: begin
                    // 现态：S_SET_UNITS
                    // 条件：按下置数键 -> 次态：S_IDLE
                if (set_mode_pulse) state_n = S_IDLE;
                    // 条件：按下开始键 -> 次态：S_RUN
                else if (start_pulse) state_n = S_RUN;
            end
            S_RUN: begin
                    // 现态：S_RUN
                    // 条件：按下开始键 -> 次态：S_PAUSE
                if (start_pulse) state_n = S_PAUSE;
                    // 条件：按下清零键 -> 次态：S_IDLE，同时输出 cnt_clr 脉冲
                else if (clear_pulse) begin state_n = S_IDLE; cnt_clr = 1'b1; end
            end
            S_PAUSE: begin
                    // 现态：S_PAUSE
                    // 条件：按下开始键 -> 次态：S_RUN
                if (start_pulse) state_n = S_RUN;
                    // 条件：按下清零键 -> 次态：S_IDLE，同时输出 cnt_clr 脉冲
                else if (clear_pulse) begin state_n = S_IDLE; cnt_clr = 1'b1; end
            end
                // 异常状态：回到初始态。
            default: state_n = S_IDLE;
        endcase
    end

    always @(*) begin
        run_en       = (state == S_RUN);
        // 只要不是在运行或暂停，都认为是在初始化/设置阶段
        init_en      = (state == S_IDLE) || (state == S_SET_TENS) || (state == S_SET_UNITS);
        set_tens_en  = (state == S_SET_TENS);
        set_units_en = (state == S_SET_UNITS);
    end
endmodule