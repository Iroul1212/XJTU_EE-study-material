module key_debounce_pulse #(
    parameter integer DB_MAX = 21'd2_000_000
)(
    input wire clk,
    input wire rst,
    input wire key_n,
    output wire press_pulse
);
    reg [1:0] key_sync;
    reg [20:0] db_cnt;
    reg key_level;
    reg key_level_d;

    assign press_pulse = key_level & ~key_level_d;

    always @(posedge clk or posedge rst) begin
        if (rst)
            key_sync <= 2'b11;
        else
            key_sync <= {key_sync[0], key_n};
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            key_level <= 1'b0;
            db_cnt <= 21'd0;
        end else if (key_sync[1] == 1'b0) begin
            if (db_cnt < DB_MAX)
                db_cnt <= db_cnt + 1'b1;
            else
                key_level <= 1'b1;
        end else begin
            key_level <= 1'b0;
            db_cnt <= 21'd0;
        end
    end

    always @(posedge clk or posedge rst) begin
        if (rst)
            key_level_d <= 1'b0;
        else
            key_level_d <= key_level;
    end
endmodule
