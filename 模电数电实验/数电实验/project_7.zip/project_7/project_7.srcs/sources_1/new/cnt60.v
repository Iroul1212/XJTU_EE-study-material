module cnt60 (
    input wire clk,
    input wire rst,             
    input wire clr,             
    input wire pulse_in,        
    input wire init_en,         
    input wire set_tens_en,     
    input wire set_units_en,    
    input wire add_val_pulse,   
    output wire [7:0] x
);
    reg [3:0] units, tens;
    reg [3:0] cfg_tens, cfg_units; // 这里存储的是你“改掉”的初始状态

    assign x = {tens, units};

    // 逻辑：修改配置寄存器
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            cfg_tens  <= 4'd5;
            cfg_units <= 4'd9;
        end else begin
            if (set_tens_en && add_val_pulse)
                cfg_tens <= (cfg_tens == 4'd5) ? 4'd0 : cfg_tens + 1'b1;
            else if (set_units_en && add_val_pulse)
                cfg_units <= (cfg_units == 4'd9) ? 4'd0 : cfg_units + 1'b1;
        end
    end

    // 逻辑：计数与同步
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            tens  <= 4'd5;
            units <= 4'd9;
        end else if (init_en || clr) begin
            // 关键：在设置和复位状态，当前显示值强制等于配置值
            tens  <= cfg_tens;
            units <= cfg_units;
        end else if (pulse_in) begin
            // 运行逻辑保持不变
            if (tens == 0 && units == 0) begin
                tens <= 0; units <= 0;
            end else if (units == 0) begin
                units <= 9; tens <= tens - 1;
            end else begin
                units <= units - 1;
            end
        end
    end
endmodule