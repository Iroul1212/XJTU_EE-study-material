module top_module (
    input wire clk,
    input wire rst,             // 高有效复位
    input wire key_start_n,     // 开始/暂停
    input wire key_clear_n,     // 清零/重置
    input wire key_add_tens_n,  // [功能复用] 切换设置模式 (Set Mode)
    input wire key_add_units_n, // [功能复用] 当前位数值加1 (Add Value)
    output wire [7:0] x,
    output wire [3:0] seg_an,
    output wire [6:0] seg_out
);
    wire w;
    wire [7:0] sec_bcd;
    wire [15:0] disp_bcd;
    
    wire run_en, cnt_clr, init_en;
    wire set_tens_en, set_units_en;
    
    wire start_pressed, clear_pressed;
    wire set_mode_pressed; // 原 add_tens_pressed
    wire add_val_pressed;  // 原 add_units_pressed

    sec_pulse u1_sec_pulse (
        .clk(clk), .rst(rst), .pulse_out(w)
    );

    key_debounce_pulse u2_key_start (
        .clk(clk), .rst(rst), .key_n(key_start_n), .press_pulse(start_pressed)
    );

    key_debounce_pulse u3_key_clear (
        .clk(clk), .rst(rst), .key_n(key_clear_n), .press_pulse(clear_pressed)
    );

    // 将原本的 十位按键 映射为 切换设置模式按键
    key_debounce_pulse u_key_set_mode (
        .clk(clk), .rst(rst), .key_n(key_add_tens_n), .press_pulse(set_mode_pressed)
    );

    // 将原本的 个位按键 映射为 数值加1按键
    key_debounce_pulse u_key_add_val (
        .clk(clk), .rst(rst), .key_n(key_add_units_n), .press_pulse(add_val_pressed)
    );

    run_ctrl u4_run_ctrl (
        .clk(clk),
        .rst(rst),
        .start_pulse(start_pressed),
        .clear_pulse(clear_pressed),
        .set_mode_pulse(set_mode_pressed), // 传入切换模式脉冲
        .run_en(run_en),
        .cnt_clr(cnt_clr),
        .init_en(init_en),
        .set_tens_en(set_tens_en),         // 导出十位设置使能
        .set_units_en(set_units_en)        // 导出个位设置使能
    );

    cnt60 u5_cnt60 (
        .clk(clk),
        .rst(rst),
        .clr(cnt_clr),
        .pulse_in(w & run_en),
        .init_en(init_en),
        .set_tens_en(set_tens_en),         // 接收十位设置使能
        .set_units_en(set_units_en),       // 接收个位设置使能
        .add_val_pulse(add_val_pressed),   // 接收加1脉冲
        .x(sec_bcd)
    );

    assign x = sec_bcd;
    assign disp_bcd = {8'h00, sec_bcd};

    seg_driver u6_seg_driver (
        .clk(clk), .rst(rst), .bcd_data(disp_bcd), .seg_an(seg_an), .seg_out(seg_out)
    );
endmodule