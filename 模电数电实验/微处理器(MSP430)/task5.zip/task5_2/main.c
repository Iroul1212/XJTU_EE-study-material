#include <msp430.h>

volatile unsigned int cnt_upper = 0;      // 大写字母计数
volatile unsigned int cnt_lower = 0;      // 小写字母计数
volatile unsigned int cnt_other = 0;      // 非字母字符计数

static const char STR_UPPER[] = " | 大写：";
static const char STR_LOWER[] = " 小写：";
static const char STR_OTHER[] = " 非字母：";
static const char STR_CRLF[]  = "\r\n";

void clock_init(void)
{
    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;
    BCSCTL2 = DIVS_1;                    // SMCLK = MCLK / 2 = 500kHz
}

void uart_init(void)
{
    P1SEL  |= BIT1 + BIT2;               // P1.1(TXD), P1.2(RXD) 外设功能
    P1SEL2 |= BIT1 + BIT2;

    UCA0CTL1 |= UCSWRST;                 // 进入复位状态
    UCA0CTL1 |= UCSSEL_2;                // 时钟源 = SMCLK
    UCA0BR0  = 52;                       // 500kHz / 9600 ≈ 52.0833
    UCA0BR1  = 0;
    UCA0MCTL = UCBRS_1;                  // 调制值 = 1
    UCA0CTL1 &= ~UCSWRST;                // 退出复位，UART 开始工作

    IE2 |= UCA0RXIE;                     // 使能 UCA0 接收中断
}

void UART_SendChar(unsigned char c)
{
    while (!(IFG2 & UCA0TXIFG));         // 等待 TX 缓冲空
    UCA0TXBUF = c;
}

void UART_SendString(const char *str)
{
    while (*str)
        UART_SendChar(*str++);
}

void UART_SendNum(unsigned int num)
{
    char buf[6];
    char *p = buf + sizeof(buf) - 1;
    *p = '\0';

    if (num == 0)
    {
        *(--p) = '0';
    }
    else
    {
        while (num > 0)
        {
            *(--p) = (char)('0' + (num % 10));
            num /= 10;
        }
    }
    UART_SendString(p);
}

void UART_SendStats(void)
{
    UART_SendString(STR_UPPER);
    UART_SendNum(cnt_upper);

    UART_SendString(STR_LOWER);
    UART_SendNum(cnt_lower);

    UART_SendString(STR_OTHER);
    UART_SendNum(cnt_other);

    UART_SendString(STR_CRLF);
}

#pragma vector = USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
    unsigned char rx_data = UCA0RXBUF;   // 读取接收字节（自动清除 IFG）
    unsigned char tx_data;               // 待回传的字符

    if (rx_data == '\r' || rx_data == '\n')
    {
        UART_SendStats();                // 同行追加统计信息（尾部自带 \r\n 换行）
        cnt_upper = 0;
        cnt_lower = 0;
        cnt_other = 0;
        return;                          // 已处理完毕，直接返回
    }

    if (rx_data >= 'A' && rx_data <= 'Z')
    {
        tx_data = rx_data + ('a' - 'A');
        cnt_upper++;                     // 原始为大写
    }
    else if (rx_data >= 'a' && rx_data <= 'z')
    {
        tx_data = rx_data - ('a' - 'A');
        cnt_lower++;                     // 原始为小写
    }
    else
    {
        tx_data = rx_data;
        cnt_other++;                     // 非字母字符
    }

    UART_SendChar(tx_data);
}

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;           // 停止看门狗

    clock_init();
    uart_init();

    __bis_SR_register(GIE);             // 全局中断使能

    while (1)
    {
        __low_power_mode_0();           // 休眠，由 ISR 唤醒
    }
}

