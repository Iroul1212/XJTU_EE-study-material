#include <msp430.h>

#define NUM_SAMPLES  8                    // DTC 传输次数
#define CMD_BUF_SIZE  8                   // 指令缓冲区大小

unsigned int adc_data[NUM_SAMPLES];       // DTC 自动填充 8 组原始采样值
unsigned long adc_sum;                    // 总和
unsigned int adc_avg;                     // 算术平均值
unsigned int voltage_mv;                  // 换算后的电压值 (mV)

char cmd_buf[CMD_BUF_SIZE];              // 接收字符缓冲区
volatile unsigned char cmd_idx = 0;      // 缓冲区当前写入位置

volatile unsigned int cnt_upper = 0;     // 大写字母计数
volatile unsigned int cnt_lower = 0;     // 小写字母计数
volatile unsigned int cnt_other = 0;     // 非字母字符计数

static const char STR_HEAD[]   = "原始均值：";
static const char STR_MID[]    = " , 实测电压：";
static const char STR_TAIL[]   = " V\r\n";
static const char STR_CLS[]    = "\033[2J\033[H";   // ANSI 清屏 + 光标归位
static const char STR_CLS_OK[] = "-- Screen Cleared --\r\n";
static const char STR_UPPER[]  = " | 大写：";
static const char STR_LOWER[]  = " 小写：";
static const char STR_OTHER[]  = " 非字母：";
static const char STR_PROMPT[]  = "\r\n> ";

void UART_Init(void)
{
    P1SEL  |= BIT1 + BIT2;               // P1.1=RXD, P1.2=TXD (UCA0 功能)
    P1SEL2 |= BIT1 + BIT2;

    UCA0CTL1 |= UCSWRST;                 // 进入复位
    UCA0CTL1 |= UCSSEL_2;                // 时钟源 = SMCLK (1MHz)
    UCA0BR0  = 6;                        // 1MHz / (9600*16) ≈ 6.51
    UCA0BR1  = 0;
    UCA0MCTL = UCBRF_8 | UCOS16;         // 过采样模式, 小数 = 8/16
    UCA0CTL1 &= ~UCSWRST;                // 释放复位, 启动 USCI

    IE2 |= UCA0RXIE;                     // 使能 UCA0 接收中断
}

void UART_SendChar(unsigned char c)
{
    while (!(IFG2 & UCA0TXIFG));
    UCA0TXBUF = c;
}

void UART_SendString(const char *str)
{
    while (*str)
        UART_SendChar(*str++);
}

void UART_SendNum(unsigned int num)
{
    char buf[6];
    char *p = buf + sizeof(buf) - 1;
    *p = '\0';

    if (num == 0)
    {
        *(--p) = '0';
    }
    else
    {
        while (num > 0)
        {
            *(--p) = (char)('0' + (num % 10));
            num /= 10;
        }
    }
    UART_SendString(p);
}

void UART_SendVoltage(unsigned int mv)
{
    char frac_buf[4];

    UART_SendNum(mv / 1000);
    UART_SendChar('.');

    unsigned int frac = mv % 1000;
    frac_buf[3] = '\0';
    frac_buf[2] = (char)('0' + (frac % 10));
    frac /= 10;
    frac_buf[1] = (char)('0' + (frac % 10));
    frac /= 10;
    frac_buf[0] = (char)('0' + (frac % 10));
    UART_SendString(frac_buf);
}

void ADC_Read(void)
{
    unsigned int i;

    ADC10DTC1 = NUM_SAMPLES;
    ADC10SA   = (unsigned int)adc_data;

    ADC10CTL0 |= ENC + ADC10SC;
    while (!(ADC10CTL0 & ADC10IFG));
    ADC10CTL0 &= ~ENC;

    adc_sum = 0;
    for (i = NUM_SAMPLES; i > 0; i--)
        adc_sum += adc_data[i - 1];
    adc_avg = (unsigned int)(adc_sum / NUM_SAMPLES);

    voltage_mv = (unsigned int)((unsigned long)adc_avg * 2500 / 1023);
}

void Send_Result(void)
{
    UART_SendString(STR_HEAD);
    UART_SendNum(adc_avg);
    UART_SendString(STR_MID);
    UART_SendVoltage(voltage_mv);
    UART_SendString(STR_TAIL);
}

void Send_Stats(void)
{
    UART_SendString(STR_UPPER);
    UART_SendNum(cnt_upper);
    UART_SendString(STR_LOWER);
    UART_SendNum(cnt_lower);
    UART_SendString(STR_OTHER);
    UART_SendNum(cnt_other);
    UART_SendString(STR_TAIL);
}

void Process_Command(void)
{
    if (cmd_idx == 3 &&
        cmd_buf[0] == 'A' && cmd_buf[1] == 'D' && cmd_buf[2] == 'C')
    {
        ADC_Read();
        Send_Result();
    }
    else if (cmd_idx == 3 &&
             cmd_buf[0] == 'C' && cmd_buf[1] == 'L' && cmd_buf[2] == 'S')
    {
        UART_SendString(STR_CLS);        // ANSI 清屏
        UART_SendString(STR_CLS_OK);     // 确认提示
    }
    else if (cmd_idx > 0)
    {
        UART_SendChar('\r');             // 换行
        UART_SendChar('\n');
        Send_Stats();                    // 统计信息
    }

    cnt_upper = 0;
    cnt_lower = 0;
    cnt_other = 0;

    UART_SendString(STR_PROMPT);
}

#pragma vector = USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
    unsigned char rx = UCA0RXBUF;        // 读取接收字节
    unsigned char tx;                    // 待回传字符

    if (rx == '\r' || rx == '\n')
    {
        cmd_buf[cmd_idx] = '\0';         // 结束字符串
        Process_Command();               // 解析并执行
        cmd_idx = 0;                     // 重置缓冲区
        return;
    }

    if (rx == 0x08 || rx == 0x7F)        // Backspace / Delete
    {
        if (cmd_idx > 0)
        {
            cmd_idx--;
            UART_SendChar('\b');         // 光标回退
            UART_SendChar(' ');          // 擦除字符
            UART_SendChar('\b');         // 光标再次回退
        }
        return;
    }

    if (rx >= 'A' && rx <= 'Z')
    {
        tx = rx + ('a' - 'A');           // 大写 → 小写
        cnt_upper++;                     // 原始为大写
    }
    else if (rx >= 'a' && rx <= 'z')
    {
        tx = rx - ('a' - 'A');           // 小写 → 大写
        cnt_lower++;                     // 原始为小写
    }
    else
    {
        tx = rx;                         // 非字母原样
        cnt_other++;                     // 非字母字符
    }

    UART_SendChar(tx);

    if (cmd_idx < CMD_BUF_SIZE - 1)
    {
        cmd_buf[cmd_idx++] = (char)rx;   // 存原始字符（用于指令匹配）
    }
}

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;            // 停止看门狗

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR &= ~BIT0;
    P1SEL |= BIT0;

    ADC10CTL1 = INCH_0 | CONSEQ_2
              | ADC10SSEL_0 | ADC10DIV_0;

    ADC10CTL0 = SREF_1 | ADC10SHT_3 | MSC
              | REFON | REF2_5V | ADC10ON;

    UART_Init();

    __delay_cycles(30000);               // 等待参考电压稳定

    UART_SendString("\r\n=== MSP430 指令终端 ===\r\n");
    UART_SendString("ADC - 测量电压  CLS - 清屏\r\n");
    UART_SendString("> ");

    __bis_SR_register(GIE);              // 全局中断使能

    while (1)
    {
        __low_power_mode_0();            // 休眠，由 ISR 唤醒
    }
}
