#include <msp430.h>

#define NUM_SAMPLES  8                    // DTC 传输次数

unsigned int adc_data[NUM_SAMPLES];       // DTC 自动填充 8 组原始采样值
unsigned long adc_sum;                    // 总和
unsigned int adc_avg;                     // 算术平均值
unsigned int voltage_mv;                  // 换算后的电压值 (mV)

static const char STR_HEAD[]  = "原始均值：";
static const char STR_MID[]   = " , 实测电压：";
static const char STR_TAIL[]  = " V\r\n";

void UART_Init(void)
{
    P1SEL  |= BIT1 + BIT2;               // P1.1=RXD, P1.2=TXD (UCA0 功能)
    P1SEL2 |= BIT1 + BIT2;

    UCA0CTL1 |= UCSSEL_2;                // 时钟源 =
    UCA0BR0  = 6;                        // 整数部分
    UCA0BR1  = 0;
    UCA0MCTL = UCBRF_8 | UCOS16;         // 小数部分 + 过采样使能
    UCA0CTL1 &= ~UCSWRST;                // 释放复位, 启动 USCI
}

void UART_SendChar(unsigned char c)
{
    while (!(IFG2 & UCA0TXIFG));         // 等待发送缓冲空
    UCA0TXBUF = c;
}

void UART_SendString(const char *str)
{
    while (*str)
    {
        UART_SendChar(*str++);
    }
}

void UART_SendNum(unsigned int num)
{
    char buf[6];                         // 最大 65535 (5位+'\0')
    char *p = buf + sizeof(buf) - 1;
    *p = '\0';

    if (num == 0)
    {
        *(--p) = '0';
    }
    else
    {
        while (num > 0)
        {
            *(--p) = (char)('0' + (num % 10));
            num /= 10;
        }
    }
    UART_SendString(p);
}

void UART_SendVoltage(unsigned int mv)
{
    char frac_buf[4];                    // 3位小数 + '\0'

    UART_SendNum(mv / 1000);

    UART_SendChar('.');

    unsigned int frac = mv % 1000;
    frac_buf[3] = '\0';
    frac_buf[2] = (char)('0' + (frac % 10));
    frac /= 10;
    frac_buf[1] = (char)('0' + (frac % 10));
    frac /= 10;
    frac_buf[0] = (char)('0' + (frac % 10));
    UART_SendString(frac_buf);
}

void ADC_Read(void)
{
    unsigned int i;

    ADC10DTC1 = NUM_SAMPLES;             // DTC 传输 8 次
    ADC10SA   = (unsigned int)adc_data;  // 存储首地址

    ADC10CTL0 |= ENC + ADC10SC;          // 启动转换
    while (!(ADC10CTL0 & ADC10IFG));     // 等待完成
    ADC10CTL0 &= ~ENC;                   // 关闭转换使能

    adc_sum = 0;
    for (i = NUM_SAMPLES; i > 0; i--)    // 倒计数（ULP 13.1 建议）
        adc_sum += adc_data[i - 1];
    adc_avg = (unsigned int)(adc_sum / NUM_SAMPLES);

    // 换算为电压值 (mV):  VREF=2.5V, ADC 10位 (0~1023)
    //   V(mV) = adc_avg * 2500 / 1023
    voltage_mv = (unsigned int)((unsigned long)adc_avg * 2500 / 1023);
}

void Send_Result(void)
{
    UART_SendString(STR_HEAD);           // "原始均值："
    UART_SendNum(adc_avg);               // ADC 平均值
    UART_SendString(STR_MID);            // " , 实测电压："
    UART_SendVoltage(voltage_mv);        // X.XXX
    UART_SendString(STR_TAIL);           // " V\r\n"
}

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;            // 停止看门狗

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR &= ~BIT0;                      // P1.0 = A0 输入
    P1SEL |= BIT0;                       // 功能选择: ADC 通道

    ADC10CTL1 = INCH_0 | CONSEQ_2
              | ADC10SSEL_0 | ADC10DIV_0;

    ADC10CTL0 = SREF_1 | ADC10SHT_3 | MSC
              | REFON | REF2_5V | ADC10ON;

    UART_Init();

    __delay_cycles(30000);

    while (1)
    {
        ADC_Read();                      // ADC 采样 + 求均值 + 电压换算
        Send_Result();                   // 通过 UART 发送到 PC
        __delay_cycles(1000000);         // 延时约 1 秒
    }
}
