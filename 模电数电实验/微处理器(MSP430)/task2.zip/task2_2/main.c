#include <msp430.h>

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;           // 停止看门狗定时器

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR |= BIT6;                      // P1.6 设为输出
    P1OUT &= ~BIT6;                     // 初始低电平

    TA0CCR0  = 9;                      // 半周期: (9+1) = 10 counts → 10us
    TA0CCTL0 = CCIE;                    // 使能 CCR0 中断
    TA0CTL   = TASSEL_2 | MC_1;         // SMCLK, 不分频, 增计数模式

    __bis_SR_register(LPM0_bits | GIE);

    return 0;
}

#pragma vector = TIMER0_A0_VECTOR
__interrupt void Timer0_A0_ISR(void)
{
    P1OUT ^= BIT6;                      // 翻转 P1.6 (LED2)
}
