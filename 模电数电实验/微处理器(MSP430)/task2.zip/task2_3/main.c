#include <msp430.h>

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;           // 停止看门狗

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P2DIR |= BIT2;                      // P2.2 输出
    P2SEL |= BIT2;                      // P2.2 外设功能 (TA1.1)

    TA1CCR0  = 12499;                   // 周期: 12500/125kHz = 100ms → 10Hz
    TA1CCR1  = 2500;                    // 高电平: 2500/125kHz = 20ms → 20%
    TA1CCTL1 = OUTMOD_7;                // Reset/Set 模式
    TA1CTL   = TASSEL_2 | ID_3 | MC_1;  // SMCLK, /8, 增计数

    __bis_SR_register(LPM0_bits);       // 进入 LPM0，硬件自动输出

    return 0;
}
