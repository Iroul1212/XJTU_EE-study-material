#include <msp430.h>

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;           // 停止看门狗定时器

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR |= BIT6;                      // P1.6 设为输出
    P1SEL |= BIT6;                      // P1.6 选择外设功能 (TA0.1)

    TA0CCR0  = 19;                      // 周期: (19+1) = 20 counts → 20us → 50kHz
    TA0CCR1  = 10;                      // 占空比: 10/20 = 50%
    TA0CCTL1 = OUTMOD_7;                // 输出模式 7: Reset/Set (标准PWM)
    TA0CTL   = TASSEL_2 | MC_1;         // SMCLK, 不分频, 增计数模式

    __bis_SR_register(LPM0_bits);

    return 0;
}
