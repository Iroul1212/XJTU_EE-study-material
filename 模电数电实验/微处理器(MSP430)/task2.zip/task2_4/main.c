#include <msp430.h>

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR |= BIT1 | BIT2;               // P1.1, P1.2 输出
    P1SEL |= BIT1 | BIT2;               // 外设功能 (TA0.0, TA0.1)

    TA0CCR0  = 999;                     // 周期 1kHz
    TA0CCTL0 = OUTMOD_4;                // P1.1: CCR0 匹配翻转 → 500Hz, 50%
    TA0CCR1  = 250;                     // 高电平 250/1000 = 25%
    TA0CCTL1 = OUTMOD_7;                // P1.2: 1kHz, 25%
    TA0CTL   = TASSEL_2 | MC_1;         // SMCLK, 不分频, 增计数

    P2DIR |= BIT0 | BIT4;               // P2.0, P2.4 输出
    P2SEL |= BIT0 | BIT4;               // 外设功能 (TA1.0, TA1.2)

    TA1CCR0  = 12499;                   // 周期 10Hz (125kHz / 12500)
    TA1CCTL0 = OUTMOD_4;                // P2.0: CCR0 匹配翻转 → 5Hz, 50%
    TA1CCR2  = 2500;                    // 高电平 2500/12500 = 20%
    TA1CCTL2 = OUTMOD_7;                // P2.4: 10Hz, 20%
    TA1CTL   = TASSEL_2 | ID_3 | MC_1;  // SMCLK, /8, 增计数

    __bis_SR_register(LPM0_bits);

    return 0;
}
