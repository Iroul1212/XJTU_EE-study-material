#include <msp430.h>

#define VCC_VOLTAGE     3.3f            // 板载 Vcc 电压 (V)
#define THRESHOLD_V     2.0f            // 预设判决阈值 (V)

#define THRESHOLD_ADC   ((unsigned int)((THRESHOLD_V / VCC_VOLTAGE) * 1023.0f))

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;           // 停止看门狗

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR |= BIT0;
    P1OUT &= ~BIT0;

    P1DIR &= ~BIT3;
    P1SEL |= BIT3;                      // 功能选择: ADC 输入

    ADC10CTL1 = INCH_3 | ADC10DIV_0
              | ADC10SSEL_0;

    ADC10CTL0 = SREF_0 | ADC10SHT_2 | ADC10SR
              | ADC10ON;

    __delay_cycles(100);

    while (1)
    {

        ADC10CTL0 |= ENC + ADC10SC;

        while (ADC10CTL1 & ADC10BUSY);

        if (ADC10MEM >= THRESHOLD_ADC)
            P1OUT |= BIT0;               // 高于阈值 → 高电平
        else
            P1OUT &= ~BIT0;              // 低于阈值 → 低电平

        ADC10CTL0 &= ~ENC;
    }
}
