#include <msp430.h>

#define NUM_SAMPLES  8                    // DTC 传输次数

unsigned int adc_data[NUM_SAMPLES];       // DTC 自动填充 8 组原始采样值
unsigned long adc_sum;                    // 总和
unsigned int adc_avg;                     // 算术平均值

void main(void)
{
    unsigned int i;

    WDTCTL = WDTPW | WDTHOLD;            // 停止看门狗

    BCSCTL1 = CALBC1_1MHZ;
    DCOCTL  = CALDCO_1MHZ;

    P1DIR &= ~BIT0;
    P1SEL |= BIT0;

    ADC10CTL1 = INCH_0 | CONSEQ_2
              | ADC10SSEL_0 | ADC10DIV_0;

    ADC10CTL0 = SREF_1 | ADC10SHT_3 | MSC
              | REFON | REF2_5V | ADC10ON;

    __delay_cycles(30000);

    ADC10DTC1 = NUM_SAMPLES;
    ADC10SA   = (unsigned int)adc_data;

    ADC10CTL0 |= ENC + ADC10SC;

    while (!(ADC10CTL0 & ADC10IFG));

    ADC10CTL0 &= ~ENC;

    adc_sum = 0;
    for (i = 0; i < NUM_SAMPLES; i++)
        adc_sum += adc_data[i];
    adc_avg = (unsigned int)(adc_sum / NUM_SAMPLES);

    __no_operation();                     // SET BREAKPOINT HERE

    while (1);
}
