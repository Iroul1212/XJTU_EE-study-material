# FIXED

src/USCI_I2C.obj: ../src/USCI_I2C.c
src/USCI_I2C.obj: D:/MSP430/workspace_v12/task3_1/src/USCI_I2C.h
src/USCI_I2C.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
src/USCI_I2C.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430g2553.h
src/USCI_I2C.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
src/USCI_I2C.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
src/USCI_I2C.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h

../src/USCI_I2C.c:

D:/MSP430/workspace_v12/task3_1/src/USCI_I2C.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430g2553.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

