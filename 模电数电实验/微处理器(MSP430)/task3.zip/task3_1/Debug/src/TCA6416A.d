# FIXED

src/TCA6416A.obj: ../src/TCA6416A.c
src/TCA6416A.obj: D:/MSP430/workspace_v12/task3_1/src/TCA6416A.h
src/TCA6416A.obj: D:/MSP430/workspace_v12/task3_1/src/USCI_I2C.h
src/TCA6416A.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
src/TCA6416A.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430g2553.h
src/TCA6416A.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
src/TCA6416A.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
src/TCA6416A.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h

../src/TCA6416A.c:

D:/MSP430/workspace_v12/task3_1/src/TCA6416A.h:

D:/MSP430/workspace_v12/task3_1/src/USCI_I2C.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430g2553.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

