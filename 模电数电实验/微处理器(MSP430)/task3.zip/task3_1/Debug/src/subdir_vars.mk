################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/HT1621.c \
../src/LCD_128.c \
../src/TCA6416A.c \
../src/USCI_I2C.c 

C_DEPS += \
./src/HT1621.d \
./src/LCD_128.d \
./src/TCA6416A.d \
./src/USCI_I2C.d 

OBJS += \
./src/HT1621.obj \
./src/LCD_128.obj \
./src/TCA6416A.obj \
./src/USCI_I2C.obj 

OBJS__QUOTED += \
"src\HT1621.obj" \
"src\LCD_128.obj" \
"src\TCA6416A.obj" \
"src\USCI_I2C.obj" 

C_DEPS__QUOTED += \
"src\HT1621.d" \
"src\LCD_128.d" \
"src\TCA6416A.d" \
"src\USCI_I2C.d" 

C_SRCS__QUOTED += \
"../src/HT1621.c" \
"../src/LCD_128.c" \
"../src/TCA6416A.c" \
"../src/USCI_I2C.c" 


