#include <msp430.h>

#define SMCLK_HZ  16000000UL

volatile unsigned int  cap_old;           // 第一次捕获值
volatile unsigned int  cap_new;           // 第二次捕获值
volatile unsigned int  ovf_cnt;           // 两次捕获间溢出次数
volatile unsigned char cap_ready;         // 0=等待, 1=等待二次, 2=完成
volatile unsigned int  pulse_cnt;         // 周期内的 SMCLK 时钟周期数
volatile unsigned long period_ticks;      // 周期 (SMCLK ticks)
volatile unsigned long freq_hz;           // 频率 (Hz)


void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    DCOCTL  = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;
    BCSCTL2  = 0;

    P1DIR |= BIT0;
    P1OUT &= ~BIT0;
    P1DIR &= ~BIT2;
    P1SEL |= BIT2;                        // TA0.1 CCI1A

    TA0CTL   = TASSEL_2 | MC_2 | TAIE;

    TA0CCTL1 = CM_1 | CCIS_0 | CAP | SCS | CCIE;

    __enable_interrupt();

    while (1)
    {
        while (cap_ready < 2)
            __low_power_mode_0();

        if (cap_new >= cap_old)
            period_ticks = (unsigned long)(cap_new - cap_old);
        else
            period_ticks = (unsigned long)(0xFFFF - cap_old)
                         + (unsigned long)cap_new + 1UL;
        period_ticks += (unsigned long)ovf_cnt * 65536UL;

        if (period_ticks > 0)
            freq_hz = SMCLK_HZ / period_ticks;
        else
            freq_hz = 0;

        P1OUT ^= BIT0;
        pulse_cnt = (unsigned int)period_ticks;  // 冻结时钟周期数
        cap_ready = 0;
    }
}


#pragma vector = TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
    switch (__even_in_range(TA0IV, 14))
    {
        case 2:                            // CCR1 捕获
            if (cap_ready == 0) {
                ovf_cnt   = 0;
                cap_old   = TA0CCR1;
                cap_ready = 1;
            } else if (cap_ready == 1) {
                cap_new   = TA0CCR1;
                cap_ready = 2;
                __bic_SR_register_on_exit(LPM0_bits);
            }
            break;

        case 10:                           // 定时器溢出
            if (cap_ready == 1)
                ovf_cnt++;
            break;

        default:
            break;
    }
}

