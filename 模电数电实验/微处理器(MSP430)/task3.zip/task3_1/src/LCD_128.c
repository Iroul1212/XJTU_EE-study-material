/*
 * LCD_128.c
 * 128段式LCD 顶层库函数实现
 * 基于《LaunchPad口袋实验平台》第14章
 *
 * LCD_Buffer[8] 与 HT1621 32字节显存一一对应
 * 每个 Buffer 16位, 共 8×16 = 128 位 = 128 段
 */

#include "src/LCD_128.h"

/* 全局显存数组 (128位 = 8×16位) */
unsigned int LCD_Buffer[8] = {0};

/*
 * 清屏: 清除全部 128 段
 */
void LCD_Clear(void)
{
    unsigned char i = 0;
    for (i = 0; i <= 7; i++)
        LCD_Buffer[i] = 0;
}

/*
 * 显示某一段
 * SegNum: 0~127 段号
 */
void LCD_DisplaySeg(unsigned char SegNum)
{
    LCD_Buffer[SegNum / 16] |= 1 << (SegNum % 16);
}

/*
 * 消隐某一段
 * SegNum: 0~127 段号
 */
void LCD_ClearSeg(unsigned char SegNum)
{
    LCD_Buffer[SegNum / 16] &= ~(1 << (SegNum % 16));
}

/*
 * 显示单个数码 (在指定位置显示数字 0~9)
 * Digit: 0~9 要显示的数字, 其他值则消隐
 * Position: 1~10, 对应第几个 "8字段"
 *
 * 显示译码表 (参考手册表14.3):
 * 位1 (buffer[0]): 消隐=0EF0, 0=0EB0,1=0600,2=0C70,3=0E50,4=06C0,
 *                    5=0AD0,6=0AF0,7=0E00,8=0EF0,9=0ED0
 * 位2 (buffer[0]高4位+buffer[1]低4位):
 *                    消隐=F000/000E, 0=B000/000E,1=0000/0006,
 *                    2=7000/000C,3=5000/000E,4=C000/0006,
 *                    5=D000/000A,6=F000/000A,7=0000/000E,
 *                    8=F000/000E,9=D000/000E
 * 位3 (buffer[1]): 同位1
 * 位4 (buffer[3]低8位): 消隐=00EF, 0=00EB,1=0060,2=00C7,3=00E5,
 *                         4=006C,5=00AD,6=00AF,7=00E0,8=00EF,9=00ED
 * 位5 (buffer[3]高8位): 消隐=EF00, 0=EB00,1=6000,2=C700,3=E500,
 *                         4=6C00,5=AD00,6=AF00,7=E000,8=EF00,9=ED00
 * 位6 (buffer[4]低8位): 同位4
 * 位7 (buffer[6]低8位): 消隐=00F7, 0=00D7,1=0006,2=00E3,3=00A7,
 *                         4=0036,5=00B5,6=00F5,7=0007,8=00F7,9=00B7
 * 位8 (buffer[6]高8位): 消隐=F700, 0=D700,1=0600,2=E300,3=A700,
 *                         4=3600,5=B500,6=F500,7=0700,8=F700,9=B700
 * 位9 (buffer[7]低8位): 同位7
 * 位10(buffer[7]高8位): 同位8
 */
void LCD_DisplayDigit(unsigned char Digit, unsigned char Position)
{
    switch (Position)
    {
    case 1:     /* 第1个 "8字段" (大数码, 左1), buffer[0] 低12位 */
        LCD_Buffer[0] &= 0xF00F;            // 清除位1相关段
        switch (Digit)
        {
        case 0:  LCD_Buffer[0] |= 0x0EB0; break;
        case 1:  LCD_Buffer[0] |= 0x0600; break;
        case 2:  LCD_Buffer[0] |= 0x0C70; break;
        case 3:  LCD_Buffer[0] |= 0x0E50; break;
        case 4:  LCD_Buffer[0] |= 0x06C0; break;
        case 5:  LCD_Buffer[0] |= 0x0AD0; break;
        case 6:  LCD_Buffer[0] |= 0x0AF0; break;
        case 7:  LCD_Buffer[0] |= 0x0E00; break;
        case 8:  LCD_Buffer[0] |= 0x0EF0; break;
        case 9:  LCD_Buffer[0] |= 0x0ED0; break;
        default: break;                     // 消隐
        }
        break;

    case 2:     /* 第2个 "8字段" (大数码, 左2), buffer[0]高4位 + buffer[1]低4位 */
        LCD_Buffer[0] &= 0x0FFF;            // 清除 buffer[0] 高4位
        LCD_Buffer[1] &= 0xFFF0;            // 清除 buffer[1] 低4位
        switch (Digit)
        {
        case 0:  LCD_Buffer[0] |= 0xB000; LCD_Buffer[1] |= 0x000E; break;
        case 1:  LCD_Buffer[0] |= 0x0000; LCD_Buffer[1] |= 0x0006; break;
        case 2:  LCD_Buffer[0] |= 0x7000; LCD_Buffer[1] |= 0x000C; break;
        case 3:  LCD_Buffer[0] |= 0x5000; LCD_Buffer[1] |= 0x000E; break;
        case 4:  LCD_Buffer[0] |= 0xC000; LCD_Buffer[1] |= 0x0006; break;
        case 5:  LCD_Buffer[0] |= 0xD000; LCD_Buffer[1] |= 0x000A; break;
        case 6:  LCD_Buffer[0] |= 0xF000; LCD_Buffer[1] |= 0x000A; break;
        case 7:  LCD_Buffer[0] |= 0x0000; LCD_Buffer[1] |= 0x000E; break;
        case 8:  LCD_Buffer[0] |= 0xF000; LCD_Buffer[1] |= 0x000E; break;
        case 9:  LCD_Buffer[0] |= 0xD000; LCD_Buffer[1] |= 0x000E; break;
        default: break;                     // 消隐
        }
        break;

    case 3:     /* 第3个 "8字段" (大数码, 左3), buffer[1] 位4~15 */
        LCD_Buffer[1] &= 0xF00F;            // 清除位3相关段
        switch (Digit)
        {
        case 0:  LCD_Buffer[1] |= 0x0EB0; break;
        case 1:  LCD_Buffer[1] |= 0x0600; break;
        case 2:  LCD_Buffer[1] |= 0x0C70; break;
        case 3:  LCD_Buffer[1] |= 0x0E50; break;
        case 4:  LCD_Buffer[1] |= 0x06C0; break;
        case 5:  LCD_Buffer[1] |= 0x0AD0; break;
        case 6:  LCD_Buffer[1] |= 0x0AF0; break;
        case 7:  LCD_Buffer[1] |= 0x0E00; break;
        case 8:  LCD_Buffer[1] |= 0x0EF0; break;
        case 9:  LCD_Buffer[1] |= 0x0ED0; break;
        default: break;
        }
        break;

    case 4:     /* 第4个 "8字段" (大数码, 左4), buffer[3] 低8位 */
        LCD_Buffer[3] &= 0xFF00;
        switch (Digit)
        {
        case 0:  LCD_Buffer[3] |= 0x00EB; break;
        case 1:  LCD_Buffer[3] |= 0x0060; break;
        case 2:  LCD_Buffer[3] |= 0x00C7; break;
        case 3:  LCD_Buffer[3] |= 0x00E5; break;
        case 4:  LCD_Buffer[3] |= 0x006C; break;
        case 5:  LCD_Buffer[3] |= 0x00AD; break;
        case 6:  LCD_Buffer[3] |= 0x00AF; break;
        case 7:  LCD_Buffer[3] |= 0x00E0; break;
        case 8:  LCD_Buffer[3] |= 0x00EF; break;
        case 9:  LCD_Buffer[3] |= 0x00ED; break;
        default: break;
        }
        break;

    case 5:     /* 第5个 "8字段" (大数码, 左5), buffer[3] 高8位 */
        LCD_Buffer[3] &= 0x00FF;
        switch (Digit)
        {
        case 0:  LCD_Buffer[3] |= 0xEB00; break;
        case 1:  LCD_Buffer[3] |= 0x6000; break;
        case 2:  LCD_Buffer[3] |= 0xC700; break;
        case 3:  LCD_Buffer[3] |= 0xE500; break;
        case 4:  LCD_Buffer[3] |= 0x6C00; break;
        case 5:  LCD_Buffer[3] |= 0xAD00; break;
        case 6:  LCD_Buffer[3] |= 0xAF00; break;
        case 7:  LCD_Buffer[3] |= 0xE000; break;
        case 8:  LCD_Buffer[3] |= 0xEF00; break;
        case 9:  LCD_Buffer[3] |= 0xED00; break;
        default: break;
        }
        break;

    case 6:     /* 第6个 "8字段" (大数码, 左6), buffer[4] 低8位 */
        LCD_Buffer[4] &= 0xFF00;
        switch (Digit)
        {
        case 0:  LCD_Buffer[4] |= 0x00EB; break;
        case 1:  LCD_Buffer[4] |= 0x0060; break;
        case 2:  LCD_Buffer[4] |= 0x00C7; break;
        case 3:  LCD_Buffer[4] |= 0x00E5; break;
        case 4:  LCD_Buffer[4] |= 0x006C; break;
        case 5:  LCD_Buffer[4] |= 0x00AD; break;
        case 6:  LCD_Buffer[4] |= 0x00AF; break;
        case 7:  LCD_Buffer[4] |= 0x00E0; break;
        case 8:  LCD_Buffer[4] |= 0x00EF; break;
        case 9:  LCD_Buffer[4] |= 0x00ED; break;
        default: break;
        }
        break;

    case 7:     /* 第7个 "8字段" (小数码, 右至左第1个), buffer[6] 低8位 */
        LCD_Buffer[6] &= 0xFF00;
        switch (Digit)
        {
        case 0:  LCD_Buffer[6] |= 0x00D7; break;
        case 1:  LCD_Buffer[6] |= 0x0006; break;
        case 2:  LCD_Buffer[6] |= 0x00E3; break;
        case 3:  LCD_Buffer[6] |= 0x00A7; break;
        case 4:  LCD_Buffer[6] |= 0x0036; break;
        case 5:  LCD_Buffer[6] |= 0x00B5; break;
        case 6:  LCD_Buffer[6] |= 0x00F5; break;
        case 7:  LCD_Buffer[6] |= 0x0007; break;
        case 8:  LCD_Buffer[6] |= 0x00F7; break;
        case 9:  LCD_Buffer[6] |= 0x00B7; break;
        default: break;
        }
        break;

    case 8:     /* 第8个 "8字段" (小数码, 右至左第2个), buffer[6] 高8位 */
        LCD_Buffer[6] &= 0x00FF;
        switch (Digit)
        {
        case 0:  LCD_Buffer[6] |= 0xD700; break;
        case 1:  LCD_Buffer[6] |= 0x0600; break;
        case 2:  LCD_Buffer[6] |= 0xE300; break;
        case 3:  LCD_Buffer[6] |= 0xA700; break;
        case 4:  LCD_Buffer[6] |= 0x3600; break;
        case 5:  LCD_Buffer[6] |= 0xB500; break;
        case 6:  LCD_Buffer[6] |= 0xF500; break;
        case 7:  LCD_Buffer[6] |= 0x0700; break;
        case 8:  LCD_Buffer[6] |= 0xF700; break;
        case 9:  LCD_Buffer[6] |= 0xB700; break;
        default: break;
        }
        break;

    case 9:     /* 第9个 "8字段" (小数码, 右至左第3个), buffer[7] 低8位 */
        LCD_Buffer[7] &= 0xFF00;
        switch (Digit)
        {
        case 0:  LCD_Buffer[7] |= 0x00D7; break;
        case 1:  LCD_Buffer[7] |= 0x0006; break;
        case 2:  LCD_Buffer[7] |= 0x00E3; break;
        case 3:  LCD_Buffer[7] |= 0x00A7; break;
        case 4:  LCD_Buffer[7] |= 0x0036; break;
        case 5:  LCD_Buffer[7] |= 0x00B5; break;
        case 6:  LCD_Buffer[7] |= 0x00F5; break;
        case 7:  LCD_Buffer[7] |= 0x0007; break;
        case 8:  LCD_Buffer[7] |= 0x00F7; break;
        case 9:  LCD_Buffer[7] |= 0x00B7; break;
        default: break;
        }
        break;

    case 10:    /* 第10个 "8字段" (小数码, 右至左第4个), buffer[7] 高8位 */
        LCD_Buffer[7] &= 0x00FF;
        switch (Digit)
        {
        case 0:  LCD_Buffer[7] |= 0xD700; break;
        case 1:  LCD_Buffer[7] |= 0x0600; break;
        case 2:  LCD_Buffer[7] |= 0xE300; break;
        case 3:  LCD_Buffer[7] |= 0xA700; break;
        case 4:  LCD_Buffer[7] |= 0x3600; break;
        case 5:  LCD_Buffer[7] |= 0xB500; break;
        case 6:  LCD_Buffer[7] |= 0xF500; break;
        case 7:  LCD_Buffer[7] |= 0x0700; break;
        case 8:  LCD_Buffer[7] |= 0xF700; break;
        case 9:  LCD_Buffer[7] |= 0xB700; break;
        default: break;
        }
        break;

    default:
        break;
    }
}

/*
 * 连续显示整数
 * Digit: -32768 ~ 32767
 * 显示在 6 个大数码上 (位置1~6)
 */
void LCD_DisplayNum(long int Digit)
{
    unsigned char i = 0;
    unsigned char DispBuff[6] = {0};

    if (Digit < 0)
    {
        Digit = -Digit;
        LCD_DisplaySeg(_LCD_NEG);       // 显示负号
    }
    else
    {
        LCD_ClearSeg(_LCD_NEG);         // 清除负号
    }

    /* 拆分数字 (个位→高位) */
    for (i = 0; i < 6; i++)
    {
        DispBuff[i] = (unsigned char)(Digit % 10);
        Digit /= 10;
    }

    /* 消隐高位无效0 */
    for (i = 5; i > 0; i--)
    {
        if (DispBuff[i] == 0)
            DispBuff[i] = LCD_DIGIT_CLEAR;
        else
            break;
    }
    /* i=0 (个位) 始终显示, 即使是0 */

    /* 显示 (DispBuff[0]为个位, 在位置6; DispBuff[5]为最高位, 在位置1) */
    for (i = 0; i < 6; i++)
    {
        LCD_DisplayDigit(DispBuff[i], 6 - i);
    }
}

/*
 * 计算单个 8字段 的显存值和 HT1621 起始地址
 * Position: 8字段位置 (1~10)
 * Num_Buffer: 返回该位的段码字节
 * Addr: 返回该位在 HT1621 显存中的起始地址
 *
 * HT1621 显存地址 = 首段号 / 4
 */
void Calculate_NumBuff(unsigned char Position,
                       unsigned char *Num_Buffer,
                       unsigned char *Addr)
{
    switch (Position)
    {
    case 1:
        *Num_Buffer = (unsigned char)((LCD_Buffer[0] & 0x0FF0) >> 4);
        *Addr = 4 / 4;      // 首段4, 地址1
        break;
    case 2:
        *Num_Buffer = (unsigned char)(((LCD_Buffer[0] & 0xF000) >> 12) |
                                      ((LCD_Buffer[1] & 0x000F) << 4));
        *Addr = 12 / 4;     // 首段12, 地址3
        break;
    case 3:
        *Num_Buffer = (unsigned char)((LCD_Buffer[1] & 0x0FF0) >> 4);
        *Addr = 20 / 4;     // 首段20, 地址5
        break;
    case 4:
        *Num_Buffer = (unsigned char)(LCD_Buffer[3] & 0x00FF);
        *Addr = 48 / 4;     // 首段48, 地址12
        break;
    case 5:
        *Num_Buffer = (unsigned char)((LCD_Buffer[3] & 0xFF00) >> 8);
        *Addr = 56 / 4;     // 首段56, 地址14
        break;
    case 6:
        *Num_Buffer = (unsigned char)(LCD_Buffer[4] & 0x00FF);
        *Addr = 64 / 4;     // 首段64, 地址16
        break;
    case 7:
        *Num_Buffer = (unsigned char)(LCD_Buffer[6] & 0x00FF);
        *Addr = 96 / 4;     // 首段96, 地址24
        break;
    case 8:
        *Num_Buffer = (unsigned char)((LCD_Buffer[6] & 0xFF00) >> 8);
        *Addr = 104 / 4;    // 首段104, 地址26
        break;
    case 9:
        *Num_Buffer = (unsigned char)(LCD_Buffer[7] & 0x00FF);
        *Addr = 112 / 4;    // 首段112, 地址28
        break;
    case 10:
        *Num_Buffer = (unsigned char)((LCD_Buffer[7] & 0xFF00) >> 8);
        *Addr = 120 / 4;    // 首段120, 地址30
        break;
    default:
        *Num_Buffer = 0;
        *Addr = 0;
        break;
    }
}

/*
 * 温度专用显示函数
 * 在大数码区显示带一位小数的温度值, 并显示 °C 符号
 *
 * 显示格式:
 *   正温度: "XX.X°C" — 位置4=十位, 位5=个位, DOT3(段52)=小数点, 位6=十分位
 *   负温度: "-XX.X°C"
 *
 * Temp_x10: 温度值 × 10 (如 253 表示 25.3°C, -54 表示 -5.4°C)
 * isPositive: 1=正温度(不显示负号), 0=负温度(显示负号)
 */
void LCD_DisplayTemp(int Temp_x10, unsigned char isPositive)
{
    unsigned char tens, ones, tenths;

    /* 取绝对值 */
    if (Temp_x10 < 0)
        Temp_x10 = -Temp_x10;

    tens   = (unsigned char)(Temp_x10 / 100);       // 十位
    ones   = (unsigned char)((Temp_x10 / 10) % 10); // 个位
    tenths = (unsigned char)(Temp_x10 % 10);         // 十分位

    /* 负号处理 */
    if (!isPositive)
        LCD_DisplaySeg(_LCD_NEG);
    else
        LCD_ClearSeg(_LCD_NEG);

    /* 十位 (位置4): 消隐前导0 */
    if (tens == 0)
        LCD_DisplayDigit(LCD_DIGIT_CLEAR, 4);
    else
        LCD_DisplayDigit(tens, 4);

    /* 个位 (位置5) */
    LCD_DisplayDigit(ones, 5);

    /* 小数点: DOT4 (段60), 在位置5和6之间 */
    LCD_DisplaySeg(_LCD_DOT4);

    /* 十分位 (位置6) */
    LCD_DisplayDigit(tenths, 6);

    /* 显示温度符号 °C */
    LCD_DisplaySeg(_LCD_DEGREE);        // ° 符号
    LCD_DisplaySeg(_LCD_AC);            // 借用 AC 符号模拟 'C' (或直接只用°)

    /* 清除位置1~3 (不使用的前导大数码) */
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 1);
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 2);
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 3);

    /* 在小型数码区(位置7~10)显示温度符号相关 */
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 7);
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 8);
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 9);
    LCD_DisplayDigit(LCD_DIGIT_CLEAR, 10);
}
