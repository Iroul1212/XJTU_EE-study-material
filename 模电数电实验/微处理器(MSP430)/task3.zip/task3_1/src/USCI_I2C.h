/*
 * USCI_I2C.h
 * MSP430G2553 硬件 I2C 库函数头文件
 * 基于《LaunchPad口袋实验平台》第12章
 */

#ifndef USCI_I2C_H_
#define USCI_I2C_H_

#include <msp430.h>

/* I2C 状态宏定义 */
#define I2C_IDLE    0
#define I2C_TX      1
#define I2C_RX      2
#define I2C_SNDSTOP 3

#define I2C_ACK     0
#define I2C_NACK    1

/* 全局变量 */
extern volatile unsigned char I2C_State;
extern volatile unsigned char *I2C_TxPtr;
extern volatile unsigned char *I2C_RxPtr;
extern volatile unsigned char I2C_TxLen;
extern volatile unsigned char I2C_RxLen;
extern volatile unsigned char I2C_TxDone;
extern volatile unsigned char I2C_RxDone;
extern volatile unsigned char I2C_RxNack;

/* 函数声明 */
void I2C_Init(void);
void I2C_Tx_Init(unsigned char *Data, unsigned char Len);
void I2C_Rx_Init(unsigned char *Data, unsigned char Len);
unsigned char I2C_TxFrame(unsigned char SlaveAddr, unsigned char *Data, unsigned char Len);
unsigned char I2C_RxFrame(unsigned char SlaveAddr, unsigned char *Data, unsigned char Len);

#endif /* USCI_I2C_H_ */
