/*
 * TCA6416A.h
 * IO 扩展芯片 TCA6416A 库函数头文件
 * 基于《LaunchPad口袋实验平台》第12章
 */

#ifndef TCA6416A_H_
#define TCA6416A_H_

#include "src/USCI_I2C.h"

/* TCA6416A I2C 从机地址 */
#define TCA6416A_ADDR   0x20

/* TCA6416A 寄存器地址 */
#define TCA6416_INPUT0   0x00
#define TCA6416_INPUT1   0x01
#define TCA6416_OUTPUT0  0x02
#define TCA6416_OUTPUT1  0x03
#define TCA6416_POLAR0   0x04
#define TCA6416_POLAR1   0x05
#define TCA6416_CONFIG0  0x06
#define TCA6416_CONFIG1  0x07

/* 全局变量 */
extern unsigned char Port0_Output;
extern unsigned char Port1_Output;

/* 函数声明 */
void TCA6416A_Init(void);
unsigned char TCA6416_Tx_Frame(unsigned char RegAddr, unsigned char Data);
unsigned char TCA6416_Rx_Frame(unsigned char RegAddr);
void PinOUT(unsigned char PinNum, unsigned char Level);
unsigned char PinIN(unsigned char PinNum);

#endif /* TCA6416A_H_ */
