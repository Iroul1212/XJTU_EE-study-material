/*
 * HT1621.h
 * LCD 驱动器 HT1621 库函数头文件
 * 基于《LaunchPad口袋实验平台》第14章
 */

#ifndef HT1621_H_
#define HT1621_H_

#include "src/TCA6416A.h"

/*
 * 硬件隔离宏定义：通过 TCA6416A 间接控制 HT1621
 * TCA6416A Pin 14 = /CS
 * TCA6416A Pin 15 = /RD
 * TCA6416A Pin 16 = /WR
 * TCA6416A Pin 17 = DATA
 */
#define HT1621_CS_LOW      PinOUT(14, 0)
#define HT1621_CS_HIGH     PinOUT(14, 1)
#define HT1621_RD_LOW      PinOUT(15, 0)
#define HT1621_RD_HIGH     PinOUT(15, 1)
#define HT1621_WR_LOW      PinOUT(16, 0)
#define HT1621_WR_HIGH     PinOUT(16, 1)
#define HT1621_DATA_LOW    PinOUT(17, 0)
#define HT1621_DATA_HIGH   PinOUT(17, 1)

/* HT1621 命令字 */
#define HT1621_COMMAND      4    // 100 写命令
#define HT1621_WRITEDISBUF  5    // 101 写显存
#define HT1621_INIT_BIAS    0x29 // 1/3 bias + 4 COM
#define HT1621_OSC          0x01 // 内部振荡器使能

/* BIT0~BIT7 宏已由 msp430g2553.h 提供, 此处不再重复定义 */

/* 函数声明 */
void HT1621_SendBit(unsigned int Code);
void HT1621_init(void);
void HT1621_Reflash(unsigned int *p);
void HT1621_Reflash_Digit(unsigned char Position);
void HT1621_Delay(void);

#endif /* HT1621_H_ */
