/*
 * LCD_128.h
 * 128段式LCD 顶层库函数头文件
 * 基于《LaunchPad口袋实验平台》第14章
 * LCD 段码宏定义及函数声明
 */

#ifndef LCD_128_H_
#define LCD_128_H_

/* ===== 128 段码宏定义 ===== */
/* 通用符号 */
#define _LCD_MIN           0
#define _LCD_NEG           1
#define _LCD_POS           2
#define _LCD_MAX           3

/* 小数点 (DOT0~DOT6 对应 10 个 "8字段" 之间的小数点) */
#define _LCD_DOT0          8
#define _LCD_DOT1          16
#define _LCD_DOT2          24
#define _LCD_DOT3          52
#define _LCD_DOT4          60
#define _LCD_DOT5          107
#define _LCD_DOT6          123

/* 冒号 */
#define _LCD_COLON0        99
#define _LCD_COLON1        83
#define _LCD_COLON2        115

/* 状态指示 */
#define _LCD_BUSY          28
#define _LCD_ERROR         29
#define _LCD_AUTO          30
#define _LCD_RUN           31
#define _LCD_PAUSE         32
#define _LCD_STOP          33

/* 单位符号 */
#define _LCD_kPA           34
#define _LCD_k_g           35
#define _LCD_pre_s         36
#define _LCD_m_pre_s       37
#define _LCD_c_m_pre_s     38
#define _LCD_g             39
#define _LCD_TI_logo       40
#define _LCD_AC            41
#define _LCD_DC            42
#define _LCD_Hz            43
#define _LCD_L             44
#define _LCD_M3            45
#define _LCD_M_Hz          46
#define _LCD_k_Hz          47
#define _LCD_PRECENT       68
#define _LCD_k_W           72
#define _LCD_m_V           73
#define _LCD_m_A           74
#define _LCD_k_OHOM        75
#define _LCD_W             76
#define _LCD_V             77
#define _LCD_A             78
#define _LCD_OHOM          79
#define _LCD_DEGREE        80
#define _LCD_dB            81
#define _LCD_QDU_logo      82

/* 附加符号 */
#define _LCD_3_AT          84
#define _LCD_2_AT          85
#define _LCD_AT            86
#define _LCD_BELL          87
#define _LCD_AM            88
#define _LCD_FM            89
#define _LCD_RX            90
#define _LCD_LOCK          91
#define _LCD_PM            92
#define _LCD_CH            93
#define _LCD_TX            94
#define _LCD_LOWBAT        95

/* 第1个 "8字段" 段码 (左1 大数码, 位1) */
#define _LCD_1A            11
#define _LCD_1B            10
#define _LCD_1C            9
#define _LCD_1D            4
#define _LCD_1E            5
#define _LCD_1F            7
#define _LCD_1G            6

/* 第2个 "8字段" 段码 (左2 大数码, 位2) */
#define _LCD_2A            19
#define _LCD_2B            18
#define _LCD_2C            17
#define _LCD_2D            12
#define _LCD_2E            13
#define _LCD_2F            15
#define _LCD_2G            14

/* 第3个 "8字段" 段码 (左3 大数码, 位3) */
#define _LCD_3A            27
#define _LCD_3B            26
#define _LCD_3C            25
#define _LCD_3D            20
#define _LCD_3E            21
#define _LCD_3F            23
#define _LCD_3G            22

/* 第4个 "8字段" 段码 (左4 大数码, 位4) */
#define _LCD_4A            55
#define _LCD_4B            54
#define _LCD_4C            53
#define _LCD_4D            48
#define _LCD_4E            49
#define _LCD_4F            51
#define _LCD_4G            50

/* 第5个 "8字段" 段码 (左5 大数码, 位5) */
#define _LCD_5A            63
#define _LCD_5B            62
#define _LCD_5C            61
#define _LCD_5D            56
#define _LCD_5E            57
#define _LCD_5F            59
#define _LCD_5G            58

/* 第6个 "8字段" 段码 (左6 大数码, 位6) */
#define _LCD_6A            71
#define _LCD_6B            70
#define _LCD_6C            69
#define _LCD_6D            64
#define _LCD_6E            65
#define _LCD_6F            67
#define _LCD_6G            66

/* 第7个 "8字段" 段码 (小数码, 右至左第1个, 位7) */
#define _LCD_7A            96
#define _LCD_7B            97
#define _LCD_7C            98
#define _LCD_7D            103
#define _LCD_7E            102
#define _LCD_7F            100
#define _LCD_7G            101

/* 第8个 "8字段" 段码 (小数码, 右至左第2个, 位8) */
#define _LCD_8A            104
#define _LCD_8B            105
#define _LCD_8C            106
#define _LCD_8D            111
#define _LCD_8E            110
#define _LCD_8F            108
#define _LCD_8G            109

/* 第9个 "8字段" 段码 (小数码, 右至左第3个, 位9) */
#define _LCD_9A            112
#define _LCD_9B            113
#define _LCD_9C            114
#define _LCD_9D            119
#define _LCD_9E            118
#define _LCD_9F            116
#define _LCD_9G            117

/* 第10个 "8字段" 段码 (小数码, 右至左第4个, 位10) */
#define _LCD_10A           120
#define _LCD_10B           121
#define _LCD_10C           122
#define _LCD_10D           127
#define _LCD_10E           126
#define _LCD_10F           124
#define _LCD_10G           125

/* 消隐标记 */
#define LCD_DIGIT_CLEAR    11

/* ===== 全局显存数组 ===== */
extern unsigned int LCD_Buffer[8];

/* ===== 函数声明 ===== */
void LCD_Clear(void);
void LCD_DisplaySeg(unsigned char SegNum);
void LCD_ClearSeg(unsigned char SegNum);
void LCD_DisplayDigit(unsigned char Digit, unsigned char Position);
void LCD_DisplayNum(long int Digit);
void Calculate_NumBuff(unsigned char Position,
                       unsigned char *Num_Buffer,
                       unsigned char *Addr);

/*
 * 温度专用显示函数
 * 显示带一位小数的温度值
 * Temp_x10: 温度值 × 10 (如 253 表示 25.3°C)
 * isPositive: 1=正温度, 0=负温度
 */
void LCD_DisplayTemp(int Temp_x10, unsigned char isPositive);

#endif /* LCD_128_H_ */
