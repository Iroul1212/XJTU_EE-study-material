/*
 * HT1621.c
 * LCD 驱动器 HT1621 库函数实现
 * 基于《LaunchPad口袋实验平台》第14章
 */

#include "src/HT1621.h"

/*
 * 向 HT1621 发送一个位
 * Code=0: 数据线置低
 * Code!=0: 数据线置高
 */
void HT1621_SendBit(unsigned int Code)
{
    HT1621_WR_LOW;
    if (Code == 0)
    {
        HT1621_DATA_LOW;
    }
    else
    {
        HT1621_DATA_HIGH;
    }
    HT1621_WR_HIGH;
}

/*
 * HT1621 初始化
 * 开启 LCD 驱动, 1/3 bias, 4 COM, 内部振荡器
 */
void HT1621_init(void)
{
    unsigned char i = 0;
    unsigned char Temp = 0;

    /* 全部信号线拉高，再 CS 使能 */
    HT1621_CS_HIGH;
    HT1621_WR_HIGH;
    HT1621_DATA_HIGH;
    HT1621_CS_LOW;

    /* --- 发送命令字 100，表明是写命令 --- */
    Temp = HT1621_COMMAND;
    for (i = 0; i < 3; i++)
    {
        HT1621_SendBit(Temp & BIT2);
        Temp = Temp << 1;
    }

    /* --- 开启 LCD 驱动: 0000 0011 --- */
    Temp = 0x03;
    for (i = 0; i < 8; i++)
    {
        HT1621_SendBit(Temp & BIT7);
        Temp = Temp << 1;
    }
    HT1621_WR_LOW;
    HT1621_WR_HIGH;       // 空发 1 位

    /* --- 设为 1/3 bias 和 4 COM: 0010 1001 --- */
    Temp = HT1621_INIT_BIAS;
    for (i = 0; i < 8; i++)
    {
        HT1621_SendBit(Temp & BIT7);
        Temp = Temp << 1;
    }
    HT1621_WR_LOW;
    HT1621_WR_HIGH;       // 空发 1 位

    /* --- 开启内部振荡器: 0000 0001 --- */
    Temp = HT1621_OSC;
    for (i = 0; i < 8; i++)
    {
        HT1621_SendBit(Temp & BIT7);
        Temp = Temp << 1;
    }
    HT1621_WR_LOW;
    HT1621_WR_HIGH;       // 空发 1 位

    HT1621_CS_HIGH;       // CS 置高，片选禁止
}

/*
 * 全显存刷新（刷屏）
 * 将 LCD_Buffer[] 全部 128 段写入 HT1621 显存
 */
void HT1621_Reflash(unsigned int *p)
{
    unsigned char i = 0, j = 0;
    unsigned int Temp = 0;

    HT1621_CS_LOW;        // 使能

    /* 发送命令字 101 (写显存) */
    for (i = 0; i < 3; i++)
    {
        HT1621_SendBit((HT1621_WRITEDISBUF << i) & BIT2);
    }

    /* 发送显存首地址 000000 */
    for (i = 0; i <= 5; i++)
    {
        HT1621_SendBit(0);
    }

    /* 发送 128 位显存，分 8 字每字 16 位 */
    for (i = 0; i < 8; i++)
    {
        Temp = *p++;
        for (j = 0; j < 16; j++)
        {
            HT1621_SendBit(Temp & BIT0);
            Temp = Temp >> 1;
        }
    }

    HT1621_CS_HIGH;       // 使能禁止
}

/*
 * 单字节显存刷新
 * 只更新指定 8 字段所在的 HT1621 显存
 * Position: 1~10 (对应 10 个 "8字段")
 */
void HT1621_Reflash_Digit(unsigned char Position)
{
    unsigned char Num_Buffer = 0;
    unsigned char Addr = 0;
    unsigned char i = 0;

    /* 需要 LCD_128.c 中的 Calculate_NumBuff 函数 */
    extern void Calculate_NumBuff(unsigned char Position,
                                  unsigned char *Num_Buffer,
                                  unsigned char *Addr);
    Calculate_NumBuff(Position, &Num_Buffer, &Addr);

    HT1621_CS_LOW;        // 使能

    /* 发送命令字 101 (写显存) */
    for (i = 0; i < 3; i++)
    {
        HT1621_SendBit((HT1621_WRITEDISBUF << i) & BIT2);
    }

    /* 发送 6 位待写显存首地址 */
    for (i = 0; i < 6; i++)
    {
        HT1621_SendBit((Addr << i) & BIT5);
    }

    /* 发送 1 字节数据 */
    for (i = 0; i < 8; i++)
    {
        HT1621_SendBit(Num_Buffer & BIT0);
        Num_Buffer = Num_Buffer >> 1;
    }

    HT1621_CS_HIGH;       // 使能禁止
}

/*
 * 简单延时（用于 HT1621 时序）
 */
void HT1621_Delay(void)
{
    unsigned int i;
    for (i = 0; i < 10; i++)
    {
        __no_operation();
    }
}
