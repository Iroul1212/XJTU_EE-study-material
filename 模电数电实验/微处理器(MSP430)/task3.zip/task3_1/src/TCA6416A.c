/*
 * TCA6416A.c
 * IO 扩展芯片 TCA6416A 库函数实现
 * 基于《LaunchPad口袋实验平台》第12章
 * TCA6416A 提供 16 路扩展 IO (P0.0~P0.7, P1.0~P1.7)
 * PinNum: 0~15, 对应 P0.0~P1.7
 */

#include "src/TCA6416A.h"

/* 全局变量 */
unsigned char Port0_Output = 0xFF;  // P0 输出缓存(默认全高)
unsigned char Port1_Output = 0xFF;  // P1 输出缓存(默认全高)

/*
 * 发送数据到 TCA6416A 寄存器
 */
unsigned char TCA6416_Tx_Frame(unsigned char RegAddr, unsigned char Data)
{
    unsigned char TxBuf[2];
    TxBuf[0] = RegAddr;
    TxBuf[1] = Data;
    I2C_TxFrame(TCA6416A_ADDR, TxBuf, 2);
    return 0;
}

/*
 * 从 TCA6416A 寄存器接收数据
 */
unsigned char TCA6416_Rx_Frame(unsigned char RegAddr)
{
    unsigned char RxData = 0;

    /* 先发送寄存器地址 */
    unsigned char TxBuf[1];
    TxBuf[0] = RegAddr;
    I2C_TxFrame(TCA6416A_ADDR, TxBuf, 1);

    /* 再接收数据 */
    I2C_RxFrame(TCA6416A_ADDR, &RxData, 1);

    return RxData;
}

/*
 * TCA6416A 初始化
 * 配置 P0.0~P0.7, P1.0~P1.7 全部为输出
 */
void TCA6416A_Init(void)
{
    /* 配置方向: 全部为输出 (0=输出) */
    TCA6416_Tx_Frame(TCA6416_CONFIG0, 0x00);  // P0 全部输出
    TCA6416_Tx_Frame(TCA6416_CONFIG1, 0x00);  // P1 全部输出

    /* 初始输出全高 */
    Port0_Output = 0xFF;
    Port1_Output = 0xFF;
    TCA6416_Tx_Frame(TCA6416_OUTPUT0, Port0_Output);
    TCA6416_Tx_Frame(TCA6416_OUTPUT1, Port1_Output);
}

/*
 * IO 输出控制
 * 手册编号: P0.0~P0.7 = 0~7,  P1.0~P1.7 = 10~17
 * 例: PinOUT(14,0) → P1.4 输出低 (HT1621 CS)
 *     PinOUT(17,1) → P1.7 输出高 (HT1621 DATA)
 */
void PinOUT(unsigned char PinNum, unsigned char Level)
{
    if (PinNum <= 7)            // P0.0~P0.7
    {
        if (Level)
            Port0_Output |= (1 << PinNum);
        else
            Port0_Output &= ~(1 << PinNum);
        TCA6416_Tx_Frame(TCA6416_OUTPUT0, Port0_Output);
    }
    else if (PinNum >= 10 && PinNum <= 17)  // P1.0~P1.7
    {
        PinNum -= 10;
        if (Level)
            Port1_Output |= (1 << PinNum);
        else
            Port1_Output &= ~(1 << PinNum);
        TCA6416_Tx_Frame(TCA6416_OUTPUT1, Port1_Output);
    }
}

/*
 * IO 输入检测
 * 编号同 PinOUT: P0=0~7, P1=10~17
 */
unsigned char PinIN(unsigned char PinNum)
{
    unsigned char PortVal;

    if (PinNum <= 7)
    {
        PortVal = TCA6416_Rx_Frame(TCA6416_INPUT0);
        return (PortVal >> PinNum) & 0x01;
    }
    else if (PinNum >= 10 && PinNum <= 17)
    {
        PinNum -= 10;
        PortVal = TCA6416_Rx_Frame(TCA6416_INPUT1);
        return (PortVal >> PinNum) & 0x01;
    }
    return 0;
}
