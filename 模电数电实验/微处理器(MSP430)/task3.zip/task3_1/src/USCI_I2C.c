/*
 * USCI_I2C.c
 * MSP430G2553 硬件 I2C 库函数实现
 * 基于《LaunchPad口袋实验平台》第12章
 * I2C 引脚: P1.6=SCL, P1.7=SDA (USCI_B0)
 */

#include "src/USCI_I2C.h"

/* 全局变量定义 */
volatile unsigned char I2C_State = I2C_IDLE;
volatile unsigned char *I2C_TxPtr;
volatile unsigned char *I2C_RxPtr;
volatile unsigned char I2C_TxLen;
volatile unsigned char I2C_RxLen;
volatile unsigned char I2C_TxDone;
volatile unsigned char I2C_RxDone;
volatile unsigned char I2C_RxNack;

/*
 * I2C 初始化：SMCLK/16 ≈ 100kHz @ 1MHz SMCLK
 */
void I2C_Init(void)
{
    /* P1.6=SCL, P1.7=SDA 设为外设模式 */
    P1SEL  |= BIT6 + BIT7;
    P1SEL2 |= BIT6 + BIT7;

    /* USCI_B0 复位 */
    UCB0CTL1 |= UCSWRST;

    /* I2C 主模式, 同步模式 */
    UCB0CTL0 = UCMST + UCMODE_3 + UCSYNC;

    /* 时钟源 SMCLK, 分频约 100kHz */
    UCB0CTL1 = UCSSEL_2 + UCSWRST;
    UCB0BR0 = 10;            // SMCLK/10 = 100kHz @ 1MHz
    UCB0BR1 = 0;

    /* 清除复位 */
    UCB0CTL1 &= ~UCSWRST;

    /* 使能发送/接收中断 */
    IE2 |= UCB0TXIE + UCB0RXIE;
}

/*
 * 初始化发送
 */
void I2C_Tx_Init(unsigned char *Data, unsigned char Len)
{
    I2C_TxPtr  = Data;
    I2C_TxLen  = Len;
    I2C_TxDone = 0;
    I2C_RxNack = 0;
    I2C_State  = I2C_TX;

    /* 发送起始位 + 从机地址(W) */
    UCB0CTL1 |= UCTR;           // 发送模式
    UCB0CTL1 |= UCTXSTT;        // 起始条件
}

/*
 * 初始化接收
 */
void I2C_Rx_Init(unsigned char *Data, unsigned char Len)
{
    I2C_RxPtr  = Data;
    I2C_RxLen  = Len;
    I2C_RxDone = 0;
    I2C_RxNack = 0;
    I2C_State  = I2C_RX;

    /* 发送起始位 + 从机地址(R) */
    UCB0CTL1 &= ~UCTR;          // 接收模式
    UCB0CTL1 |= UCTXSTT;        // 起始条件
}

/*
 * 发送一帧数据（带超时保护, 返回0=成功 1=失败）
 */
unsigned char I2C_TxFrame(unsigned char SlaveAddr, unsigned char *Data, unsigned char Len)
{
    volatile unsigned long timeout = 50000;

    UCB0STAT &= ~(UCNACKIFG + UCSTPIFG + UCSTTIFG);
    UCB0I2CSA = SlaveAddr;
    I2C_Tx_Init(Data, Len);

    __bis_SR_register(GIE);
    while (I2C_TxDone == 0 && I2C_RxNack == 0)
    {
        if (--timeout == 0) break;
    }

    if (timeout == 0 || I2C_RxNack)
    {
        UCB0CTL1 |= UCTXSTP;
        UCB0CTL1 |= UCSWRST;
        UCB0CTL1 &= ~UCSWRST;
        I2C_State  = I2C_IDLE;
        I2C_TxDone = 0;
        return 1;
    }
    return 0;
}

/*
 * 接收一帧数据（带超时保护, 返回0=成功 1=失败）
 */
unsigned char I2C_RxFrame(unsigned char SlaveAddr, unsigned char *Data, unsigned char Len)
{
    volatile unsigned long timeout = 50000;

    UCB0STAT &= ~(UCNACKIFG + UCSTPIFG + UCSTTIFG);
    UCB0I2CSA = SlaveAddr;
    I2C_Rx_Init(Data, Len);

    __bis_SR_register(GIE);
    while (I2C_RxDone == 0 && I2C_RxNack == 0)
    {
        if (--timeout == 0) break;
    }

    if (timeout == 0 || I2C_RxNack)
    {
        UCB0CTL1 |= UCTXSTP;
        UCB0CTL1 |= UCSWRST;
        UCB0CTL1 &= ~UCSWRST;
        I2C_State  = I2C_IDLE;
        I2C_RxDone = 0;
        return 1;
    }
    return 0;
}

/*
 * USCI_B0 发送中断服务函数
 */
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCIAB0TX_VECTOR
__interrupt void USCIAB0TX_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(USCIAB0TX_VECTOR))) USCIAB0TX_ISR (void)
#else
#error Compiler not supported!
#endif
{
    /* NACK 处理: 从机不应答时立即退出 */
    if (UCB0STAT & UCNACKIFG)
    {
        UCB0STAT &= ~UCNACKIFG;
        UCB0CTL1 |= UCTXSTP;
        I2C_RxNack = 1;
        I2C_TxDone = 1;
        I2C_State  = I2C_IDLE;
        return;
    }

    if (I2C_State == I2C_TX)
    {
        if (I2C_TxLen > 0)
        {
            UCB0TXBUF = *I2C_TxPtr++;  // 发送数据
            I2C_TxLen--;
        }
        else
        {
            /* 发送停止位 */
            UCB0CTL1 |= UCTXSTP;
            I2C_TxDone = 1;
            I2C_State  = I2C_IDLE;

            /* 清除中断标志 */
            IFG2 &= ~UCB0TXIFG;
        }
    }
    else if (I2C_State == I2C_RX)
    {
        if (I2C_RxDone == 1)
        {
            /* 发送停止位 */
            UCB0CTL1 |= UCTXSTP;
            I2C_State = I2C_IDLE;
        }
    }
}

/*
 * USCI_B0 接收中断服务函数
 */
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCIAB0RX_ISR(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(USCIAB0RX_VECTOR))) USCIAB0RX_ISR (void)
#else
#error Compiler not supported!
#endif
{
    if (I2C_State == I2C_RX)
    {
        if (I2C_RxLen > 0)
        {
            *I2C_RxPtr++ = UCB0RXBUF;  // 接收数据
            I2C_RxLen--;
        }

        if (I2C_RxLen == 1)
        {
            /* 倒数第2字节，发NACK */
            UCB0CTL1 |= UCTXNACK;
        }
        else if (I2C_RxLen == 0)
        {
            /* 最后一字节，发停止 */
            UCB0CTL1 |= UCTXSTP;
            I2C_RxDone = 1;
            I2C_State  = I2C_IDLE;
        }
    }
}
