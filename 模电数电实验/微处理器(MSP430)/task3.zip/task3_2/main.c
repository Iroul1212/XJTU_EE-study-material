#include <msp430.h>

#define SMCLK_HZ  1000000UL

volatile unsigned int  edge_cnt;          // 闸门内实时脉冲计数
volatile unsigned int  pulse_cnt;         // 冻结值 (CCS 观察)
volatile unsigned char gate_done;         // 闸门结束标志
volatile unsigned char wdt_tick;          // WDT 累计次数 (×1s)
volatile unsigned long freq_hz;           // 测量频率 (Hz)


void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;             // 先关看门狗

    DCOCTL  = CALDCO_1MHZ;
    BCSCTL1 = CALBC1_1MHZ;
    BCSCTL2  = 0;

    P1DIR |= BIT0;
    P1OUT &= ~BIT0;
    P1DIR &= ~BIT2;
    P1SEL |= BIT2;                        // TA0.1 CCI1A

    TA0CTL   = TASSEL_2 | MC_2;

    TA0CCTL1 = CM_1 | CCIS_0 | CAP | SCS | CCIE;

    __enable_interrupt();

    while (1)
    {
        edge_cnt  = 0;
        wdt_tick  = 0;
        gate_done = 0;

        TA0CCTL1 &= ~CCIFG;
        TA0CCTL1 |= CCIE;

        WDTCTL = WDTPW | WDTTMSEL | WDTCNTCL | WDTSSEL;
        IE1   |= WDTIE;


        while (!gate_done)
            __low_power_mode_0();

        IE1 &= ~WDTIE;
        WDTCTL = WDTPW | WDTHOLD;
        TA0CCTL1 &= ~CCIE;
 / 2UL;  // 2s 闸门, f = N/2
        pulse_cnt = edge_cnt;
        pulse_cnt = edge_cnt;             // 冻结显示

        P1OUT ^= BIT0;                    // LED 翻转
    }
}

#pragma vector = TIMER0_A1_VECTOR
__interrupt void TIMER0_A1_ISR(void)
{
    switch (__even_in_range(TA0IV, 14))
    {
        case 2:                            // CCR1 捕获 (P1.2 上升沿)
            edge_cnt++;
            break;

        default:
            break;
    }
}

#pragma vector = WDT_VECTOR
__interrupt void WDT_ISR(void)
{
    IFG1 &= ~WDTIFG;
    wdt_tick++;
    if (wdt_tick >= 2) {                  // 累计 2 次 = 2s
        gate_done = 1;
        __bic_SR_register_on_exit(LPM0_bits);
    }
}

