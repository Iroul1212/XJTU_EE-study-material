# FIXED

src/LCD_128.obj: ../src/LCD_128.c
src/LCD_128.obj: D:/MSP430/workspace_v12/task3_2/src/LCD_128.h

../src/LCD_128.c:

D:/MSP430/workspace_v12/task3_2/src/LCD_128.h:

