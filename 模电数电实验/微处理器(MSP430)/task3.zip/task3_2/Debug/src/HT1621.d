# FIXED

src/HT1621.obj: ../src/HT1621.c
src/HT1621.obj: D:/MSP430/workspace_v12/task3_2/src/HT1621.h
src/HT1621.obj: D:/MSP430/workspace_v12/task3_2/src/TCA6416A.h
src/HT1621.obj: D:/MSP430/workspace_v12/task3_2/src/USCI_I2C.h
src/HT1621.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h
src/HT1621.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430g2553.h
src/HT1621.obj: D:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h
src/HT1621.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h
src/HT1621.obj: D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h

../src/HT1621.c:

D:/MSP430/workspace_v12/task3_2/src/HT1621.h:

D:/MSP430/workspace_v12/task3_2/src/TCA6416A.h:

D:/MSP430/workspace_v12/task3_2/src/USCI_I2C.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/msp430g2553.h:

D:/ti/ccs1281/ccs/ccs_base/msp430/include/in430.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics.h:

D:/ti/ccs1281/ccs/tools/compiler/ti-cgt-msp430_21.6.1.LTS/include/intrinsics_legacy_undefs.h:

