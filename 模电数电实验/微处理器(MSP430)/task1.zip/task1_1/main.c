#include <msp430.h>

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // 关闭看门狗定时器

    P1DIR |= BIT0;               // P1.0设为输出
    P1OUT &= ~BIT0;              // 初始熄灭LED1

    P1DIR &= ~BIT4;              // P1.4设为输入

     P1REN |= BIT4;            // 启用P1.4内部电阻
    // P1OUT |= BIT4;            // 配置为上拉电阻（悬空时读到高电平→LED亮）
     P1OUT &= ~BIT4;           // 配置为下拉电阻（悬空时读到低电平→LED灭）

    while(1)
    {
        if(P1IN & BIT4)          // P1.4输入为高电平
        {
            P1OUT |= BIT0;       // LED1(P1.0)点亮
        }
        else                     // P1.4输入为低电平
        {
            P1OUT &= ~BIT0;      // LED1(P1.0)熄灭
        }
    }
}
