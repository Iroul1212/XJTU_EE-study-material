#include <msp430.h>

#define FAULT_1             // 故障1: 中断标志位未清零
// #define FAULT_2          // 故障2: 未开启全局中断

volatile unsigned char mode = 0;
unsigned char edge_count = 0;

void GPIO_Init(void);
void P1_IODect(void);
void P13_Onclick(void);

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;

    GPIO_Init();

#if !defined(FAULT_2)
    __enable_interrupt();
#else
    __disable_interrupt();          // 显式确保GIE=0
#endif

    while(1)
    {
        __low_power_mode_0();
    }
}

void GPIO_Init(void)
{

    P1DIR |= BIT0;
    P1OUT &= ~BIT0;

    P1DIR &= ~BIT3;
    P1REN |= BIT3;
    P1OUT |= BIT3;
    P1IES |= BIT3;
    P1IE  |= BIT3;
    P1IFG &= ~BIT3;

    P1DIR &= ~BIT4;
    P1REN |= BIT4;
    P1OUT |= BIT4;
    P1IES &= ~BIT4;
    P1IE  |= BIT4;
    P1IFG &= ~BIT4;
}

#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
    if(P1IFG & BIT3)
    {
        P1_IODect();
    }

    if(P1IFG & BIT4)
    {
        edge_count++;

        if(mode == 0)
        {
            if(edge_count >= 2)
            {
                P1OUT ^= BIT0;
                edge_count = 0;
            }
        }
        else
        {
            P1OUT ^= BIT0;
            edge_count = 0;
        }

#if !defined(FAULT_1)
        P1IFG &= ~BIT4;             // FAULT_1: 此行被跳过
#else

#endif
    }
}

void P1_IODect(void)
{
    unsigned char Push_Key;
    Push_Key = P1IFG & (~P1DIR);

    __delay_cycles(10000);

    if((P1IN & Push_Key) == 0)
    {
        switch(Push_Key)
        {
            case BIT3: P13_Onclick(); break;
            default: break;
        }
    }

    P1IFG &= ~BIT3;
}

void P13_Onclick(void)
{
    mode = !mode;
    edge_count = 0;
}
