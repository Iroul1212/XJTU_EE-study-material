#include <msp430.h>

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // 关闭看门狗
    P1DIR |= 0x01;              // P1.0 设为输出（LED）

    volatile unsigned int i;    // 16位，范围 0~65535

    while(1)
    {
        P1OUT ^= 0x01;          // 翻转 P1.0（LED 亮/灭）
        for(i = 100000; i > 0; i--);  // 软件延时，修改此值观察频率
    }
}
