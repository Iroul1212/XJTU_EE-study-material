#include <msp430.h>

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;       // 停止看门狗定时器

    BCSCTL3 |= LFXT1S_2;            // LFXT1Sx = 10b，选择 VLOCLK (~12kHz) 作为 ACLK 源

    P1DIR |= BIT0;                  // P1.0 设为输出
    P1SEL |= BIT0;                  // P1.0 选择外设功能 —— 输出 ACLK

    while (1){}

    return 0;
}
