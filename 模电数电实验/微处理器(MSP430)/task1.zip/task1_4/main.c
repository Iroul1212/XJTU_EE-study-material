#include <msp430.h>

void GPIO_Init(void);
void P1_IODect(void);
void P13_Onclick(void);

void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;   // 关闭看门狗

    DCOCTL  = CALDCO_16MHZ;
    BCSCTL1 = CALBC1_16MHZ;

    BCSCTL2 = 0x00;

    GPIO_Init();                // 初始化GPIO
    _enable_interrupts();       // 使能总中断

    while(1)
    {
        __delay_cycles(1000000);
        P1OUT ^= BIT6;          // LED2(P1.6) 状态翻转
    }
}

void GPIO_Init(void)
{
    P1DIR |= BIT6;
    P1OUT |= BIT6;

    P1SEL |= BIT4;              // 选择SMCLK外设功能
    P1DIR |= BIT4;              // 输出方向

    P1REN |= BIT3;              // 启用内部上下拉电阻
    P1OUT |= BIT3;              // 设置为上拉
    P1IES |= BIT3;              // 下降沿触发中断
    P1IE  |= BIT3;              // 允许P1.3中断
    P1DIR &= ~BIT3;             // P1.3设为输入
}

#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
    P1_IODect();                // 检测具体中断IO
    P1IFG = 0;                  // 手动清除中断标志
}

void P1_IODect(void)
{
    unsigned int Push_Key = 0;
    Push_Key = P1IFG & (~P1DIR);            // 排除输出IO干扰

    __delay_cycles(10000);                  // 消抖延时

    if((P1IN & Push_Key) == 0)              // 按键仍然按下，确认有效
    {
        switch(Push_Key)
        {
            case BIT3: P13_Onclick(); break; // P1.3事件处理
            default: break;
        }
    }
}

void P13_Onclick(void)
{
    static unsigned char Freq = 0;          // 静态变量，记录当前分频档位
    unsigned char divBits;

    Freq++;
    if(Freq > 3) Freq = 0;                  // 0~3循环

    switch(Freq)
    {
        case 0:                             // ÷2: DIVM=01, DIVS=01
            divBits = (DIVM_1 | DIVS_1);    // 01 << 4 | 01 << 2
            break;
        case 1:                             // ÷4: DIVM=10, DIVS=10
            divBits = (DIVM_2 | DIVS_2);
            break;
        case 2:                             // ÷8: DIVM=11, DIVS=11
            divBits = (DIVM_3 | DIVS_3);
            break;
        case 3:                             // ÷1: DIVM=00, DIVS=00
            divBits = (DIVM_0 | DIVS_0);
            break;
        default: break;
    }
	
    BCSCTL2 = divBits;
}
