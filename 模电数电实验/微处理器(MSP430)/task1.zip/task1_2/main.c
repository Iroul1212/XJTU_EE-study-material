#include <msp430.h>

volatile unsigned char mode = 0;    // 0=功能A(1Hz), 1=功能B(2Hz)
unsigned char edge_count = 0;       // 边沿计数器

void GPIO_Init(void);
void P1_IODect(void);               // P1口中断事件检测
void P13_Onclick(void);             // P1.3按键事件处理

int main(void)
{
    WDTCTL = WDTPW | WDTHOLD;       // 关闭看门狗

    GPIO_Init();
    __enable_interrupt();            // 使能全局中断

    while(1)
    {
        __low_power_mode_0();        // 进入LPM0，等待中断唤醒
    }
}

void GPIO_Init(void)
{
    P1DIR |= BIT0;
    P1OUT &= ~BIT0;

    P1DIR &= ~BIT3;
    P1REN |= BIT3;                  // 启用内部电阻
    P1OUT |= BIT3;                  // 上拉（未按下=高电平，按下=低电平）
    P1IES |= BIT3;                  // 下降沿触发（高→低，即按下瞬间）
    P1IE  |= BIT3;                  // 使能P1.3中断
    P1IFG &= ~BIT3;

    P1DIR &= ~BIT4;
    P1REN |= BIT4;
    P1OUT |= BIT4;                  // 上拉
    P1IES &= ~BIT4;                 // 上升沿触发
    P1IE  |= BIT4;                  // 使能P1.4中断
    P1IFG &= ~BIT4;
}

#pragma vector = PORT1_VECTOR
__interrupt void PORT1_ISR(void)
{
    if(P1IFG & BIT3)
    {
        P1_IODect();                // 消抖检测 + 事件处理
    }

    if(P1IFG & BIT4)
    {
        edge_count++;

        if(mode == 0)               // 功能A: 1Hz (每2个边沿翻转)
        {
            if(edge_count >= 2)
            {
                P1OUT ^= BIT0;
                edge_count = 0;
            }
        }
        else                        // 功能B: 2Hz (每1个边沿翻转)
        {
            P1OUT ^= BIT0;
            edge_count = 0;
        }

        P1IFG &= ~BIT4;
    }
}


void P1_IODect(void)
{
    unsigned char Push_Key;
    Push_Key = P1IFG & (~P1DIR);    // 排除输出IO，锁定中断源

    __delay_cycles(10000);          // 消抖延时（约1ms @ 1MHz）

    if((P1IN & Push_Key) == 0)      // 确认按键依然按下（低电平有效）
    {
        switch(Push_Key)
        {
            case BIT3: P13_Onclick(); break;
            default: break;
        }
    }

    P1IFG &= ~BIT3;                 // 清除P1.3中断标志
}

void P13_Onclick(void)
{
    mode = !mode;                   // 翻转模式: 0→1 或 1→0
    edge_count = 0;                 // 复位边沿计数器，避免模式切换瞬间误触发
}
